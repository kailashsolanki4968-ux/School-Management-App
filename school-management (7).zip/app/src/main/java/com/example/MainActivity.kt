package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthViewModel
import com.example.ui.auth.AuthViewModelFactory
import com.example.ui.parent.ParentMainScreen
import com.example.ui.parent.ParentViewModel
import com.example.ui.parent.ParentViewModelFactory
import com.example.ui.principal.PrincipalMainScreen
import com.example.ui.principal.PrincipalViewModel
import com.example.ui.principal.PrincipalViewModelFactory
import com.example.ui.teacher.TeacherMainScreen
import com.example.ui.teacher.TeacherViewModel
import com.example.ui.teacher.TeacherViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var repository: SchoolRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = SchoolRepository.getInstance(applicationContext)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SchoolApp(repository = repository)
                }
            }
        }
    }
}

@Composable
fun SchoolApp(repository: SchoolRepository) {
    val session by repository.sessionState.collectAsStateWithLifecycle()

    when (val currentSession = session) {
        null -> {
            val authViewModel: AuthViewModel = viewModel(
                factory = AuthViewModelFactory(repository)
            )
            AuthScreen(viewModel = authViewModel)
        }
        else -> {
            when (currentSession.role) {
                UserRole.PRINCIPAL.name -> {
                    val principalViewModel: PrincipalViewModel = viewModel(
                        key = "principal_${currentSession.userId}",
                        factory = PrincipalViewModelFactory(repository)
                    )
                    PrincipalMainScreen(viewModel = principalViewModel)
                }
                UserRole.TEACHER.name -> {
                    val teacherViewModel: TeacherViewModel = viewModel(
                        key = "teacher_${currentSession.userId}",
                        factory = TeacherViewModelFactory(repository, currentSession.userId)
                    )
                    TeacherMainScreen(viewModel = teacherViewModel)
                }
                UserRole.PARENT.name -> {
                    val parentViewModel: ParentViewModel = viewModel(
                        key = "parent_${currentSession.userId}",
                        factory = ParentViewModelFactory(repository, currentSession.userId)
                    )
                    ParentMainScreen(viewModel = parentViewModel)
                }
                else -> {
                    val authViewModel: AuthViewModel = viewModel(
                        factory = AuthViewModelFactory(repository)
                    )
                    AuthScreen(viewModel = authViewModel)
                }
            }
        }
    }
}
