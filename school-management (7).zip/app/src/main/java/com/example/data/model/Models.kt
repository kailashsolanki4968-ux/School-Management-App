package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    PRINCIPAL,
    TEACHER,
    PARENT
}

enum class AccountStatus {
    APPROVED,
    PENDING,
    REJECTED
}

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    EXCUSED
}

enum class LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}

enum class LeaveType {
    SICK,
    CASUAL,
    EMERGENCY,
    ANNUAL
}

enum class AnnouncementPriority {
    NORMAL,
    URGENT,
    EVENT
}

@Entity(tableName = "schools")
data class School(
    @PrimaryKey val id: String, // e.g. "SCH_OAKRIDGE_101"
    val name: String, // e.g. "Oakridge International School"
    val code: String, // e.g. "OAK101"
    val address: String = "123 Academic Way",
    val principalId: String = "PRIN001",
    val contactEmail: String = "admin@school.edu",
    val contactPhone: String = "+1 555-0199",
    val currency: String = "₹",
    val currencyCode: String = "INR",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "users")
data class UserAccount(
    @PrimaryKey val id: String, // e.g. "PRIN001", "TCH101", "PAR101"
    val schoolId: String = "SCH_OAKRIDGE_101",
    val name: String,
    val email: String,
    val phone: String,
    val role: String, // UserRole.PRINCIPAL.name, UserRole.TEACHER.name, UserRole.PARENT.name
    val passwordHash: String,
    val passwordSalt: String = "",
    val securityQuestion: String,
    val securityAnswer: String,
    val status: String = AccountStatus.APPROVED.name,
    val assignedClassId: String? = null,
    val linkedStudentIds: String = "", // Comma-separated student IDs for PARENT role
    val subject: String? = null,
    val joiningDate: String? = null,
    val monthlySalary: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "classes")
data class SchoolClass(
    @PrimaryKey val id: String, // e.g. "CLASS_10A"
    val schoolId: String = "SCH_OAKRIDGE_101",
    val name: String, // e.g. "Grade 10 - Section A"
    val grade: String, // e.g. "Grade 10"
    val section: String, // e.g. "A"
    val classTeacherId: String? = null,
    val roomNumber: String = "Room 101"
)

@Entity(tableName = "students")
data class Student(
    @PrimaryKey val id: String, // e.g. "STU_1001"
    val schoolId: String = "SCH_OAKRIDGE_101",
    val rollNumber: String,
    val name: String,
    val classId: String,
    val gender: String = "Male",
    val parentName: String = "",
    val parentPhone: String = "",
    val parentUserId: String? = null,
    val emergencyContact: String = "",
    val address: String = ""
)

@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val date: String, // "yyyy-MM-dd"
    val studentId: String,
    val studentName: String,
    val rollNumber: String,
    val classId: String,
    val status: String, // AttendanceStatus
    val markedByTeacherId: String = "",
    val remarks: String? = null,
    val isSubmitted: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "attendance_submissions")
data class AttendanceSubmissionRecord(
    @PrimaryKey val id: String, // "${classId}_${date}"
    val schoolId: String = "SCH_OAKRIDGE_101",
    val date: String, // "yyyy-MM-dd"
    val classId: String,
    val className: String,
    val classTeacherId: String,
    val classTeacherName: String,
    val totalStudents: Int,
    val presentStudents: Int,
    val absentStudents: Int,
    val absentStudentNames: String, // Comma separated absent students or "None"
    val absentNotes: String, // Combined notes for absentees or "No notes"
    val submittedStatus: String = "SUBMITTED", // "SUBMITTED", "PENDING", "APPROVED"
    val submittedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val classId: String,
    val teacherId: String,
    val teacherName: String,
    val subject: String,
    val title: String,
    val description: String,
    val assignedDate: String, // "yyyy-MM-dd"
    val dueDate: String, // "yyyy-MM-dd"
    val status: String = "ACTIVE"
)

@Entity(tableName = "school_tests")
data class SchoolTest(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val classId: String,
    val className: String = "",
    val testName: String, // e.g. "Unit Test 1", "Mid-Term Exam"
    val subject: String,
    val date: String, // "yyyy-MM-dd"
    val maxMarks: Double = 100.0,
    val createdByTeacherId: String = "",
    val createdByTeacherName: String = "",
    val totalStudents: Int = 0,
    val averageScore: Double = 0.0,
    val highestScore: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "student_marks")
data class StudentMark(
    @PrimaryKey val id: String, // UUID
    val testId: String = "",
    val schoolId: String = "SCH_OAKRIDGE_101",
    val studentId: String,
    val studentName: String,
    val rollNumber: String,
    val classId: String,
    val examName: String, // e.g. "Mid-Term Exam", "Unit Test 1"
    val subject: String,
    val maxMarks: Double = 100.0,
    val marksObtained: Double = 0.0,
    val percentage: Double = 0.0,
    val rank: Int = 1,
    val grade: String = "A",
    val remarks: String? = null,
    val date: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "student_fees")
data class StudentFee(
    @PrimaryKey val studentId: String, // One record per student
    val schoolId: String = "SCH_OAKRIDGE_101",
    val studentName: String,
    val rollNumber: String,
    val classId: String,
    val totalFee: Double = 0.0,
    val totalPaid: Double = 0.0,
    val remainingFee: Double = 0.0,
    val status: String = "UNPAID", // "PAID", "PARTIAL", "UNPAID"
    val lastPaymentDate: String? = null,
    val currency: String = "₹",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "fee_payments")
data class FeePayment(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val studentId: String,
    val studentName: String,
    val rollNumber: String,
    val classId: String,
    val amount: Double,
    val date: String, // "yyyy-MM-dd"
    val paymentMode: String = "Cash", // Cash, Bank Transfer, Online, Card, UPI, Cheque
    val note: String = "",
    val receiptNumber: String = "",
    val recordedBy: String = "Principal",
    val currency: String = "₹",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val title: String,
    val content: String,
    val targetAudience: String = "ALL", // "ALL" or specific classId
    val priority: String = AnnouncementPriority.NORMAL.name,
    val authorName: String = "Principal",
    val date: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "leave_requests")
data class LeaveRequest(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val teacherId: String,
    val teacherName: String,
    val leaveType: String, // LeaveType
    val startDate: String,
    val endDate: String,
    val daysCount: Int = 1,
    val reason: String,
    val status: String = LeaveStatus.PENDING.name,
    val principalComment: String? = null,
    val appliedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val studentId: String,
    val studentName: String,
    val senderId: String,
    val senderName: String,
    val senderRole: String, // "PRINCIPAL", "TEACHER", "PARENT"
    val receiverId: String,
    val receiverName: String,
    val receiverRole: String, // "PRINCIPAL", "TEACHER", "PARENT"
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SENT" // "SENDING", "SENT", "DELIVERED", "FAILED"
)

@Entity(tableName = "teacher_salaries")
data class TeacherSalary(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val teacherId: String,
    val teacherName: String,
    val month: String, // e.g. "September 2026", "August 2026"
    val monthlySalary: Double,
    val amountPaid: Double,
    val paymentDate: String, // "yyyy-MM-dd"
    val remainingAmount: Double = (monthlySalary - amountPaid).coerceAtLeast(0.0),
    val currency: String = "₹",
    val paymentMode: String = "Bank Transfer", // "Bank Transfer", "Cheque", "Cash", "UPI/Online"
    val transactionRef: String = "",
    val remarks: String = "",
    val status: String = "PAID", // "PAID", "PARTIAL", "PENDING"
    val recordedBy: String = "Principal",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "activity_records")
data class ActivityRecord(
    @PrimaryKey val id: String, // UUID
    val schoolId: String = "SCH_OAKRIDGE_101",
    val date: String, // "yyyy-MM-dd"
    val time: String, // "hh:mm a"
    val timestamp: Long = System.currentTimeMillis(),
    val category: String, // ATTENDANCE, MARKS_TESTS, STUDENT_RECORD, TEACHER_RECORD, FEE_PAYMENT, SALARY_PAYMENT, ANNOUNCEMENT, LEAVE_REQUEST, OTHER
    val personName: String,
    val personRole: String = "STUDENT", // STUDENT, TEACHER, PARENT, PRINCIPAL, STAFF
    val personId: String = "",
    val classId: String = "",
    val className: String = "",
    val action: String,
    val amount: Double? = null,
    val marks: String? = null,
    val details: String = "",
    val performedBy: String = "Principal"
)

enum class ActivityCategory(val key: String, val displayName: String) {
    ALL("ALL", "All Categories"),
    ATTENDANCE("ATTENDANCE", "Attendance"),
    MARKS_TESTS("MARKS_TESTS", "Tests & Marks"),
    STUDENT_RECORD("STUDENT_RECORD", "Student Records"),
    TEACHER_RECORD("TEACHER_RECORD", "Teacher Records"),
    FEE_PAYMENT("FEE_PAYMENT", "Fee Payments"),
    SALARY_PAYMENT("SALARY_PAYMENT", "Teacher Salaries"),
    ANNOUNCEMENT("ANNOUNCEMENT", "Notices & Broadcasts"),
    LEAVE_REQUEST("LEAVE_REQUEST", "Leave Requests"),
    OTHER("OTHER", "Other Activities")
}


