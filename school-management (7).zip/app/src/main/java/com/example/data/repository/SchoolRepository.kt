package com.example.data.repository

import android.content.Context
import com.example.data.cloud.CloudDatabaseService
import com.example.data.db.AppDatabase
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.School
import com.example.data.model.SchoolClass
import com.example.data.model.SchoolTest
import com.example.data.model.Student
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.TeacherSalary
import com.example.data.model.ActivityRecord
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.security.PasswordSecurity
import com.example.data.session.SessionManager
import com.example.data.session.UserSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class SchoolRepository(
    private val database: AppDatabase,
    private val sessionManager: SessionManager,
    private val cloudService: CloudDatabaseService
) {
    val sessionState: StateFlow<UserSession?> = sessionManager.sessionState

    val currentSchoolId: String
        get() = sessionManager.sessionState.value?.schoolId ?: "SCH_OAKRIDGE_101"

    // --- Schools ---
    fun getAllSchools(): Flow<List<School>> = database.schoolDao().getAllSchools()
    fun getSchoolByIdFlow(id: String): Flow<School?> = database.schoolDao().getSchoolByIdFlow(id)
    fun getCurrentSchoolFlow(): Flow<School?> = database.schoolDao().getSchoolByIdFlow(currentSchoolId)

    suspend fun getSchoolById(id: String): School? = withContext(Dispatchers.IO) {
        database.schoolDao().getSchoolById(id) ?: cloudService.getCloudSchoolById(id)
    }

    suspend fun updateSchoolCurrency(currency: String, currencyCode: String) = withContext(Dispatchers.IO) {
        database.schoolDao().updateSchoolCurrency(currentSchoolId, currency, currencyCode)
    }

    suspend fun registerSchool(school: School): Result<School> = withContext(Dispatchers.IO) {
        val cloudRes = cloudService.registerSchool(school)
        if (cloudRes.isFailure) return@withContext cloudRes
        database.schoolDao().insertSchool(school)
        Result.success(school)
    }

    // --- Users & Multi-Device Cloud Authentication ---
    fun getAllTeachers(): Flow<List<UserAccount>> = database.userDao().getAllTeachers(currentSchoolId)
    fun getPendingTeachers(): Flow<List<UserAccount>> = database.userDao().getPendingTeachers(currentSchoolId)
    fun getApprovedTeachers(): Flow<List<UserAccount>> = database.userDao().getApprovedTeachers(currentSchoolId)

    fun getAllParents(): Flow<List<UserAccount>> = database.userDao().getAllParents(currentSchoolId)
    fun getPendingParents(): Flow<List<UserAccount>> = database.userDao().getPendingParents(currentSchoolId)
    fun getApprovedParents(): Flow<List<UserAccount>> = database.userDao().getApprovedParents(currentSchoolId)

    fun getUserByIdFlow(id: String): Flow<UserAccount?> = database.userDao().getUserByIdFlow(id)

    suspend fun getUserById(id: String): UserAccount? = withContext(Dispatchers.IO) {
        database.userDao().getUserById(id) ?: cloudService.findCloudUser(id)
    }

    suspend fun registerUser(user: UserAccount, rawPassword: String, rawSecurityAnswer: String): Result<UserAccount> = withContext(Dispatchers.IO) {
        val salt = PasswordSecurity.generateSalt()
        val passwordHash = PasswordSecurity.hashPassword(rawPassword, salt)
        val answerHash = PasswordSecurity.hashSecurityAnswer(rawSecurityAnswer)

        val securedUser = user.copy(
            passwordHash = passwordHash,
            passwordSalt = salt,
            securityAnswer = answerHash
        )

        // 1. Cloud registration (ensures account is accessible on all devices)
        val cloudRes = cloudService.registerCloudUser(securedUser)
        if (cloudRes.isFailure) {
            return@withContext cloudRes
        }

        // 2. Local DB persistence
        database.userDao().insertUser(securedUser)
        Result.success(securedUser)
    }

    suspend fun login(id: String, password: String, expectedRole: String, inputSchoolId: String? = null): Result<UserAccount> = withContext(Dispatchers.IO) {
        val cleanId = id.trim()

        // 1. First check Cloud user registry for multi-device sync
        var user = cloudService.findCloudUser(cleanId)
        if (user != null) {
            database.userDao().insertUser(user)
        } else {
            user = database.userDao().getUserById(cleanId)
        }

        if (user == null) {
            return@withContext Result.failure(
                Exception("Account ID '$cleanId' not found. Please verify your ID or create an account.")
            )
        }

        // 2. Strict School ID validation (if provided)
        if (!inputSchoolId.isNullOrBlank() && !user.schoolId.equals(inputSchoolId.trim(), ignoreCase = true)) {
            return@withContext Result.failure(
                Exception("Invalid School ID. This account belongs to school '${user.schoolId}'.")
            )
        }

        // 3. Cryptographic password verification
        val isPasswordCorrect = PasswordSecurity.verifyPassword(password, user.passwordSalt, user.passwordHash)
        if (!isPasswordCorrect) {
            return@withContext Result.failure(Exception("Incorrect password. Please check and try again."))
        }

        // 4. Role validation
        if (user.role != expectedRole) {
            return@withContext Result.failure(
                Exception("Unauthorized role. This account is registered as ${user.role}, not $expectedRole.")
            )
        }

        // 5. Account approval check for teachers
        if (user.role == UserRole.TEACHER.name) {
            when (user.status) {
                AccountStatus.PENDING.name -> {
                    return@withContext Result.failure(
                        Exception("Your Teacher account is pending Principal approval. Please wait for the Principal to approve your registration.")
                    )
                }
                AccountStatus.REJECTED.name -> {
                    return@withContext Result.failure(
                        Exception("Your Teacher account registration was declined by the Principal.")
                    )
                }
            }
        }

        // Retrieve School Name
        val school = database.schoolDao().getSchoolById(user.schoolId)
            ?: cloudService.getCloudSchoolById(user.schoolId)
        val schoolName = school?.name ?: "School (${user.schoolId})"

        // Save session
        sessionManager.saveSession(
            userId = user.id,
            role = user.role,
            name = user.name,
            schoolId = user.schoolId,
            schoolName = schoolName,
            assignedClassId = user.assignedClassId,
            linkedStudentIds = user.linkedStudentIds
        )

        Result.success(user)
    }

    fun logout() {
        sessionManager.clearSession()
    }

    suspend fun updateTeacherStatus(teacherId: String, status: String) = withContext(Dispatchers.IO) {
        database.userDao().updateTeacherStatus(teacherId, status)
        cloudService.updateCloudTeacherStatus(teacherId, status)
    }

    suspend fun updateParentStatus(parentId: String, status: String) = withContext(Dispatchers.IO) {
        database.userDao().updateUserStatus(parentId, status)
        cloudService.updateCloudUserStatus(parentId, status)
    }

    suspend fun linkParentToStudent(parentId: String, studentId: String) = withContext(Dispatchers.IO) {
        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        val currentIds = parent?.linkedStudentIds?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
        currentIds.add(studentId.trim())
        val updatedIds = currentIds.joinToString(",")

        database.userDao().updateParentLinkedStudents(parentId, updatedIds)
        database.studentDao().updateStudentParentUserId(studentId, parentId)
        cloudService.linkParentStudentInCloud(parentId, studentId)
    }

    suspend fun unlinkParentFromStudent(parentId: String, studentId: String) = withContext(Dispatchers.IO) {
        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        val currentIds = parent?.linkedStudentIds?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
        currentIds.remove(studentId.trim())
        val updatedIds = currentIds.joinToString(",")

        database.userDao().updateParentLinkedStudents(parentId, updatedIds)
        database.studentDao().updateStudentParentUserId(studentId, null)
        cloudService.unlinkParentStudentInCloud(parentId, studentId)
    }

    suspend fun updateTeacherClass(teacherId: String, classId: String?) = withContext(Dispatchers.IO) {
        database.userDao().updateAssignedClass(teacherId, classId)
        val user = database.userDao().getUserById(teacherId)
        if (user != null) {
            cloudService.updateCloudUser(user.copy(assignedClassId = classId))
        }
        if (classId != null) {
            database.classDao().updateClassTeacher(classId, teacherId)
        }
    }

    suspend fun updateTeacher(teacher: UserAccount) = withContext(Dispatchers.IO) {
        database.userDao().updateUser(teacher)
        cloudService.updateCloudUser(teacher)
        if (teacher.assignedClassId != null) {
            database.classDao().updateClassTeacher(teacher.assignedClassId, teacher.id)
        }
    }

    suspend fun resetPasswordWithSecurity(
        userId: String,
        securityAnswer: String,
        newPassword: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        val user = database.userDao().getUserById(cleanId) ?: cloudService.findCloudUser(cleanId)
            ?: return@withContext Result.failure(Exception("User ID not found in system."))

        val isAnswerCorrect = PasswordSecurity.verifySecurityAnswer(securityAnswer, user.securityAnswer)
        if (!isAnswerCorrect) {
            return@withContext Result.failure(Exception("Security answer is incorrect."))
        }

        val newSalt = PasswordSecurity.generateSalt()
        val newHash = PasswordSecurity.hashPassword(newPassword, newSalt)

        database.userDao().updatePassword(user.id, newHash, newSalt)
        cloudService.updateCloudUserPassword(user.id, newHash, newSalt)
        Result.success(Unit)
    }

    suspend fun directUpdatePassword(userId: String, newPassword: String) = withContext(Dispatchers.IO) {
        val newSalt = PasswordSecurity.generateSalt()
        val newHash = PasswordSecurity.hashPassword(newPassword, newSalt)
        database.userDao().updatePassword(userId, newHash, newSalt)
        cloudService.updateCloudUserPassword(userId, newHash, newSalt)
    }

    suspend fun deleteTeacher(teacherId: String) = withContext(Dispatchers.IO) {
        database.userDao().deleteUser(teacherId)
    }

    suspend fun deleteParent(parentId: String) = withContext(Dispatchers.IO) {
        database.userDao().deleteUser(parentId)
    }

    // --- Classes (School Isolated) ---
    fun getAllClasses(): Flow<List<SchoolClass>> = database.classDao().getAllClasses(currentSchoolId)
    fun getClassByIdFlow(id: String): Flow<SchoolClass?> = database.classDao().getClassByIdFlow(id)
    suspend fun getClassById(id: String): SchoolClass? = withContext(Dispatchers.IO) {
        database.classDao().getClassById(id)
    }

    suspend fun insertClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        val classWithSchool = schoolClass.copy(schoolId = currentSchoolId)
        database.classDao().insertClass(classWithSchool)
        classWithSchool.classTeacherId?.let { teacherId ->
            database.userDao().updateAssignedClass(teacherId, classWithSchool.id)
        }
    }

    suspend fun updateClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        val classWithSchool = schoolClass.copy(schoolId = currentSchoolId)
        database.classDao().updateClass(classWithSchool)
        classWithSchool.classTeacherId?.let { teacherId ->
            database.userDao().updateAssignedClass(teacherId, classWithSchool.id)
        }
    }

    suspend fun deleteClass(classId: String) = withContext(Dispatchers.IO) {
        database.classDao().deleteClass(classId)
    }

    // --- Students (School Isolated) ---
    fun getAllStudents(): Flow<List<Student>> = database.studentDao().getAllStudents(currentSchoolId)
    fun getStudentsByClass(classId: String): Flow<List<Student>> = database.studentDao().getStudentsByClass(currentSchoolId, classId)
    suspend fun getStudentsByClassDirect(classId: String): List<Student> = withContext(Dispatchers.IO) {
        database.studentDao().getStudentsByClassDirect(currentSchoolId, classId)
    }

    fun getStudentByIdFlow(id: String): Flow<Student?> = database.studentDao().getStudentByIdFlow(id)
    suspend fun getStudentById(id: String): Student? = withContext(Dispatchers.IO) {
        database.studentDao().getStudentById(id)
    }

    fun getStudentsByIdsFlow(ids: List<String>): Flow<List<Student>> {
        if (ids.isEmpty()) return flowOf(emptyList())
        return database.studentDao().getStudentsByIdsFlow(ids)
    }

    suspend fun getStudentsByIds(ids: List<String>): List<Student> = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) emptyList()
        else database.studentDao().getStudentsByIds(ids)
    }

    suspend fun insertStudent(student: Student) = withContext(Dispatchers.IO) {
        database.studentDao().insertStudent(student.copy(schoolId = currentSchoolId))
    }

    suspend fun updateStudent(student: Student) = withContext(Dispatchers.IO) {
        database.studentDao().updateStudent(student.copy(schoolId = currentSchoolId))
    }

    suspend fun deleteStudent(studentId: String) = withContext(Dispatchers.IO) {
        database.studentDao().deleteStudent(studentId)
    }

    // --- Attendance (School Isolated) ---
    fun getAttendanceByClassAndDate(classId: String, date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceByClassAndDate(currentSchoolId, classId, date)

    suspend fun getAttendanceByClassAndDateDirect(classId: String, date: String): List<AttendanceRecord> =
        withContext(Dispatchers.IO) {
            database.attendanceDao().getAttendanceByClassAndDateDirect(currentSchoolId, classId, date)
        }

    fun getAllAttendanceByDate(date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAllAttendanceByDate(currentSchoolId, date)

    fun getAbsentStudentsByDate(date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAbsentStudentsByDate(currentSchoolId, date)

    fun getAttendanceForStudent(studentId: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceForStudent(studentId)

    suspend fun saveAttendance(records: List<AttendanceRecord>) = withContext(Dispatchers.IO) {
        val isolated = records.map { it.copy(schoolId = currentSchoolId) }
        database.attendanceDao().insertAttendance(isolated)
    }

    suspend fun saveSingleAttendance(record: AttendanceRecord) = withContext(Dispatchers.IO) {
        database.attendanceDao().insertSingleAttendance(record.copy(schoolId = currentSchoolId))
    }

    // --- Attendance Submissions (School Isolated) ---
    fun getAllAttendanceSubmissions(): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getAllSubmissions(currentSchoolId)

    fun getAttendanceSubmissionsByDate(date: String): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getSubmissionsByDate(currentSchoolId, date)

    fun getAttendanceSubmissionsByClass(classId: String): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getSubmissionsByClass(currentSchoolId, classId)

    fun getAttendanceSubmissionByClassAndDateFlow(classId: String, date: String): Flow<AttendanceSubmissionRecord?> =
        database.attendanceSubmissionDao().getSubmissionByClassAndDateFlow(currentSchoolId, classId, date)

    suspend fun getAttendanceSubmissionByClassAndDate(classId: String, date: String): AttendanceSubmissionRecord? =
        withContext(Dispatchers.IO) {
            database.attendanceSubmissionDao().getSubmissionByClassAndDate(currentSchoolId, classId, date)
        }

    suspend fun submitAttendanceReport(
        submission: AttendanceSubmissionRecord,
        records: List<AttendanceRecord>
    ) = withContext(Dispatchers.IO) {
        val isolatedRecords = records.map { it.copy(schoolId = currentSchoolId) }
        val isolatedSubmission = submission.copy(schoolId = currentSchoolId)
        database.attendanceDao().insertAttendance(isolatedRecords)
        database.attendanceSubmissionDao().insertSubmission(isolatedSubmission)

        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = submission.date,
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = "ATTENDANCE",
            personName = submission.classTeacherName,
            personRole = "TEACHER",
            personId = submission.classTeacherId,
            classId = submission.classId,
            className = submission.className,
            action = "Daily Attendance Submitted (${submission.className})",
            amount = null,
            marks = null,
            details = "Total Students: ${submission.totalStudents} • Present: ${submission.presentStudents} • Absent: ${submission.absentStudents}. Absentees: ${submission.absentStudentNames.ifBlank { "None" }}. Notes: ${submission.absentNotes.ifBlank { "N/A" }}",
            performedBy = submission.classTeacherName
        )
        database.activityRecordDao().insertActivity(activity)
    }

    // --- Homework (School Isolated) ---
    fun getHomeworkByClass(classId: String): Flow<List<Homework>> =
        database.homeworkDao().getHomeworkByClass(currentSchoolId, classId)

    fun getAllHomework(): Flow<List<Homework>> =
        database.homeworkDao().getAllHomework(currentSchoolId)

    suspend fun insertHomework(homework: Homework) = withContext(Dispatchers.IO) {
        database.homeworkDao().insertHomework(homework.copy(schoolId = currentSchoolId))
    }

    suspend fun deleteHomework(id: String) = withContext(Dispatchers.IO) {
        database.homeworkDao().deleteHomework(id)
    }

    // --- Tests & Result History (School Isolated & Calculated Ranks) ---
    fun getAllTests(): Flow<List<SchoolTest>> =
        database.testDao().getAllTests(currentSchoolId)

    fun getTestsByClass(classId: String): Flow<List<SchoolTest>> =
        database.testDao().getTestsByClass(currentSchoolId, classId)

    fun getTestByIdFlow(id: String): Flow<SchoolTest?> =
        database.testDao().getTestByIdFlow(id)

    suspend fun createTestWithMarks(
        testId: String,
        classId: String,
        className: String,
        testName: String,
        subject: String,
        date: String,
        maxMarks: Double,
        teacherId: String,
        teacherName: String,
        marksDrafts: List<Pair<Student, Pair<Double, String?>>>
    ): Result<SchoolTest> = withContext(Dispatchers.IO) {
        try {
            val safeMaxMarks = if (maxMarks <= 0.0) 100.0 else maxMarks
            val totalStudents = marksDrafts.size

            // Sort descending by marks obtained to calculate competition rank
            val sortedList = marksDrafts.sortedByDescending { it.second.first }
            val highestScore = sortedList.firstOrNull()?.second?.first ?: 0.0
            val averageScore = if (totalStudents > 0) {
                sortedList.map { it.second.first }.average()
            } else 0.0

            val marksToInsert = sortedList.mapIndexed { index, (student, scoreAndRemark) ->
                val obtained = scoreAndRemark.first.coerceIn(0.0, safeMaxMarks)
                val remarks = scoreAndRemark.second
                val percentage = (obtained / safeMaxMarks) * 100.0

                // Rank calculation (handles ties)
                val rank = if (index > 0 && obtained == sortedList[index - 1].second.first) {
                    sortedList.indexOfFirst { it.second.first == obtained } + 1
                } else {
                    index + 1
                }

                val grade = when {
                    percentage >= 90.0 -> "A+"
                    percentage >= 80.0 -> "A"
                    percentage >= 70.0 -> "B+"
                    percentage >= 60.0 -> "B"
                    percentage >= 50.0 -> "C"
                    percentage >= 40.0 -> "D"
                    else -> "F"
                }

                StudentMark(
                    id = UUID.randomUUID().toString(),
                    testId = testId,
                    schoolId = currentSchoolId,
                    studentId = student.id,
                    studentName = student.name,
                    rollNumber = student.rollNumber,
                    classId = classId,
                    examName = testName.trim(),
                    subject = subject.trim(),
                    maxMarks = safeMaxMarks,
                    marksObtained = obtained,
                    percentage = percentage,
                    rank = rank,
                    grade = grade,
                    remarks = remarks?.trim()?.ifBlank { null },
                    date = date.trim()
                )
            }

            val schoolTest = SchoolTest(
                id = testId,
                schoolId = currentSchoolId,
                classId = classId,
                className = className,
                testName = testName.trim(),
                subject = subject.trim(),
                date = date.trim(),
                maxMarks = safeMaxMarks,
                createdByTeacherId = teacherId,
                createdByTeacherName = teacherName,
                totalStudents = totalStudents,
                averageScore = averageScore,
                highestScore = highestScore
            )

            // Save test record and marks
            database.testDao().insertTest(schoolTest)
            database.markDao().deleteMarksByTest(testId)
            database.markDao().insertMarks(marksToInsert)

            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = date.trim(),
                time = timeStr,
                timestamp = System.currentTimeMillis(),
                category = "MARKS_TESTS",
                personName = teacherName,
                personRole = "TEACHER",
                personId = teacherId,
                classId = classId,
                className = className,
                action = "Test & Results Recorded: $testName ($subject)",
                amount = null,
                marks = "Avg: ${String.format(Locale.getDefault(), "%.1f", averageScore)}% • Top: ${String.format(Locale.getDefault(), "%.1f", highestScore)}/$safeMaxMarks",
                details = "Class: $className • Subject: $subject • $totalStudents students evaluated. Top Rank #1: ${sortedList.firstOrNull()?.first?.name ?: "N/A"}",
                performedBy = teacherName
            )
            database.activityRecordDao().insertActivity(activity)

            Result.success(schoolTest)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTest(testId: String) = withContext(Dispatchers.IO) {
        database.markDao().deleteMarksByTest(testId)
        database.testDao().deleteTest(testId)
    }

    // --- Marks (School Isolated) ---
    fun getMarksByClass(classId: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByClass(currentSchoolId, classId)

    fun getMarksByTest(testId: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByTest(testId)

    fun getMarksByClassAndExam(classId: String, examName: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByClassAndExam(currentSchoolId, classId, examName)

    fun getMarksByStudent(studentId: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByStudent(studentId)

    fun getAllMarks(): Flow<List<StudentMark>> =
        database.markDao().getAllMarks(currentSchoolId)

    suspend fun insertMark(mark: StudentMark) = withContext(Dispatchers.IO) {
        database.markDao().insertMark(mark.copy(schoolId = currentSchoolId))
    }

    suspend fun insertMarks(marks: List<StudentMark>) = withContext(Dispatchers.IO) {
        val isolated = marks.map { it.copy(schoolId = currentSchoolId) }
        database.markDao().insertMarks(isolated)
    }

    suspend fun deleteMark(id: String) = withContext(Dispatchers.IO) {
        database.markDao().deleteMark(id)
    }

    // --- Fees Management (School Isolated) ---
    fun getAllStudentFees(): Flow<List<StudentFee>> =
        database.feeDao().getAllStudentFees(currentSchoolId)

    fun getFeesByClass(classId: String): Flow<List<StudentFee>> =
        database.feeDao().getFeesByClass(currentSchoolId, classId)

    fun getFeeForStudent(studentId: String): Flow<StudentFee?> =
        database.feeDao().getFeeForStudent(studentId)

    suspend fun setStudentTotalFee(
        student: Student,
        totalFee: Double
    ) = withContext(Dispatchers.IO) {
        val payments = database.feePaymentDao().getPaymentsByStudentDirect(student.id)
        val totalPaid = payments.sumOf { it.amount }
        val safeTotalFee = maxOf(0.0, totalFee)
        val remaining = maxOf(0.0, safeTotalFee - totalPaid)
        val status = when {
            remaining <= 0.0 && totalPaid > 0.0 -> "PAID"
            totalPaid > 0.0 -> "PARTIAL"
            else -> "UNPAID"
        }
        val lastDate = payments.maxByOrNull { it.timestamp }?.date

        val studentFee = StudentFee(
            studentId = student.id,
            schoolId = currentSchoolId,
            studentName = student.name,
            rollNumber = student.rollNumber,
            classId = student.classId,
            totalFee = safeTotalFee,
            totalPaid = totalPaid,
            remainingFee = remaining,
            status = status,
            lastPaymentDate = lastDate,
            updatedAt = System.currentTimeMillis()
        )
        database.feeDao().insertStudentFee(studentFee)
    }

    suspend fun recordFeePayment(
        student: Student,
        amount: Double,
        date: String,
        paymentMode: String,
        note: String,
        recordedBy: String
    ): Result<FeePayment> = withContext(Dispatchers.IO) {
        try {
            if (amount <= 0.0) {
                return@withContext Result.failure(IllegalArgumentException("Payment amount must be greater than 0"))
            }

            val school = database.schoolDao().getSchoolById(currentSchoolId)
            val curr = school?.currency ?: "₹"
            val receiptNo = "REC-${(100000..999999).random()}"
            val payment = FeePayment(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                studentId = student.id,
                studentName = student.name,
                rollNumber = student.rollNumber,
                classId = student.classId,
                amount = amount,
                currency = curr,
                date = date.trim(),
                paymentMode = paymentMode.trim().ifBlank { "Cash" },
                note = note.trim(),
                receiptNumber = receiptNo,
                recordedBy = recordedBy.trim().ifBlank { "School Administration" },
                timestamp = System.currentTimeMillis()
            )

            database.feePaymentDao().insertPayment(payment)

            // Recalculate fee balance for this student
            val allPayments = database.feePaymentDao().getPaymentsByStudentDirect(student.id)
            val totalPaid = allPayments.sumOf { it.amount }
            val existingFee = database.feeDao().getFeeForStudentDirect(student.id)
            val currentTotal = existingFee?.totalFee ?: 4500.0
            val remaining = maxOf(0.0, currentTotal - totalPaid)
            val status = when {
                remaining <= 0.0 -> "PAID"
                totalPaid > 0.0 -> "PARTIAL"
                else -> "UNPAID"
            }

            val updatedFee = StudentFee(
                studentId = student.id,
                schoolId = currentSchoolId,
                studentName = student.name,
                rollNumber = student.rollNumber,
                classId = student.classId,
                totalFee = currentTotal,
                totalPaid = totalPaid,
                remainingFee = remaining,
                currency = curr,
                status = status,
                lastPaymentDate = date.trim(),
                updatedAt = System.currentTimeMillis()
            )
            database.feeDao().insertStudentFee(updatedFee)

            // Log activity in school history
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = date.trim(),
                time = timeStr,
                timestamp = System.currentTimeMillis(),
                category = "FEE_PAYMENT",
                personName = student.name,
                personRole = "STUDENT",
                personId = student.id,
                classId = student.classId,
                className = "",
                action = "Fee Payment Collected ($receiptNo)",
                amount = amount,
                marks = null,
                details = "Received $curr${String.format(Locale.getDefault(), "%.2f", amount)} via $paymentMode. Receipt: $receiptNo. Remaining: $curr${String.format(Locale.getDefault(), "%.2f", remaining)}. Status: $status. Note: $note",
                performedBy = payment.recordedBy
            )
            database.activityRecordDao().insertActivity(activity)

            Result.success(payment)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getPaymentsByStudent(studentId: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getPaymentsByStudent(studentId)

    fun getPaymentsByClass(classId: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getPaymentsByClass(currentSchoolId, classId)

    fun getAllPayments(): Flow<List<FeePayment>> =
        database.feePaymentDao().getAllPayments(currentSchoolId)

    suspend fun deleteFeePayment(paymentId: String, studentId: String) = withContext(Dispatchers.IO) {
        database.feePaymentDao().deletePayment(paymentId)
        val allPayments = database.feePaymentDao().getPaymentsByStudentDirect(studentId)
        val totalPaid = allPayments.sumOf { it.amount }
        val existingFee = database.feeDao().getFeeForStudentDirect(studentId)
        if (existingFee != null) {
            val remaining = maxOf(0.0, existingFee.totalFee - totalPaid)
            val status = when {
                remaining <= 0.0 && totalPaid > 0.0 -> "PAID"
                totalPaid > 0.0 -> "PARTIAL"
                else -> "UNPAID"
            }
            database.feeDao().updateStudentFee(
                existingFee.copy(
                    totalPaid = totalPaid,
                    remainingFee = remaining,
                    status = status,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    // --- Teacher Salaries (School Isolated & Role Protected) ---
    fun getAllSalaries(): Flow<List<TeacherSalary>> =
        database.teacherSalaryDao().getAllSalaries(currentSchoolId)

    fun getSalariesForTeacher(teacherId: String): Flow<List<TeacherSalary>> =
        database.teacherSalaryDao().getSalariesForTeacher(currentSchoolId, teacherId)

    fun getSalariesByMonth(month: String): Flow<List<TeacherSalary>> =
        database.teacherSalaryDao().getSalariesByMonth(currentSchoolId, month)

    suspend fun recordTeacherSalary(
        teacherId: String,
        teacherName: String,
        month: String,
        monthlySalary: Double,
        amountPaid: Double,
        paymentDate: String,
        remainingAmount: Double,
        paymentMode: String,
        transactionRef: String,
        remarks: String,
        recordedBy: String
    ): Result<TeacherSalary> = withContext(Dispatchers.IO) {
        try {
            if (monthlySalary < 0.0 || amountPaid < 0.0) {
                return@withContext Result.failure(IllegalArgumentException("Salary amounts cannot be negative"))
            }
            val safeRemaining = if (remainingAmount >= 0.0) remainingAmount else maxOf(0.0, monthlySalary - amountPaid)
            val status = when {
                safeRemaining <= 0.0 && amountPaid > 0.0 -> "PAID"
                amountPaid > 0.0 -> "PARTIAL"
                else -> "PENDING"
            }

            val school = database.schoolDao().getSchoolById(currentSchoolId)
            val curr = school?.currency ?: "₹"

            val salary = TeacherSalary(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                teacherId = teacherId,
                teacherName = teacherName,
                month = month.trim(),
                monthlySalary = monthlySalary,
                amountPaid = amountPaid,
                paymentDate = paymentDate.trim(),
                remainingAmount = safeRemaining,
                currency = curr,
                paymentMode = paymentMode.trim().ifBlank { "Bank Transfer" },
                transactionRef = transactionRef.trim(),
                remarks = remarks.trim(),
                status = status,
                recordedBy = recordedBy.trim().ifBlank { "Principal" },
                timestamp = System.currentTimeMillis()
            )

            database.teacherSalaryDao().insertSalary(salary)

            // Log activity in school history
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = paymentDate.trim(),
                time = timeStr,
                timestamp = System.currentTimeMillis(),
                category = "SALARY_PAYMENT",
                personName = teacherName,
                personRole = "TEACHER",
                personId = teacherId,
                classId = "",
                className = "",
                action = "Teacher Salary Disbursed ($month)",
                amount = amountPaid,
                marks = null,
                details = "Monthly Salary: $curr${String.format(Locale.getDefault(), "%.2f", monthlySalary)} • Amount Paid: $curr${String.format(Locale.getDefault(), "%.2f", amountPaid)} • Remaining: $curr${String.format(Locale.getDefault(), "%.2f", safeRemaining)} • Mode: $paymentMode • Ref: $transactionRef • Remarks: $remarks",
                performedBy = salary.recordedBy
            )
            database.activityRecordDao().insertActivity(activity)

            Result.success(salary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTeacherSalary(id: String) = withContext(Dispatchers.IO) {
        database.teacherSalaryDao().deleteSalary(id)
    }

    // --- School Activity & Operations History ---
    fun getAllActivities(): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getAllActivities(currentSchoolId)

    fun getActivitiesByCategory(category: String): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getActivitiesByCategory(currentSchoolId, category)

    fun getActivitiesByClass(classId: String): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getActivitiesByClass(currentSchoolId, classId)

    fun getActivitiesByPerson(personId: String): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getActivitiesByPerson(currentSchoolId, personId)

    suspend fun logActivity(activity: ActivityRecord) = withContext(Dispatchers.IO) {
        database.activityRecordDao().insertActivity(activity.copy(schoolId = currentSchoolId))
    }

    suspend fun deleteActivity(id: String) = withContext(Dispatchers.IO) {
        database.activityRecordDao().deleteActivity(id)
    }

    // --- Announcements (School Isolated) ---
    fun getAnnouncementsForClass(classId: String): Flow<List<Announcement>> =
        database.announcementDao().getAnnouncementsForClass(currentSchoolId, classId)

    fun getAllAnnouncements(): Flow<List<Announcement>> =
        database.announcementDao().getAllAnnouncements(currentSchoolId)

    suspend fun insertAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        val isolatedAnnouncement = announcement.copy(schoolId = currentSchoolId)
        database.announcementDao().insertAnnouncement(isolatedAnnouncement)

        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = isolatedAnnouncement.date.ifBlank { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) },
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = "ANNOUNCEMENT",
            personName = isolatedAnnouncement.authorName,
            personRole = "PRINCIPAL",
            personId = "",
            classId = isolatedAnnouncement.targetAudience,
            className = if (isolatedAnnouncement.targetAudience == "ALL") "All Classes" else isolatedAnnouncement.targetAudience,
            action = "Notice Broadcasted: ${isolatedAnnouncement.title}",
            amount = null,
            marks = null,
            details = "Priority: ${isolatedAnnouncement.priority} • Target: ${isolatedAnnouncement.targetAudience} • Content: ${isolatedAnnouncement.content}",
            performedBy = isolatedAnnouncement.authorName
        )
        database.activityRecordDao().insertActivity(activity)
    }

    suspend fun deleteAnnouncement(id: String) = withContext(Dispatchers.IO) {
        database.announcementDao().deleteAnnouncement(id)
    }

    // --- Leaves (School Isolated) ---
    fun getAllLeaveRequests(): Flow<List<LeaveRequest>> =
        database.leaveDao().getAllLeaveRequests(currentSchoolId)

    fun getLeaveRequestsByTeacher(teacherId: String): Flow<List<LeaveRequest>> =
        database.leaveDao().getLeaveRequestsByTeacher(teacherId)

    fun getPendingLeaveRequests(): Flow<List<LeaveRequest>> =
        database.leaveDao().getPendingLeaveRequests(currentSchoolId)

    suspend fun insertLeaveRequest(request: LeaveRequest) = withContext(Dispatchers.IO) {
        database.leaveDao().insertLeaveRequest(request.copy(schoolId = currentSchoolId))
    }

    suspend fun updateLeaveStatus(id: String, status: String, comment: String?) = withContext(Dispatchers.IO) {
        database.leaveDao().updateLeaveStatus(id, status, comment)

        val req = database.leaveDao().getLeaveRequestById(id)
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = "LEAVE_REQUEST",
            personName = req?.teacherName ?: "Teacher",
            personRole = "TEACHER",
            personId = req?.teacherId ?: "",
            classId = "",
            className = "",
            action = "Leave Request $status",
            amount = null,
            marks = null,
            details = "Leave Type: ${req?.leaveType ?: "Leave"} • Duration: ${req?.daysCount ?: 1} day(s) (${req?.startDate} to ${req?.endDate}). Reason: ${req?.reason}. Remark: ${comment ?: "No remarks"}",
            performedBy = "Principal"
        )
        database.activityRecordDao().insertActivity(activity)
    }

    suspend fun deleteLeaveRequest(id: String) = withContext(Dispatchers.IO) {
        database.leaveDao().deleteLeaveRequest(id)
    }

    // --- Chat Messages (School & Student Isolated, Cloud Synchronized) ---
    fun getMessagesForStudent(studentId: String): Flow<List<ChatMessage>> =
        database.chatMessageDao().getMessagesForStudent(currentSchoolId, studentId)

    fun getMessagesForUser(userId: String): Flow<List<ChatMessage>> =
        database.chatMessageDao().getMessagesForUser(currentSchoolId, userId)

    fun getAllMessagesForSchool(): Flow<List<ChatMessage>> =
        database.chatMessageDao().getAllMessagesForSchool(currentSchoolId)

    suspend fun sendMessage(message: ChatMessage): Result<ChatMessage> = withContext(Dispatchers.IO) {
        val isolatedMessage = message.copy(schoolId = currentSchoolId)

        // 1. Sync to cloud database
        val cloudRes = cloudService.sendCloudMessage(isolatedMessage)

        // 2. Persist to local database
        database.chatMessageDao().insertMessage(isolatedMessage)
        Result.success(isolatedMessage)
    }

    suspend fun syncMessagesFromCloud(studentId: String) = withContext(Dispatchers.IO) {
        val cloudMsgs = cloudService.getCloudMessages(currentSchoolId, studentId)
        if (cloudMsgs.isNotEmpty()) {
            database.chatMessageDao().insertMessages(cloudMsgs)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: SchoolRepository? = null

        fun getInstance(context: Context): SchoolRepository {
            return INSTANCE ?: synchronized(this) {
                val db = AppDatabase.getDatabase(context)
                val session = SessionManager.getInstance(context)
                val cloud = CloudDatabaseService.getInstance(context)
                INSTANCE ?: SchoolRepository(db, session, cloud).also { INSTANCE = it }
            }
        }
    }
}
