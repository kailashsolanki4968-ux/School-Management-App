package com.example.data.security

import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64

object PasswordSecurity {

    fun generateSalt(): String {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }

    fun hashPassword(password: String, salt: String): String {
        val input = password + salt
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(password: String, salt: String, expectedHash: String): Boolean {
        // If salt is empty (legacy fallback), hash password directly or compare
        if (salt.isEmpty()) {
            val directHash = MessageDigest.getInstance("SHA-256")
                .digest(password.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
            return directHash == expectedHash || password == expectedHash
        }
        val computedHash = hashPassword(password, salt)
        return computedHash == expectedHash
    }

    fun hashSecurityAnswer(answer: String): String {
        val normalized = answer.trim().lowercase()
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(normalized.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    fun verifySecurityAnswer(answer: String, storedHashOrAnswer: String): Boolean {
        val normalized = answer.trim().lowercase()
        val computedHash = MessageDigest.getInstance("SHA-256")
            .digest(normalized.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return computedHash == storedHashOrAnswer || normalized == storedHashOrAnswer.trim().lowercase()
    }
}
