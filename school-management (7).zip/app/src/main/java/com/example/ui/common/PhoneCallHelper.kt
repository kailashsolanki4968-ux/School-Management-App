package com.example.ui.common

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object PhoneCallHelper {
    /**
     * Initiates a phone call via the Android dialer with the exact saved contact number.
     * Uses Intent.ACTION_DIAL so that the user can confirm before placing the call using
     * their device's active SIM card without needing dangerous CALL_PHONE permissions.
     * Never uses hard-coded phone numbers.
     * If a number is missing, shows "Phone number not available."
     */
    fun dialExactNumber(context: Context, rawNumber: String, contactName: String = "Contact") {
        val trimmed = rawNumber.trim()
        if (trimmed.isBlank()) {
            Toast.makeText(context, "Phone number not available.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${Uri.encode(trimmed)}")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open phone dialer on this device.", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Opens the SMS composer with that student's saved parent phone number.
     * Uses Intent.ACTION_SENDTO with "smsto:<number>" URI.
     * Never uses hard-coded phone numbers.
     * If a number is missing, shows "Phone number not available."
     */
    fun messageExactNumber(context: Context, rawNumber: String, defaultMessage: String = "") {
        val trimmed = rawNumber.trim()
        if (trimmed.isBlank()) {
            Toast.makeText(context, "Phone number not available.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:${Uri.encode(trimmed)}")
                if (defaultMessage.isNotBlank()) {
                    putExtra("sms_body", defaultMessage)
                }
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open SMS composer on this device.", Toast.LENGTH_LONG).show()
        }
    }
}
