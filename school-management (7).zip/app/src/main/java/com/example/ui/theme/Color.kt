package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val PrimaryNavy = Color(0xFF1E3A8A)
val PrimaryNavyDark = Color(0xFF0F172A)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE)
val OnPrimaryContainerLight = Color(0xFF1E3A8A)

val SecondaryAmber = Color(0xFFD97706)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFEF3C7)
val OnSecondaryContainerLight = Color(0xFF78350F)

val TertiaryTeal = Color(0xFF0D9488)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFCCFBF1)
val OnTertiaryContainerLight = Color(0xFF115E59)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Palette
val PrimaryDark = Color(0xFF93C5FD)
val OnPrimaryDark = Color(0xFF1E3A8A)
val PrimaryContainerDark = Color(0xFF1E40AF)
val OnPrimaryContainerDark = Color(0xFFDBEAFE)

val SecondaryDark = Color(0xFFFCD34D)
val OnSecondaryDark = Color(0xFF78350F)
val SecondaryContainerDark = Color(0xFF92400E)
val OnSecondaryContainerDark = Color(0xFFFEF3C7)

val TertiaryDark = Color(0xFF5EEAD4)
val OnTertiaryDark = Color(0xFF115E59)
val TertiaryContainerDark = Color(0xFF134E4A)
val OnTertiaryContainerDark = Color(0xFFCCFBF1)

val BackgroundDark = Color(0xFF0B1120)
val SurfaceDark = Color(0xFF111827)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)

// Status colors
val StatusPresent = Color(0xFF10B981)
val StatusPresentBg = Color(0xFFD1FAE5)
val StatusAbsent = Color(0xFFEF4444)
val StatusAbsentBg = Color(0xFFFEE2E2)
val StatusLate = Color(0xFFF59E0B)
val StatusLateBg = Color(0xFFFEF3C7)
val StatusExcused = Color(0xFF3B82F6)
val StatusExcusedBg = Color(0xFFDBEAFE)
