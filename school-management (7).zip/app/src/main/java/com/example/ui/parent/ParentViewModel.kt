package com.example.ui.parent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.School
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.data.session.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class ParentTab {
    OVERVIEW,
    MESSAGES,
    ATTENDANCE,
    HOMEWORK,
    MARKS,
    FEES,
    ANNOUNCEMENTS,
    PROFILE
}

data class ChildAttendanceStats(
    val totalDays: Int = 0,
    val presentDays: Int = 0,
    val absentDays: Int = 0,
    val lateDays: Int = 0,
    val excusedDays: Int = 0,
    val percentage: Double = 0.0
)

class ParentViewModel(
    val repository: SchoolRepository,
    val parentId: String
) : ViewModel() {

    val sessionState: StateFlow<UserSession?> = repository.sessionState

    private val _currentTab = MutableStateFlow(ParentTab.OVERVIEW)
    val currentTab: StateFlow<ParentTab> = _currentTab.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    val parentProfile: StateFlow<UserAccount?> = repository.getUserByIdFlow(parentId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // School Details
    val schoolDetails: StateFlow<School?> = repository.getSchoolByIdFlow(repository.currentSchoolId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Linked children
    val linkedChildren: StateFlow<List<Student>> = parentProfile.flatMapLatest { profile ->
        if (profile == null) return@flatMapLatest flowOf(emptyList())
        val ids = profile.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (ids.isNotEmpty()) {
            repository.getStudentsByIdsFlow(ids)
        } else {
            // Fallback: search all students for this school
            repository.getAllStudents().map { all ->
                all.filter { it.parentUserId == parentId || it.parentName.equals(profile.name, ignoreCase = true) }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedChildId = MutableStateFlow<String?>(null)
    val selectedChildId: StateFlow<String?> = _selectedChildId.asStateFlow()

    val selectedChild: StateFlow<Student?> = kotlinx.coroutines.flow.combine(
        linkedChildren,
        _selectedChildId
    ) { children, selectedId ->
        if (children.isEmpty()) null
        else if (selectedId != null) children.find { it.id == selectedId } ?: children.firstOrNull()
        else children.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Class info
    val childClass: StateFlow<SchoolClass?> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getClassByIdFlow(child.classId)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Class Teacher
    val classTeacher: StateFlow<UserAccount?> = childClass.flatMapLatest { cls ->
        if (cls?.classTeacherId != null) repository.getUserByIdFlow(cls.classTeacherId)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Attendance history
    val childAttendanceHistory: StateFlow<List<AttendanceRecord>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getAttendanceForStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Child Attendance Stats
    val attendanceStats: StateFlow<ChildAttendanceStats> = childAttendanceHistory.map { records ->
        if (records.isEmpty()) {
            ChildAttendanceStats()
        } else {
            val total = records.size
            val present = records.count { it.status == "PRESENT" }
            val absent = records.count { it.status == "ABSENT" }
            val late = records.count { it.status == "LATE" }
            val excused = records.count { it.status == "EXCUSED" }
            val pct = if (total > 0) ((present + late * 0.5) / total) * 100.0 else 0.0
            ChildAttendanceStats(
                totalDays = total,
                presentDays = present,
                absentDays = absent,
                lateDays = late,
                excusedDays = excused,
                percentage = pct
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChildAttendanceStats())

    // Selected child's Homework
    val childHomework: StateFlow<List<Homework>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getHomeworkByClass(child.classId)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected child's Marks
    val childMarks: StateFlow<List<StudentMark>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getMarksByStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected child's Fee Status
    val childFee: StateFlow<StudentFee?> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getFeeForStudent(child.id)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Fee Payment Receipts
    val childFeePayments: StateFlow<List<FeePayment>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getPaymentsByStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // School Announcements
    val announcements: StateFlow<List<Announcement>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getAnnouncementsForClass(child.classId)
        else repository.getAllAnnouncements()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Child Messages with School Staff
    val childMessages: StateFlow<List<ChatMessage>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getMessagesForStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun sendMessageToSchool(messageText: String) {
        val child = selectedChild.value ?: return
        val profile = parentProfile.value ?: return
        val teacher = classTeacher.value
        val recipientId = teacher?.id ?: "PRIN001"
        val recipientName = teacher?.name ?: "School Administration"
        val recipientRole = if (teacher != null) UserRole.TEACHER.name else UserRole.PRINCIPAL.name

        viewModelScope.launch {
            val chatMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                schoolId = repository.currentSchoolId,
                studentId = child.id,
                studentName = child.name,
                senderId = parentId,
                senderName = profile.name,
                senderRole = UserRole.PARENT.name,
                receiverId = recipientId,
                receiverName = recipientName,
                receiverRole = recipientRole,
                message = messageText.trim(),
                timestamp = System.currentTimeMillis(),
                status = "DELIVERED"
            )
            repository.sendMessage(chatMsg)
        }
    }


    fun selectTab(tab: ParentTab) {
        _currentTab.value = tab
    }

    fun selectChild(childId: String) {
        _selectedChildId.value = childId
    }

    fun clearMessage() {
        _message.value = null
    }

    fun changePassword(newPassword: String) {
        if (newPassword.length < 6) {
            _message.value = "New password must be at least 6 characters"
            return
        }
        viewModelScope.launch {
            repository.directUpdatePassword(parentId, newPassword)
            _message.value = "Password updated successfully!"
        }
    }

    fun logout() {
        repository.logout()
    }
}

class ParentViewModelFactory(
    private val repository: SchoolRepository,
    private val parentId: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ParentViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ParentViewModel(repository, parentId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
