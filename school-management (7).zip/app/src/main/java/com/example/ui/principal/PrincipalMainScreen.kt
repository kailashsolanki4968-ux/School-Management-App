package com.example.ui.principal

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Verified
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.SchoolClass
import com.example.data.model.SchoolTest
import com.example.data.model.Student
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.ui.chat.StudentParentChatDialog
import com.example.ui.common.PhoneCallHelper
import com.example.ui.principal.ParentLinkingDialog
import com.example.ui.teacher.TestResultsDetailDialog
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusAbsentBg
import com.example.ui.theme.StatusLate
import com.example.ui.theme.StatusLateBg
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.StatusPresentBg
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalMainScreen(
    viewModel: PrincipalViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val pendingTeachers by viewModel.pendingTeachers.collectAsStateWithLifecycle()
    val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isTablet = maxWidth >= 720.dp

        if (isTablet) {
            // Tablet Navigation Rail Layout
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Principal",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    },
                    modifier = Modifier.fillMaxHeight()
                ) {
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.DASHBOARD,
                        onClick = { viewModel.selectTab(PrincipalTab.DASHBOARD) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                        label = { Text("Dashboard") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.TEACHERS,
                        onClick = { viewModel.selectTab(PrincipalTab.TEACHERS) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (pendingTeachers.isNotEmpty()) {
                                        Badge { Text("${pendingTeachers.size}") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Badge, contentDescription = "Teachers")
                            }
                        },
                        label = { Text("Teachers") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.CLASSES_STUDENTS,
                        onClick = { viewModel.selectTab(PrincipalTab.CLASSES_STUDENTS) },
                        icon = { Icon(Icons.Default.Class, contentDescription = "Classes") },
                        label = { Text("Classes") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.ATTENDANCE,
                        onClick = { viewModel.selectTab(PrincipalTab.ATTENDANCE) },
                        icon = { Icon(Icons.Default.HowToReg, contentDescription = "Attendance") },
                        label = { Text("Attendance") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.ACADEMICS,
                        onClick = { viewModel.selectTab(PrincipalTab.ACADEMICS) },
                        icon = { Icon(Icons.Default.Grade, contentDescription = "Academics") },
                        label = { Text("Academics") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.FEES,
                        onClick = { viewModel.selectTab(PrincipalTab.FEES) },
                        icon = { Icon(Icons.Default.Payments, contentDescription = "Fees") },
                        label = { Text("Fees") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.HISTORY,
                        onClick = { viewModel.selectTab(PrincipalTab.HISTORY) },
                        icon = { Icon(Icons.Default.History, contentDescription = "History") },
                        label = { Text("History") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.LEAVES,
                        onClick = { viewModel.selectTab(PrincipalTab.LEAVES) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (pendingLeaves.isNotEmpty()) {
                                        Badge { Text("${pendingLeaves.size}") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.EventNote, contentDescription = "Leaves")
                            }
                        },
                        label = { Text("Leaves") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.ANNOUNCEMENTS,
                        onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) },
                        icon = { Icon(Icons.Default.Campaign, contentDescription = "Announcements") },
                        label = { Text("Notices") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.SETTINGS,
                        onClick = { viewModel.selectTab(PrincipalTab.SETTINGS) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") }
                    )
                }

                // Content for Tablet
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = getPrincipalTabTitle(currentTab),
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Logged in as ${session?.name ?: "Principal"} (ID: ${session?.userId ?: ""})",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = { viewModel.logout() },
                                    modifier = Modifier.testTag("btn_logout")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ExitToApp,
                                        contentDescription = "Logout",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    PrincipalTabContent(
                        currentTab = currentTab,
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        } else {
            // Phone Layout with Bottom Navigation Bar
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = getPrincipalTabTitle(currentTab),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Principal: ${session?.name ?: "Admin"}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { viewModel.logout() },
                                modifier = Modifier.testTag("btn_logout")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = "Logout",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.DASHBOARD,
                            onClick = { viewModel.selectTab(PrincipalTab.DASHBOARD) },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                            label = { Text("Home", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.TEACHERS,
                            onClick = { viewModel.selectTab(PrincipalTab.TEACHERS) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (pendingTeachers.isNotEmpty()) {
                                            Badge { Text("${pendingTeachers.size}") }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Badge, contentDescription = "Teachers")
                                }
                            },
                            label = { Text("Teachers", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.CLASSES_STUDENTS,
                            onClick = { viewModel.selectTab(PrincipalTab.CLASSES_STUDENTS) },
                            icon = { Icon(Icons.Default.Class, contentDescription = "Classes") },
                            label = { Text("Classes", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.ATTENDANCE,
                            onClick = { viewModel.selectTab(PrincipalTab.ATTENDANCE) },
                            icon = { Icon(Icons.Default.HowToReg, contentDescription = "Attendance") },
                            label = { Text("Attendance", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab in listOf(
                                PrincipalTab.HISTORY,
                                PrincipalTab.LEAVES,
                                PrincipalTab.ACADEMICS,
                                PrincipalTab.FEES,
                                PrincipalTab.ANNOUNCEMENTS,
                                PrincipalTab.SETTINGS
                            ),
                            onClick = {
                                if (currentTab !in listOf(
                                        PrincipalTab.HISTORY,
                                        PrincipalTab.LEAVES,
                                        PrincipalTab.ACADEMICS,
                                        PrincipalTab.FEES,
                                        PrincipalTab.ANNOUNCEMENTS,
                                        PrincipalTab.SETTINGS
                                    )
                                ) {
                                    viewModel.selectTab(PrincipalTab.HISTORY)
                                }
                            },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (pendingLeaves.isNotEmpty()) {
                                            Badge { Text("${pendingLeaves.size}") }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.History, contentDescription = "More / History")
                                }
                            },
                            label = { Text("History & More", fontSize = 10.sp) }
                        )
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                PrincipalTabContent(
                    currentTab = currentTab,
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}

private fun getPrincipalTabTitle(tab: PrincipalTab): String {
    return when (tab) {
        PrincipalTab.DASHBOARD -> "School Dashboard"
        PrincipalTab.TEACHERS -> "Teacher Management"
        PrincipalTab.CLASSES_STUDENTS -> "Classes & Students"
        PrincipalTab.ATTENDANCE -> "Attendance Overview"
        PrincipalTab.ACADEMICS -> "Homework & Marks"
        PrincipalTab.FEES -> "Fee Management & Records"
        PrincipalTab.HISTORY -> "School History & Operation Logs"
        PrincipalTab.LEAVES -> "Teacher Leave Requests"
        PrincipalTab.ANNOUNCEMENTS -> "School Announcements"
        PrincipalTab.SETTINGS -> "Settings & Security"
    }
}

@Composable
fun PrincipalTabContent(
    currentTab: PrincipalTab,
    viewModel: PrincipalViewModel,
    modifier: Modifier = Modifier
) {
    // Secondary sub-tab row for phone when on "More" tab (History, Leaves, Academics, Fees, Announcements, Settings)
    val isSecondaryTab = currentTab in listOf(
        PrincipalTab.HISTORY,
        PrincipalTab.LEAVES,
        PrincipalTab.ACADEMICS,
        PrincipalTab.FEES,
        PrincipalTab.ANNOUNCEMENTS,
        PrincipalTab.SETTINGS
    )

    Column(modifier = modifier.fillMaxSize()) {
        if (isSecondaryTab) {
            val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()
            ScrollableTabRow(
                selectedTabIndex = when (currentTab) {
                    PrincipalTab.HISTORY -> 0
                    PrincipalTab.LEAVES -> 1
                    PrincipalTab.ACADEMICS -> 2
                    PrincipalTab.FEES -> 3
                    PrincipalTab.ANNOUNCEMENTS -> 4
                    PrincipalTab.SETTINGS -> 5
                    else -> 0
                },
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth(),
                edgePadding = 12.dp
            ) {
                Tab(
                    selected = currentTab == PrincipalTab.HISTORY,
                    onClick = { viewModel.selectTab(PrincipalTab.HISTORY) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("History", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
                Tab(
                    selected = currentTab == PrincipalTab.LEAVES,
                    onClick = { viewModel.selectTab(PrincipalTab.LEAVES) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Leaves", fontSize = 12.sp)
                            if (pendingLeaves.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.error)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "${pendingLeaves.size}",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                )
                Tab(
                    selected = currentTab == PrincipalTab.ACADEMICS,
                    onClick = { viewModel.selectTab(PrincipalTab.ACADEMICS) },
                    text = { Text("Academics", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == PrincipalTab.FEES,
                    onClick = { viewModel.selectTab(PrincipalTab.FEES) },
                    text = { Text("Fees", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == PrincipalTab.ANNOUNCEMENTS,
                    onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) },
                    text = { Text("Notices", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == PrincipalTab.SETTINGS,
                    onClick = { viewModel.selectTab(PrincipalTab.SETTINGS) },
                    text = { Text("Settings", fontSize = 12.sp) }
                )
            }
        }

        when (currentTab) {
            PrincipalTab.DASHBOARD -> PrincipalDashboardView(viewModel)
            PrincipalTab.TEACHERS -> PrincipalTeachersView(viewModel)
            PrincipalTab.CLASSES_STUDENTS -> PrincipalClassesStudentsView(viewModel)
            PrincipalTab.ATTENDANCE -> PrincipalAttendanceView(viewModel)
            PrincipalTab.ACADEMICS -> PrincipalAcademicsView(viewModel)
            PrincipalTab.FEES -> PrincipalFeesView(viewModel)
            PrincipalTab.HISTORY -> PrincipalHistoryView(viewModel)
            PrincipalTab.LEAVES -> PrincipalLeavesView(viewModel)
            PrincipalTab.ANNOUNCEMENTS -> PrincipalAnnouncementsView(viewModel)
            PrincipalTab.SETTINGS -> PrincipalSettingsView(viewModel)
        }
    }
}

// ---------------- DASHBOARD VIEW ----------------

@Composable
fun PrincipalDashboardView(viewModel: PrincipalViewModel) {
    val teachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val pendingTeachers by viewModel.pendingTeachers.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val students by viewModel.allStudents.collectAsStateWithLifecycle()
    val attendanceSummary by viewModel.attendanceSummary.collectAsStateWithLifecycle()
    val absentStudents by viewModel.todayAbsentStudents.collectAsStateWithLifecycle()
    val announcements by viewModel.allAnnouncements.collectAsStateWithLifecycle()
    val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()
    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val principalProfile by viewModel.principalProfile.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var selectedStudentForChat by remember { mutableStateOf<Student?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Pending action alerts
        if (pendingTeachers.isNotEmpty() || pendingLeaves.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Action Required",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (pendingTeachers.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectTab(PrincipalTab.TEACHERS) }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${pendingTeachers.size} new Teacher registration(s) awaiting your approval",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                )
                                Text(
                                    text = "Review >",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }
                        if (pendingLeaves.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectTab(PrincipalTab.LEAVES) }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${pendingLeaves.size} Teacher leave request(s) awaiting decision",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                )
                                Text(
                                    text = "Review >",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Summary KPI Cards Grid
        item {
            Text(
                text = "Key Metrics",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Students",
                    value = "${students.size}",
                    icon = Icons.Default.Group,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Active Classes",
                    value = "${classes.size}",
                    icon = Icons.Default.Class,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Teachers",
                    value = "${teachers.size}",
                    icon = Icons.Default.Badge,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Today's Attendance",
                    value = if (attendanceSummary.totalEnrolled > 0) String.format(Locale.US, "%.1f%%", attendanceSummary.attendancePercentage) else "N/A",
                    icon = Icons.Default.HowToReg,
                    color = if (attendanceSummary.attendancePercentage >= 85) StatusPresent else StatusLate,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Navigation Buttons
        item {
            Text(
                text = "Quick Actions",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.selectTab(PrincipalTab.HISTORY) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("History Logs", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = { viewModel.selectTab(PrincipalTab.TEACHERS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Teachers", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { viewModel.selectTab(PrincipalTab.CLASSES_STUDENTS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Class, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Classes", fontSize = 12.sp)
                }
            }
        }

        // Absent Students Highlight
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Absent Students (${absentStudents.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(onClick = { viewModel.selectTab(PrincipalTab.ATTENDANCE) }) {
                    Text("Full Roster >")
                }
            }

            if (absentStudents.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✅ All recorded students are present today or attendance not yet marked.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    absentStudents.take(5).forEach { record ->
                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(StatusAbsentBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "A",
                                            color = StatusAbsent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = record.studentName,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                                        )
                                        Text(
                                            text = "Class: ${record.classId} • Roll: ${record.rollNumber}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                        record.remarks?.let {
                                            Text(
                                                text = "Note: $it",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            )
                                        }
                                    }
                                }

                                // Quick Contact / Call / Message parent buttons
                                val targetStudent = students.find { it.id == record.studentId }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val phoneToDial = targetStudent?.parentPhone?.ifBlank { null } ?: targetStudent?.emergencyContact?.ifBlank { null }
                                            phoneToDial?.let { num ->
                                                PhoneCallHelper.dialExactNumber(context, num, "${record.studentName}'s Parent")
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Call", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            targetStudent?.let { selectedStudentForChat = it }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = "Message", modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Chat", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent School Announcements
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Announcements",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) }) {
                    Text("View All >")
                }
            }

            if (announcements.isEmpty()) {
                Text(
                    text = "No active announcements.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    announcements.take(3).forEach { ann ->
                        AnnouncementItemCard(announcement = ann, onDelete = { viewModel.deleteAnnouncement(ann.id) })
                    }
                }
            }
        }
    }

    // Student Parent Chat Dialog
    selectedStudentForChat?.let { student ->
        StudentParentChatDialog(
            student = student,
            repository = viewModel.repository,
            currentUserId = principalProfile?.id ?: session?.userId ?: "PRIN001",
            currentUserName = principalProfile?.name ?: session?.name ?: "Principal",
            currentUserRole = UserRole.PRINCIPAL.name,
            onDismiss = { selectedStudentForChat = null }
        )
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

// ---------------- TEACHERS & PARENTS MANAGEMENT VIEW ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalTeachersView(viewModel: PrincipalViewModel) {
    val allTeachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val pendingTeachers by viewModel.pendingTeachers.collectAsStateWithLifecycle()
    val approvedTeachers by viewModel.approvedTeachers.collectAsStateWithLifecycle()
    val allParents by viewModel.allParents.collectAsStateWithLifecycle()
    val pendingParents by viewModel.pendingParents.collectAsStateWithLifecycle()
    val approvedParents by viewModel.approvedParents.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val students by viewModel.allStudents.collectAsStateWithLifecycle()

    val context = LocalContext.current

    var mainSection by remember { mutableStateOf("TEACHERS") } // TEACHERS, PARENTS
    var filterMode by remember { mutableStateOf("ALL") } // ALL, PENDING, APPROVED
    var showAddTeacherDialog by remember { mutableStateOf(false) }
    var teacherToAssignClass by remember { mutableStateOf<UserAccount?>(null) }
    var teacherToResetPassword by remember { mutableStateOf<UserAccount?>(null) }
    var parentToDelete by remember { mutableStateOf<UserAccount?>(null) }

    val displayedTeachers = when (filterMode) {
        "PENDING" -> pendingTeachers
        "APPROVED" -> approvedTeachers
        else -> allTeachers
    }

    val displayedParents = when (filterMode) {
        "PENDING" -> pendingParents
        "APPROVED" -> approvedParents
        else -> allParents
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Main Switcher: Teachers vs Parents
            TabRow(
                selectedTabIndex = if (mainSection == "TEACHERS") 0 else 1,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = mainSection == "TEACHERS",
                    onClick = {
                        mainSection = "TEACHERS"
                        filterMode = "ALL"
                    },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Teachers (${allTeachers.size})", fontWeight = FontWeight.SemiBold)
                            if (pendingTeachers.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.error)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("${pendingTeachers.size}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                )
                Tab(
                    selected = mainSection == "PARENTS",
                    onClick = {
                        mainSection = "PARENTS"
                        filterMode = "ALL"
                    },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Parents (${allParents.size})", fontWeight = FontWeight.SemiBold)
                            if (pendingParents.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.error)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("${pendingParents.size}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val totalCount = if (mainSection == "TEACHERS") allTeachers.size else allParents.size
                val pendingCount = if (mainSection == "TEACHERS") pendingTeachers.size else pendingParents.size
                val activeCount = if (mainSection == "TEACHERS") approvedTeachers.size else approvedParents.size

                FilterChip(
                    selected = filterMode == "ALL",
                    onClick = { filterMode = "ALL" },
                    label = { Text("All ($totalCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
                FilterChip(
                    selected = filterMode == "PENDING",
                    onClick = { filterMode = "PENDING" },
                    label = { Text("Pending ($pendingCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.errorContainer
                    )
                )
                FilterChip(
                    selected = filterMode == "APPROVED",
                    onClick = { filterMode = "APPROVED" },
                    label = { Text("Active ($activeCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (mainSection == "TEACHERS") {
                if (displayedTeachers.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No teachers found in this filter category.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(displayedTeachers, key = { it.id }) { teacher ->
                            TeacherManagementCard(
                                teacher = teacher,
                                classes = classes,
                                onApprove = { viewModel.approveTeacher(teacher.id) },
                                onReject = { viewModel.rejectTeacher(teacher.id) },
                                onAssignClass = { teacherToAssignClass = teacher },
                                onResetPassword = { teacherToResetPassword = teacher },
                                onDelete = { viewModel.deleteTeacher(teacher.id) }
                            )
                        }
                    }
                }
            } else {
                // PARENTS LIST
                if (displayedParents.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No parent accounts found in this filter category.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(displayedParents, key = { it.id }) { parent ->
                            val linkedIds = parent.linkedStudentIds?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
                            val linkedStudentObjects = students.filter { linkedIds.contains(it.id) }

                            ElevatedCard(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = parent.name,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = "Phone: ${parent.phone} • ID: ${parent.id}",
                                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            )
                                        }

                                        val (statusColor, statusBg, statusText) = when (parent.status) {
                                            AccountStatus.APPROVED.name -> Triple(StatusPresent, StatusPresentBg, "Approved")
                                            AccountStatus.PENDING.name -> Triple(StatusAbsent, StatusAbsentBg, "Pending Approval")
                                            else -> Triple(Color.Gray, MaterialTheme.colorScheme.surfaceVariant, parent.status)
                                        }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(statusBg)
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = statusText,
                                                color = statusColor,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (linkedStudentObjects.isNotEmpty()) {
                                            "Linked Children: " + linkedStudentObjects.joinToString(", ") { "${it.name} (${it.classId})" }
                                        } else {
                                            "No children linked yet."
                                        },
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (linkedStudentObjects.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = if (linkedStudentObjects.isNotEmpty()) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    )

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                PhoneCallHelper.dialExactNumber(context, parent.phone, "${parent.name} (Parent)")
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Call Parent", fontSize = 11.sp)
                                        }

                                        if (parent.status == AccountStatus.PENDING.name) {
                                            Button(
                                                onClick = { viewModel.approveParent(parent.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = StatusPresent),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text("Approve", fontSize = 11.sp)
                                            }

                                            OutlinedButton(
                                                onClick = { viewModel.rejectParent(parent.id) },
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text("Reject", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                            }
                                        }

                                        Spacer(modifier = Modifier.weight(1f))

                                        IconButton(
                                            onClick = { parentToDelete = parent },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete",
                                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Parent Delete Dialog
        parentToDelete?.let { parent ->
            AlertDialog(
                onDismissRequest = { parentToDelete = null },
                title = { Text("Delete Parent Account", fontWeight = FontWeight.Bold) },
                text = { Text("Are you sure you want to delete the account for parent ${parent.name} (${parent.id})?") },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteParent(parent.id)
                            parentToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { parentToDelete = null }) { Text("Cancel") }
                }
            )
        }

        // Add Teacher Floating Action Button (Only on Teachers tab)
        if (mainSection == "TEACHERS") {
            ExtendedFloatingActionButton(
                onClick = { showAddTeacherDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
                    .testTag("fab_add_teacher"),
                icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                text = { Text("Add Teacher") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }

        // Add Teacher Dialog
        if (showAddTeacherDialog) {
            AddTeacherDialog(
                onDismiss = { showAddTeacherDialog = false },
                onAdd = { name, email, phone, subject, id, pass ->
                    viewModel.addTeacher(name, email, phone, subject, id, pass)
                    showAddTeacherDialog = false
                }
            )
        }

        // Assign Class Teacher Dialog
        teacherToAssignClass?.let { teacher ->
            AssignClassDialog(
                teacher = teacher,
                classes = classes,
                onDismiss = { teacherToAssignClass = null },
                onAssign = { classId ->
                    viewModel.assignClassTeacher(teacher.id, classId)
                    teacherToAssignClass = null
                }
            )
        }

        // Reset Password Dialog
        teacherToResetPassword?.let { teacher ->
            ResetTeacherPasswordDialog(
                teacher = teacher,
                onDismiss = { teacherToResetPassword = null },
                onReset = { newPass ->
                    viewModel.resetTeacherPassword(teacher.id, newPass)
                    teacherToResetPassword = null
                }
            )
        }
    }
}

@Composable
fun TeacherManagementCard(
    teacher: UserAccount,
    classes: List<SchoolClass>,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onAssignClass: () -> Unit,
    onResetPassword: () -> Unit,
    onDelete: () -> Unit
) {
    val assignedClass = classes.find { it.id == teacher.assignedClassId }

    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = teacher.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Teacher ID: ${teacher.id} • ${teacher.subject ?: "General"}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // Status Badge
                when (teacher.status) {
                    AccountStatus.PENDING.name -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.errorContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Pending Approval",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    AccountStatus.APPROVED.name -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.tertiaryContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Active",
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    AccountStatus.REJECTED.name -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Rejected",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "Assigned Class: ${assignedClass?.name ?: "None"}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                )
                Text(
                    text = "Contact: ${teacher.phone}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), thickness = 0.5.dp)

            // Action Buttons
            if (teacher.status == AccountStatus.PENDING.name) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve Account")
                    }
                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Decline")
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onAssignClass,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Class, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Assign Class", fontSize = 12.sp)
                    }

                    Row {
                        IconButton(onClick = onResetPassword) {
                            Icon(
                                imageVector = Icons.Default.LockReset,
                                contentDescription = "Reset Password",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onDelete) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddTeacherDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, email: String, phone: String, subject: String, customId: String?, pass: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("Mathematics") }
    var customId by remember { mutableStateOf("TCH_" + System.currentTimeMillis().toString().takeLast(4)) }
    var password by remember { mutableStateOf("teacher123") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add New Teacher", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customId,
                    onValueChange = { customId = it },
                    label = { Text("Teacher ID (Unique)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Teacher Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Physics, Math)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Initial Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onAdd(name, email, phone, subject, customId, password)
                    }
                }
            ) {
                Text("Save Teacher")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignClassDialog(
    teacher: UserAccount,
    classes: List<SchoolClass>,
    onDismiss: () -> Unit,
    onAssign: (classId: String?) -> Unit
) {
    var selectedClassId by remember { mutableStateOf(teacher.assignedClassId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assign Class Teacher", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select class for ${teacher.name}:", style = MaterialTheme.typography.bodyMedium)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedClassId = null }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = selectedClassId == null,
                        onClick = { selectedClassId = null },
                        label = { Text("None (Unassigned)") }
                    )
                }

                classes.forEach { schoolClass ->
                    FilterChip(
                        selected = selectedClassId == schoolClass.id,
                        onClick = { selectedClassId = schoolClass.id },
                        label = { Text("${schoolClass.name} (${schoolClass.roomNumber})") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = { onAssign(selectedClassId) }) { Text("Save Assignment") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ResetTeacherPasswordDialog(
    teacher: UserAccount,
    onDismiss: () -> Unit,
    onReset: (newPassword: String) -> Unit
) {
    var newPassword by remember { mutableStateOf("teacher123") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reset Teacher Password", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Set a new password for ${teacher.name} (${teacher.id}):",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("New Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (newPassword.isNotBlank()) onReset(newPassword)
            }) {
                Text("Update Password")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- CLASSES & STUDENTS VIEW ----------------

@Composable
fun PrincipalClassesStudentsView(viewModel: PrincipalViewModel) {
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val teachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val students by viewModel.allStudents.collectAsStateWithLifecycle()
    val allParents by viewModel.allParents.collectAsStateWithLifecycle()
    val approvedParents by viewModel.approvedParents.collectAsStateWithLifecycle()
    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val principalProfile by viewModel.principalProfile.collectAsStateWithLifecycle()
    val selectedClassId by viewModel.selectedClassId.collectAsStateWithLifecycle()

    val context = LocalContext.current

    var showAddClassDialog by remember { mutableStateOf(false) }
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var selectedStudentForChat by remember { mutableStateOf<Student?>(null) }
    var selectedStudentForLink by remember { mutableStateOf<Student?>(null) }
    var selectedStudentForCall by remember { mutableStateOf<Student?>(null) }
    var studentToDelete by remember { mutableStateOf<Student?>(null) }

    val currentClass = classes.find { it.id == selectedClassId }
    val displayedStudents = if (selectedClassId != null) {
        students.filter { it.classId == selectedClassId }
    } else {
        students
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Horizontal Class Selector Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedClassId == null,
                        onClick = { viewModel.selectClass(null) },
                        label = { Text("All Classes (${students.size} students)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
                items(classes) { schoolClass ->
                    val classStudentCount = students.count { it.classId == schoolClass.id }
                    FilterChip(
                        selected = selectedClassId == schoolClass.id,
                        onClick = { viewModel.selectClass(schoolClass.id) },
                        label = { Text("${schoolClass.name} ($classStudentCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Class details banner if selected
            currentClass?.let { cls ->
                val classTeacher = teachers.find { it.id == cls.classTeacherId }
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = cls.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Class Teacher: ${classTeacher?.name ?: "Unassigned"} • ${cls.roomNumber}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                        IconButton(onClick = { viewModel.deleteClass(cls.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Class", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Students List Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Enrolled Students (${displayedStudents.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { showAddClassDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Class", fontSize = 12.sp)
                    }
                    Button(
                        onClick = { showAddStudentDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Student", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (displayedStudents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No students enrolled in this class yet.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(displayedStudents, key = { it.id }) { student ->
                        val isLinked = !student.parentUserId.isNullOrBlank() || allParents.any { parent ->
                            val ids = parent.linkedStudentIds.split(",").map { it.trim() }
                            ids.contains(student.id)
                        }

                        StudentItemCard(
                            student = student,
                            isParentLinked = isLinked,
                            onCall = { selectedStudentForCall = student },
                            onMessage = { selectedStudentForChat = student },
                            onLinkParent = { selectedStudentForLink = student },
                            onDelete = { studentToDelete = student }
                        )
                    }
                }
            }
        }

        // Add Class Dialog
        if (showAddClassDialog) {
            AddClassDialog(
                teachers = teachers,
                onDismiss = { showAddClassDialog = false },
                onAdd = { name, grade, section, room, teacherId ->
                    viewModel.addClass(name, grade, section, room, teacherId)
                    showAddClassDialog = false
                }
            )
        }

        // Add Student Dialog
        if (showAddStudentDialog) {
            AddStudentDialog(
                classes = classes,
                defaultClassId = selectedClassId,
                onDismiss = { showAddStudentDialog = false },
                onAdd = { roll, name, classId, gender, parent, phone, emergency, address ->
                    viewModel.addStudent(roll, name, classId, gender, parent, phone, emergency, address)
                    showAddStudentDialog = false
                }
            )
        }

        // Delete Confirmation Dialog
        studentToDelete?.let { student ->
            AlertDialog(
                onDismissRequest = { studentToDelete = null },
                title = { Text("Delete Student Record", fontWeight = FontWeight.Bold) },
                text = { Text("Are you sure you want to delete ${student.name} (Roll: ${student.rollNumber})? This will remove attendance and marks records.") },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteStudent(student.id)
                            studentToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { studentToDelete = null }) { Text("Cancel") }
                }
            )
        }

        // Call Selection Dialog
        selectedStudentForCall?.let { student ->
            AlertDialog(
                onDismissRequest = { selectedStudentForCall = null },
                title = { Text("Call Contact for ${student.name}", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Select which contact number to dial directly from your device:")
                        if (student.parentPhone.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    PhoneCallHelper.dialExactNumber(context, student.parentPhone, "${student.name}'s Parent")
                                    selectedStudentForCall = null
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Call Parent: ${student.parentPhone}")
                            }
                        }

                        if (student.emergencyContact.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    PhoneCallHelper.dialExactNumber(context, student.emergencyContact, "${student.name}'s Emergency Contact")
                                    selectedStudentForCall = null
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Emergency, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Call Emergency: ${student.emergencyContact}")
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { selectedStudentForCall = null }) { Text("Cancel") }
                }
            )
        }

        // Parent Linking Dialog
        selectedStudentForLink?.let { student ->
            ParentLinkingDialog(
                student = student,
                parents = approvedParents,
                onLinkConfirmed = { parentId ->
                    viewModel.linkParentToStudent(parentId, student.id)
                    selectedStudentForLink = null
                },
                onDismiss = { selectedStudentForLink = null }
            )
        }

        // Student Parent Chat Dialog
        selectedStudentForChat?.let { student ->
            StudentParentChatDialog(
                student = student,
                repository = viewModel.repository,
                currentUserId = principalProfile?.id ?: session?.userId ?: "PRIN001",
                currentUserName = principalProfile?.name ?: session?.name ?: "Principal",
                currentUserRole = UserRole.PRINCIPAL.name,
                onDismiss = { selectedStudentForChat = null }
            )
        }
    }
}

@Composable
fun StudentItemCard(
    student: Student,
    isParentLinked: Boolean,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onLinkParent: () -> Unit,
    onDelete: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = student.rollNumber,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = student.name,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Class: ${student.classId} • Parent: ${student.parentName}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // Linking Status Badge
                if (isParentLinked) {
                    Surface(
                        color = StatusPresentBg,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = StatusPresent, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Linked", color = StatusPresent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Unlinked",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Phone contacts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "📞 Parent: ${student.parentPhone.ifBlank { "N/A" }}",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                if (student.emergencyContact.isNotBlank()) {
                    Text(
                        text = "🚨 SOS: ${student.emergencyContact}",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.error)
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)

            // Actions row: Call, Message, Link, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onCall,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Call", fontSize = 11.sp)
                }

                Button(
                    onClick = onMessage,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = "Message", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onLinkParent,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Icon(Icons.Default.Link, contentDescription = "Link Parent", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Link", fontSize = 11.sp)
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddClassDialog(
    teachers: List<UserAccount>,
    onDismiss: () -> Unit,
    onAdd: (name: String, grade: String, section: String, room: String, teacherId: String?) -> Unit
) {
    var grade by remember { mutableStateOf("Grade 11") }
    var section by remember { mutableStateOf("A") }
    var room by remember { mutableStateOf("Room 205") }
    var selectedTeacherId by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Class", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = grade,
                    onValueChange = { grade = it },
                    label = { Text("Grade / Year (e.g. Grade 10)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = section,
                    onValueChange = { section = it },
                    label = { Text("Section (e.g. A, B)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("Room Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Assign Class Teacher (Optional):", style = MaterialTheme.typography.labelMedium)
                teachers.filter { it.status == AccountStatus.APPROVED.name }.forEach { teacher ->
                    FilterChip(
                        selected = selectedTeacherId == teacher.id,
                        onClick = {
                            selectedTeacherId = if (selectedTeacherId == teacher.id) null else teacher.id
                        },
                        label = { Text("${teacher.name} (${teacher.subject ?: ""})") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (grade.isNotBlank() && section.isNotBlank()) {
                        val name = "$grade - Section $section"
                        onAdd(name, grade, section, room, selectedTeacherId)
                    }
                }
            ) {
                Text("Create Class")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddStudentDialog(
    classes: List<SchoolClass>,
    defaultClassId: String?,
    onDismiss: () -> Unit,
    onAdd: (roll: String, name: String, classId: String, gender: String, parent: String, phone: String, emergency: String, address: String) -> Unit
) {
    var rollNo by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var selectedClassId by remember { mutableStateOf(defaultClassId ?: classes.firstOrNull()?.id ?: "CLASS_10A") }
    var gender by remember { mutableStateOf("Male") }
    var parentName by remember { mutableStateOf("") }
    var parentPhone by remember { mutableStateOf("") }
    var emergencyContact by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enroll New Student", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = rollNo,
                    onValueChange = { rollNo = it },
                    label = { Text("Roll Number (e.g. 107)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Student Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Select Class:", style = MaterialTheme.typography.labelMedium)
                classes.forEach { cls ->
                    FilterChip(
                        selected = selectedClassId == cls.id,
                        onClick = { selectedClassId = cls.id },
                        label = { Text(cls.name) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = gender == "Male",
                        onClick = { gender = "Male" },
                        label = { Text("Male") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = gender == "Female",
                        onClick = { gender = "Female" },
                        label = { Text("Female") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = parentName,
                    onValueChange = { parentName = it },
                    label = { Text("Parent / Guardian Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = parentPhone,
                    onValueChange = { parentPhone = it },
                    label = { Text("Parent Phone Number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = emergencyContact,
                    onValueChange = { emergencyContact = it },
                    label = { Text("Emergency Contact Phone") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Residential Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (rollNo.isNotBlank() && name.isNotBlank()) {
                        onAdd(rollNo, name, selectedClassId, gender, parentName, parentPhone, emergencyContact, address)
                    }
                }
            ) {
                Text("Enroll Student")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- ATTENDANCE VIEW ----------------

@Composable
fun PrincipalAttendanceView(viewModel: PrincipalViewModel) {
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val attendanceSummary by viewModel.attendanceSummary.collectAsStateWithLifecycle()
    val allRecords by viewModel.todayAttendanceRecords.collectAsStateWithLifecycle()
    val absentStudents by viewModel.todayAbsentStudents.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val students by viewModel.allStudents.collectAsStateWithLifecycle()
    val selectedDateSubmissions by viewModel.selectedDateSubmissions.collectAsStateWithLifecycle()
    val allSubmissions by viewModel.allAttendanceSubmissions.collectAsStateWithLifecycle()
    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val principalProfile by viewModel.principalProfile.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var selectedStudentForChat by remember { mutableStateOf<Student?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 60.dp)
        ) {
        // Date Selector Row
        item {
            ElevatedCard(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Viewing Attendance For:",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Text(
                                text = selectedDate,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        OutlinedButton(
                            onClick = { viewModel.selectDate(todayStr) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Today", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Metrics breakdown
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "School Attendance Overview",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { (attendanceSummary.attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = StatusPresent,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatusMetric(label = "Present", count = attendanceSummary.presentCount, color = StatusPresent)
                        StatusMetric(label = "Absent", count = attendanceSummary.absentCount, color = StatusAbsent)
                        StatusMetric(label = "Late", count = attendanceSummary.lateCount, color = StatusLate)
                        StatusMetric(label = "Total Marked", count = allRecords.size, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Submitted Attendance Reports Section
        item {
            Text(
                text = "Submitted Reports from Teachers (${selectedDateSubmissions.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (selectedDateSubmissions.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No teacher attendance reports submitted yet for this date.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        } else {
            items(selectedDateSubmissions, key = { it.id }) { sub ->
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = StatusPresent,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = sub.className,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(StatusPresentBg)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = sub.submittedStatus,
                                    color = StatusPresent,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Class Teacher: ${sub.classTeacherName} • Date: ${sub.date}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Text(
                            text = "Total Students: ${sub.totalStudents} | Present: ${sub.presentStudents} | Absent: ${sub.absentStudents}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )

                        if (sub.absentStudents > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Absent Students: ${sub.absentStudentNames}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                            )
                            if (sub.absentNotes.isNotBlank() && sub.absentNotes != "No notes provided") {
                                Text(
                                    text = "Absent Notes: ${sub.absentNotes}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Absent Students Section
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Absent Students (${absentStudents.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (absentStudents.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No absent students reported for this date.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        } else {
            items(absentStudents, key = { it.id }) { record ->
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = record.studentName,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Class: ${record.classId} • Roll: ${record.rollNumber}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            record.remarks?.let {
                                Text(
                                    text = "Reason: $it",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }

                        val targetStudent = students.find { it.id == record.studentId }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val phoneToDial = targetStudent?.parentPhone?.ifBlank { null } ?: targetStudent?.emergencyContact?.ifBlank { null }
                                    phoneToDial?.let { num ->
                                        PhoneCallHelper.dialExactNumber(context, num, "${record.studentName}'s Parent")
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Call", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    targetStudent?.let { selectedStudentForChat = it }
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = "Message", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Chat", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Class-by-Class Attendance Breakdown
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Class-wise Attendance Status",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(classes, key = { it.id }) { cls ->
            val classRecords = allRecords.filter { it.classId == cls.id }
            val presentInClass = classRecords.count { it.status == "PRESENT" || it.status == "LATE" }
            val absentInClass = classRecords.count { it.status == "ABSENT" }

            ElevatedCard(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = cls.name,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "${cls.roomNumber} • Recorded: ${classRecords.size} students",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(StatusPresentBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Present: $presentInClass",
                                color = StatusPresent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(StatusAbsentBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Absent: $absentInClass",
                                color = StatusAbsent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Chat Dialog
    selectedStudentForChat?.let { student ->
        StudentParentChatDialog(
            student = student,
            repository = viewModel.repository,
            currentUserId = principalProfile?.id ?: session?.userId ?: "PRIN001",
            currentUserName = principalProfile?.name ?: session?.name ?: "Principal",
            currentUserRole = UserRole.PRINCIPAL.name,
            onDismiss = { selectedStudentForChat = null }
        )
    }
    }
}

@Composable
fun StatusMetric(label: String, count: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$count",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
    }
}

// ---------------- ACADEMICS (TESTS, MARKS & HOMEWORK) VIEW ----------------

@Composable
fun PrincipalAcademicsView(viewModel: PrincipalViewModel) {
    val homeworkList by viewModel.allHomework.collectAsStateWithLifecycle()
    val marksList by viewModel.allMarks.collectAsStateWithLifecycle()
    val testsList by viewModel.allTests.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()

    var academicSubTab by remember { mutableStateOf(0) } // 0: Tests & Results, 1: Student Marks & Ranks, 2: Homework
    var selectedClassFilter by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedTestForDetails by remember { mutableStateOf<SchoolTest?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        TabRow(
            selectedTabIndex = academicSubTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = academicSubTab == 0,
                onClick = { academicSubTab = 0 },
                text = { Text("Tests & Results (${testsList.size})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
            )
            Tab(
                selected = academicSubTab == 1,
                onClick = { academicSubTab = 1 },
                text = { Text("Marks & Ranks (${marksList.size})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
            )
            Tab(
                selected = academicSubTab == 2,
                onClick = { academicSubTab = 2 },
                text = { Text("Homework (${homeworkList.size})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Class Filter Chip Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = selectedClassFilter == null,
                    onClick = { selectedClassFilter = null },
                    label = { Text("All Classes", fontSize = 12.sp) }
                )
            }
            items(classes) { cls ->
                FilterChip(
                    selected = selectedClassFilter == cls.id,
                    onClick = {
                        selectedClassFilter = if (selectedClassFilter == cls.id) null else cls.id
                    },
                    label = { Text(cls.name, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (academicSubTab == 0) {
            // Tests & Result History
            val filteredTests = remember(testsList, selectedClassFilter) {
                if (selectedClassFilter == null) testsList
                else testsList.filter { it.classId == selectedClassFilter }
            }

            if (filteredTests.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No tests or examination results recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(filteredTests, key = { it.id }) { test ->
                        val cls = classes.find { it.id == test.classId }
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = test.testName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${test.subject} • ${cls?.name ?: test.className} • ${test.date}",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "Max: ${test.maxMarks}",
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Test Performance Metrics
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Students", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${test.totalStudents}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Class Average", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(String.format(Locale.getDefault(), "%.1f", test.averageScore), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Top Score", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${test.highestScore}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "By Teacher: ${test.createdByTeacherName}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { selectedTestForDetails = test },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("View Result Sheet", fontSize = 12.sp)
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteTest(test.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Test", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (academicSubTab == 1) {
            // Student Marks & Leaderboard
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by student name, roll no, or subject") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            val filteredMarks = remember(marksList, selectedClassFilter, searchQuery) {
                marksList.filter { mark ->
                    val matchClass = selectedClassFilter == null || mark.classId == selectedClassFilter
                    val matchQuery = searchQuery.isBlank() ||
                            mark.studentName.contains(searchQuery, ignoreCase = true) ||
                            mark.rollNumber.contains(searchQuery, ignoreCase = true) ||
                            mark.subject.contains(searchQuery, ignoreCase = true) ||
                            mark.examName.contains(searchQuery, ignoreCase = true)
                    matchClass && matchQuery
                }
            }

            if (filteredMarks.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No student marks match the criteria.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(filteredMarks, key = { it.id }) { mark ->
                        val cls = classes.find { it.id == mark.classId }
                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (mark.rank) {
                                                    1 -> Color(0xFFFFD700).copy(alpha = 0.2f)
                                                    2 -> Color(0xFFC0C0C0).copy(alpha = 0.2f)
                                                    3 -> Color(0xFFCD7F32).copy(alpha = 0.2f)
                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = when (mark.rank) {
                                                1 -> "🏆"
                                                2 -> "🥈"
                                                3 -> "🥉"
                                                else -> "#${mark.rank}"
                                            },
                                            fontSize = if (mark.rank <= 3) 15.sp else 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = "${mark.studentName} (Roll ${mark.rollNumber})",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${mark.examName} • ${mark.subject} (${cls?.name ?: mark.classId})",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        )
                                        mark.remarks?.let {
                                            Text(
                                                text = "Note: $it",
                                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                                            )
                                        }
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${mark.marksObtained} / ${mark.maxMarks}",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = String.format(Locale.getDefault(), "%.1f%%", mark.percentage),
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (mark.percentage >= 50.0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                                )
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = mark.grade,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { viewModel.deleteMark(mark.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Homework List
            val filteredHw = remember(homeworkList, selectedClassFilter) {
                if (selectedClassFilter == null) homeworkList
                else homeworkList.filter { it.classId == selectedClassFilter }
            }

            if (filteredHw.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No homework assignments posted yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(filteredHw, key = { it.id }) { hw ->
                        val cls = classes.find { it.id == hw.classId }
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = hw.subject,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Text(
                                        text = "Class: ${cls?.name ?: hw.classId}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = hw.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = hw.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(thickness = 0.5.dp)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "By: ${hw.teacherName}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    Text(
                                        text = "Due: ${hw.dueDate}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Test Results Detail Dialog for Principal
    selectedTestForDetails?.let { test ->
        val testMarks by viewModel.getMarksByTest(test.id).collectAsStateWithLifecycle(emptyList())
        TestResultsDetailDialog(
            test = test,
            marks = testMarks,
            onDismiss = { selectedTestForDetails = null },
            onDelete = {
                viewModel.deleteTest(test.id)
                selectedTestForDetails = null
            }
        )
    }
}

// ---------------- FEES & ACCOUNTS VIEW ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalFeesView(viewModel: PrincipalViewModel) {
    val students by viewModel.allStudents.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val allFees by viewModel.allStudentFees.collectAsStateWithLifecycle()
    val currentSchool by viewModel.currentSchool.collectAsStateWithLifecycle()
    val schoolCurrency = currentSchool?.currency ?: "₹"

    var selectedClassId by remember { mutableStateOf<String?>(null) }
    var selectedStatusFilter by remember { mutableStateOf("ALL") } // "ALL", "DUE", "PAID"
    var searchQuery by remember { mutableStateOf("") }

    var studentForPayment by remember { mutableStateOf<Student?>(null) }
    var studentForSetFee by remember { mutableStateOf<Pair<Student, StudentFee?>?>(null) }
    var studentForReceipts by remember { mutableStateOf<Student?>(null) }
    var showBulkClassFeeDialog by remember { mutableStateOf(false) }

    // Aggregate calculations
    val totalBilled = allFees.sumOf { it.totalFee }
    val totalCollected = allFees.sumOf { it.totalPaid }
    val totalOutstanding = allFees.sumOf { it.remainingFee }

    // Map fees by student ID for fast lookup
    val feesMap = remember(allFees) { allFees.associateBy { it.studentId } }

    val filteredStudents = remember(students, selectedClassId, selectedStatusFilter, searchQuery, feesMap) {
        students.filter { student ->
            val matchClass = selectedClassId == null || student.classId == selectedClassId
            val matchSearch = searchQuery.isBlank() ||
                    student.name.contains(searchQuery, ignoreCase = true) ||
                    student.rollNumber.contains(searchQuery, ignoreCase = true)

            val fee = feesMap[student.id]
            val status = fee?.status ?: "UNPAID"
            val matchStatus = when (selectedStatusFilter) {
                "DUE" -> status == "UNPAID" || status == "PARTIAL"
                "PAID" -> status == "PAID"
                else -> true
            }

            matchClass && matchSearch && matchStatus
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Header & Quick Action
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Fee Management",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Track payments, dues, and issue receipts",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }

                    Button(
                        onClick = { showBulkClassFeeDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_bulk_class_fee")
                    ) {
                        Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Set Class Fee", fontSize = 12.sp)
                    }
                }
            }

            // Overview Summary Card
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Collection Summary",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            val collectionPct = if (totalBilled > 0) ((totalCollected / totalBilled) * 100).toInt() else 0
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "$collectionPct% Collected",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LinearProgressIndicator(
                            progress = { if (totalBilled > 0) (totalCollected / totalBilled).toFloat().coerceIn(0f, 1f) else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = StatusPresent,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$schoolCurrency${String.format(Locale.getDefault(), "%,.0f", totalBilled)}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text("Total Billed", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$schoolCurrency${String.format(Locale.getDefault(), "%,.0f", totalCollected)}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusPresent)
                                )
                                Text("Collected", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$schoolCurrency${String.format(Locale.getDefault(), "%,.0f", totalOutstanding)}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                )
                                Text("Outstanding", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }
                        }
                    }
                }
            }

            // Filter & Search Controls
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search by student name or roll number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Status Filters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedStatusFilter == "ALL",
                            onClick = { selectedStatusFilter = "ALL" },
                            label = { Text("All (${students.size})") }
                        )
                        FilterChip(
                            selected = selectedStatusFilter == "DUE",
                            onClick = { selectedStatusFilter = "DUE" },
                            label = { Text("Pending / Due") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.errorContainer
                            )
                        )
                        FilterChip(
                            selected = selectedStatusFilter == "PAID",
                            onClick = { selectedStatusFilter = "PAID" },
                            label = { Text("Fully Paid") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StatusPresentBg
                            )
                        )
                    }

                    // Class Filter Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedClassId == null,
                                onClick = { selectedClassId = null },
                                label = { Text("All Classes") }
                            )
                        }
                        items(classes) { cls ->
                            FilterChip(
                                selected = selectedClassId == cls.id,
                                onClick = { selectedClassId = cls.id },
                                label = { Text(cls.name) }
                            )
                        }
                    }
                }
            }

            // Student Fee List
            if (filteredStudents.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = "No students match the selected fee filters.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredStudents, key = { it.id }) { student ->
                    val fee = feesMap[student.id]
                    val cls = classes.find { it.id == student.classId }
                    val total = fee?.totalFee ?: 0.0
                    val paid = fee?.totalPaid ?: 0.0
                    val balance = fee?.remainingFee ?: 0.0
                    val status = fee?.status ?: if (total == 0.0) "NOT_SET" else "UNPAID"

                    ElevatedCard(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = student.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Class: ${cls?.name ?: student.classId} • Roll: ${student.rollNumber}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }

                                // Status Tag
                                val (statusText, statusBg, statusColor) = when (status) {
                                    "PAID" -> Triple("PAID", StatusPresentBg, StatusPresent)
                                    "PARTIAL" -> Triple("PARTIAL", StatusLateBg, StatusLate)
                                    "NOT_SET" -> Triple("NO FEE SET", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                                    else -> Triple("DUE", StatusAbsentBg, StatusAbsent)
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(statusBg)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = statusText,
                                        color = statusColor,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Figures Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                val studentCurr = fee?.currency ?: schoolCurrency
                                Column {
                                    Text("Total Fee", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("$studentCurr${String.format(Locale.getDefault(), "%.2f", total)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column {
                                    Text("Paid", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("$studentCurr${String.format(Locale.getDefault(), "%.2f", paid)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StatusPresent)
                                }
                                Column {
                                    Text("Remaining Due", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("$studentCurr${String.format(Locale.getDefault(), "%.2f", balance)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (balance > 0) MaterialTheme.colorScheme.error else StatusPresent)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { studentForReceipts = student },
                                    modifier = Modifier.testTag("btn_receipts_${student.id}")
                                ) {
                                    Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Receipts", fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                OutlinedButton(
                                    onClick = { studentForSetFee = Pair(student, fee) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("Set Fee", fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                Button(
                                    onClick = { studentForPayment = student },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_pay_${student.id}")
                                ) {
                                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pay", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialogs
        studentForPayment?.let { student ->
            val fee = feesMap[student.id]
            RecordFeePaymentDialog(
                student = student,
                currentFee = fee,
                currency = schoolCurrency,
                onDismiss = { studentForPayment = null },
                onRecord = { amount, date, mode, note ->
                    viewModel.recordFeePayment(student, amount, date, mode, note)
                    studentForPayment = null
                }
            )
        }

        studentForSetFee?.let { (student, fee) ->
            SetStudentTotalFeeDialog(
                student = student,
                currentFee = fee,
                currency = schoolCurrency,
                onDismiss = { studentForSetFee = null },
                onSave = { newTotal ->
                    viewModel.setStudentTotalFee(student, newTotal)
                    studentForSetFee = null
                }
            )
        }

        studentForReceipts?.let { student ->
            val paymentsFlow = remember(student.id) { viewModel.getPaymentsByStudent(student.id) }
            val studentPayments by paymentsFlow.collectAsStateWithLifecycle(emptyList())

            StudentFeeReceiptsDialog(
                student = student,
                payments = studentPayments,
                onDismiss = { studentForReceipts = null },
                onDeletePayment = { paymentId ->
                    viewModel.deleteFeePayment(paymentId, student.id)
                }
            )
        }

        if (showBulkClassFeeDialog) {
            BulkSetClassFeesDialog(
                classes = classes,
                students = students,
                currency = schoolCurrency,
                onDismiss = { showBulkClassFeeDialog = false },
                onApply = { targetClassId, baseAmount ->
                    val classStudents = students.filter { it.classId == targetClassId }
                    classStudents.forEach { st ->
                        viewModel.setStudentTotalFee(st, baseAmount)
                    }
                    showBulkClassFeeDialog = false
                }
            )
        }
    }
}

@Composable
fun RecordFeePaymentDialog(
    student: Student,
    currentFee: StudentFee?,
    currency: String = "₹",
    onDismiss: () -> Unit,
    onRecord: (amount: Double, date: String, mode: String, note: String) -> Unit
) {
    val remaining = currentFee?.remainingFee ?: 0.0
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    var amountText by remember { mutableStateOf(if (remaining > 0) remaining.toString() else "") }
    var dateText by remember { mutableStateOf(today) }
    var paymentMode by remember { mutableStateOf("Cash") }
    var noteText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val paymentModes = listOf("Cash", "Online / UPI", "Bank Transfer", "Cheque", "Card")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Fee Payment") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Student: ${student.name} (Roll ${student.rollNumber})",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )

                currentFee?.let {
                    val curr = it.currency.ifBlank { currency }
                    Text(
                        text = "Total Fee: $curr${it.totalFee} • Balance Due: $curr${it.remainingFee}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                    )
                }

                val curr = currentFee?.currency?.ifBlank { currency } ?: currency
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        error = null
                    },
                    label = { Text("Payment Amount ($curr)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text("Date (YYYY-MM-DD)*") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("Payment Method", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(paymentModes) { mode ->
                        FilterChip(
                            selected = paymentMode == mode,
                            onClick = { paymentMode = mode },
                            label = { Text(mode, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Remarks / Receipt Reference #") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        error = "Please enter a valid positive payment amount"
                        return@Button
                    }
                    if (dateText.isBlank()) {
                        error = "Please enter a payment date"
                        return@Button
                    }
                    onRecord(amt, dateText.trim(), paymentMode, noteText.trim())
                }
            ) {
                Text("Confirm Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SetStudentTotalFeeDialog(
    student: Student,
    currentFee: StudentFee?,
    currency: String = "₹",
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var feeText by remember { mutableStateOf(currentFee?.totalFee?.toString() ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    val curr = currentFee?.currency?.ifBlank { currency } ?: currency

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Student Total Fee") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Configure annual / term fee for ${student.name} (Roll ${student.rollNumber})",
                    style = MaterialTheme.typography.bodyMedium
                )

                currentFee?.let {
                    Text(
                        text = "Currently paid: $curr${it.totalPaid}",
                        style = MaterialTheme.typography.bodySmall.copy(color = StatusPresent)
                    )
                }

                OutlinedTextField(
                    value = feeText,
                    onValueChange = {
                        feeText = it
                        error = null
                    },
                    label = { Text("Total Fee Amount ($curr)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = feeText.toDoubleOrNull()
                    if (amount == null || amount < 0.0) {
                        error = "Please enter a valid amount"
                        return@Button
                    }
                    val paid = currentFee?.totalPaid ?: 0.0
                    if (amount < paid) {
                        error = "Total fee cannot be less than already collected amount ($$paid)"
                        return@Button
                    }
                    onSave(amount)
                }
            ) {
                Text("Save Total Fee")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkSetClassFeesDialog(
    classes: List<SchoolClass>,
    students: List<Student>,
    currency: String = "₹",
    onDismiss: () -> Unit,
    onApply: (classId: String, amount: Double) -> Unit
) {
    var selectedClass by remember { mutableStateOf(classes.firstOrNull()) }
    var expanded by remember { mutableStateOf(false) }
    var feeAmountText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val studentCount = remember(selectedClass, students) {
        if (selectedClass != null) students.count { it.classId == selectedClass?.id } else 0
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Base Fee for Entire Class") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Apply uniform term/annual fee to all students in the selected class.",
                    style = MaterialTheme.typography.bodyMedium
                )

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedClass?.name ?: "Select Class",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Target Class") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        classes.forEach { cls ->
                            DropdownMenuItem(
                                text = { Text(cls.name) },
                                onClick = {
                                    selectedClass = cls
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Text(
                    text = "Will update $studentCount students in this class.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary)
                )

                OutlinedTextField(
                    value = feeAmountText,
                    onValueChange = {
                        feeAmountText = it
                        error = null
                    },
                    label = { Text("Base Fee Amount ($currency)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cls = selectedClass
                    if (cls == null) {
                        error = "Please select a class"
                        return@Button
                    }
                    val amount = feeAmountText.toDoubleOrNull()
                    if (amount == null || amount <= 0.0) {
                        error = "Please enter a valid positive fee amount"
                        return@Button
                    }
                    onApply(cls.id, amount)
                }
            ) {
                Text("Apply to Class")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun StudentFeeReceiptsDialog(
    student: Student,
    payments: List<FeePayment>,
    onDismiss: () -> Unit,
    onDeletePayment: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Payment Receipts", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Text(
                    text = "${student.name} (Roll ${student.rollNumber})",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        },
        text = {
            if (payments.isEmpty()) {
                Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                    Text("No payment receipts recorded for this student yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(payments, key = { it.id }) { pay ->
                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = pay.receiptNumber,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "${pay.currency}${String.format(Locale.getDefault(), "%.2f", pay.amount)}",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StatusPresent
                                        )
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Date: ${pay.date} • Mode: ${pay.paymentMode}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    IconButton(
                                        onClick = { onDeletePayment(pay.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete Receipt",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                if (pay.note.isNotBlank()) {
                                    Text(
                                        text = "Note: ${pay.note}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                                Text(
                                    text = "Recorded by: ${pay.recordedBy}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

// ---------------- LEAVE REQUESTS VIEW ----------------

@Composable
fun PrincipalLeavesView(viewModel: PrincipalViewModel) {
    val allLeaves by viewModel.allLeaves.collectAsStateWithLifecycle()
    val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()

    var filterPendingOnly by remember { mutableStateOf(false) }
    var leaveToApprove by remember { mutableStateOf<LeaveRequest?>(null) }
    var leaveToReject by remember { mutableStateOf<LeaveRequest?>(null) }

    val displayedLeaves = if (filterPendingOnly) pendingLeaves else allLeaves

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !filterPendingOnly,
                    onClick = { filterPendingOnly = false },
                    label = { Text("All Requests (${allLeaves.size})") }
                )
                FilterChip(
                    selected = filterPendingOnly,
                    onClick = { filterPendingOnly = true },
                    label = { Text("Pending (${pendingLeaves.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.errorContainer
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (displayedLeaves.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No leave requests found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(displayedLeaves, key = { it.id }) { leave ->
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = leave.teacherName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${leave.leaveType} Leave • ${leave.daysCount} Day(s) (${leave.startDate} to ${leave.endDate})",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        )
                                    }

                                    // Status
                                    val statusColor = when (leave.status) {
                                        "APPROVED" -> StatusPresent
                                        "REJECTED" -> StatusAbsent
                                        else -> StatusLate
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(statusColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = leave.status,
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Reason: ${leave.reason}",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                leave.principalComment?.let { comment ->
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Principal Note: $comment",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                }

                                if (leave.status == "PENDING") {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { leaveToApprove = leave },
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusPresent),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Approve")
                                        }
                                        OutlinedButton(
                                            onClick = { leaveToReject = leave },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Reject")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Leave Decision Dialogs
        leaveToApprove?.let { leave ->
            LeaveDecisionDialog(
                title = "Approve Leave Request",
                teacherName = leave.teacherName,
                isApproval = true,
                onDismiss = { leaveToApprove = null },
                onConfirm = { comment ->
                    viewModel.approveLeave(leave.id, comment)
                    leaveToApprove = null
                }
            )
        }

        leaveToReject?.let { leave ->
            LeaveDecisionDialog(
                title = "Reject Leave Request",
                teacherName = leave.teacherName,
                isApproval = false,
                onDismiss = { leaveToReject = null },
                onConfirm = { comment ->
                    viewModel.rejectLeave(leave.id, comment)
                    leaveToReject = null
                }
            )
        }
    }
}

@Composable
fun LeaveDecisionDialog(
    title: String,
    teacherName: String,
    isApproval: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (comment: String?) -> Unit
) {
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Decision for $teacherName's leave request:")
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Remarks / Instructions (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(comment.ifBlank { null }) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isApproval) StatusPresent else MaterialTheme.colorScheme.error
                )
            ) {
                Text(if (isApproval) "Confirm Approval" else "Confirm Rejection")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- ANNOUNCEMENTS VIEW ----------------

@Composable
fun PrincipalAnnouncementsView(viewModel: PrincipalViewModel) {
    val announcements by viewModel.allAnnouncements.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()

    var showNewAnnouncementDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Broadcast Center (${announcements.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Button(
                    onClick = { showNewAnnouncementDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Notice")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (announcements.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No announcements published.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(announcements, key = { it.id }) { ann ->
                        AnnouncementItemCard(
                            announcement = ann,
                            onDelete = { viewModel.deleteAnnouncement(ann.id) }
                        )
                    }
                }
            }
        }

        if (showNewAnnouncementDialog) {
            CreateAnnouncementDialog(
                classes = classes,
                onDismiss = { showNewAnnouncementDialog = false },
                onPublish = { title, content, audience, priority ->
                    viewModel.sendAnnouncement(title, content, audience, priority)
                    showNewAnnouncementDialog = false
                }
            )
        }
    }
}

@Composable
fun AnnouncementItemCard(
    announcement: Announcement,
    onDelete: (() -> Unit)? = null
) {
    val priorityColor = when (announcement.priority) {
        AnnouncementPriority.URGENT.name -> MaterialTheme.colorScheme.error
        AnnouncementPriority.EVENT.name -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.primary
    }

    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(priorityColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = announcement.priority,
                        color = priorityColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Audience: ${if (announcement.targetAudience == "ALL") "All School" else announcement.targetAudience}",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    onDelete?.let {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(onClick = it, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = announcement.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = announcement.content,
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface)
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "By: ${announcement.authorName}",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                Text(
                    text = announcement.date,
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }
    }
}

@Composable
fun CreateAnnouncementDialog(
    classes: List<SchoolClass>,
    onDismiss: () -> Unit,
    onPublish: (title: String, content: String, audience: String, priority: AnnouncementPriority) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var audience by remember { mutableStateOf("ALL") }
    var priority by remember { mutableStateOf(AnnouncementPriority.NORMAL) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Publish Announcement", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Announcement Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Details & Description") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Priority Level:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = priority == AnnouncementPriority.NORMAL,
                        onClick = { priority = AnnouncementPriority.NORMAL },
                        label = { Text("Normal", fontSize = 12.sp) }
                    )
                    FilterChip(
                        selected = priority == AnnouncementPriority.URGENT,
                        onClick = { priority = AnnouncementPriority.URGENT },
                        label = { Text("Urgent", fontSize = 12.sp) }
                    )
                    FilterChip(
                        selected = priority == AnnouncementPriority.EVENT,
                        onClick = { priority = AnnouncementPriority.EVENT },
                        label = { Text("Event", fontSize = 12.sp) }
                    )
                }

                Text("Target Audience:", style = MaterialTheme.typography.labelMedium)
                FilterChip(
                    selected = audience == "ALL",
                    onClick = { audience = "ALL" },
                    label = { Text("All School (Teachers & Students)") },
                    modifier = Modifier.fillMaxWidth()
                )
                classes.forEach { cls ->
                    FilterChip(
                        selected = audience == cls.id,
                        onClick = { audience = cls.id },
                        label = { Text(cls.name) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onPublish(title, content, audience, priority)
                    }
                }
            ) {
                Text("Publish Notice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- SETTINGS & ACCOUNT VIEW ----------------

@Composable
fun PrincipalSettingsView(viewModel: PrincipalViewModel) {
    val session by viewModel.sessionState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = session?.name ?: "Principal",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Principal ID: ${session?.userId ?: ""}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "Role: School Administration (Full Access)",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Security & Multi-Device Sync",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            ElevatedCard(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "🔐 Persistent Login & Recovery",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Your login session is securely maintained on this device until you explicitly press Logout. Closing or reopening the app does not log you out.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "Teachers and Principals can recover their passwords anytime via their verified security questions.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Logout from School Portal")
            }
        }
    }
}
