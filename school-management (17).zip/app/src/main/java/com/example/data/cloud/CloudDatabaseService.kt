package com.example.data.cloud

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import com.example.data.model.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList

/**
 * CloudDataChangeListener informs the repository when Firestore documents are updated
 * in real-time by other devices.
 */
interface CloudDataChangeListener {
    fun onStudentsChanged(students: List<Student>, removedIds: List<String>)
    fun onUsersChanged(users: List<UserAccount>)
    fun onClassesChanged(classes: List<SchoolClass>)
    fun onEnrollmentsChanged(enrollments: List<StudentEnrollment>)
    fun onFeesChanged(fees: List<StudentFee>)
    fun onFeePaymentsChanged(payments: List<FeePayment>)
    fun onSalariesChanged(salaries: List<TeacherSalary>)
    fun onAttendanceChanged(attendance: List<AttendanceRecord>)
    fun onAttendanceSubmissionsChanged(submissions: List<AttendanceSubmissionRecord>)
    fun onAnnouncementsChanged(announcements: List<Announcement>)
    fun onHomeworkChanged(homework: List<Homework>)
    fun onTestsChanged(tests: List<SchoolTest>)
    fun onMarksChanged(marks: List<StudentMark>)
    fun onLeaveRequestsChanged(leaves: List<LeaveRequest>)
    fun onActivitiesChanged(activities: List<ActivityRecord>)
    fun onMessagesChanged(messages: List<ChatMessage>)
    fun onAcademicYearsChanged(years: List<AcademicYear>)
}

/**
 * CloudDatabaseService manages Cloud Firestore persistence and Firebase Authentication.
 * Firestore acts as the persistent cloud source of truth for all schools, users,
 * classes, students, fees, attendance, announcements, and messages.
 */
class CloudDatabaseService(context: Context) {

    private val appContext = context.applicationContext
    private val mutex = Mutex()
    private val activeListeners = CopyOnWriteArrayList<ListenerRegistration>()

    // --- Legacy Remote Cloud Constants & HTTP Helpers ---
    private val APP_KEY = "school_cbc6931c"
    private val KV_BASE = "https://keyvalue.immanuel.co/api/KeyVal"
    private val REST_API_BASE = "https://api.restful-api.dev/objects"

    private fun httpGet(urlString: String): String? {
        if (isTestEnv) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "SchoolManagement/1.0 (Android; MultiDevice)")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            } else {
                null
            }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun getCloudPointer(key: String): String? {
        val url = "$KV_BASE/GetValue/$APP_KEY/$key"
        val res = httpGet(url)?.trim()?.trim('"')
        return if (res.isNullOrEmpty() || res == "null") null else res
    }

    private fun fetchDocumentFromCloud(id: String): JSONObject? {
        val res = httpGet("$REST_API_BASE/$id") ?: return null
        return try {
            val root = JSONObject(res)
            root.optJSONObject("data")
        } catch (e: Exception) {
            null
        }
    }

    private val isTestEnv: Boolean by lazy {
        Build.FINGERPRINT == "robolectric" ||
        Build.HARDWARE == "robolectric" ||
        Build.DEVICE == "robolectric" ||
        try {
            Class.forName("org.robolectric.Robolectric")
            true
        } catch (e: Throwable) {
            false
        }
    }

    private val firestore: FirebaseFirestore? by lazy {
        if (isTestEnv) return@lazy null
        try {
            if (FirebaseApp.getApps(appContext).isEmpty()) {
                FirebaseApp.initializeApp(appContext)
            }
            val db = FirebaseFirestore.getInstance()
            try {
                val settings = FirebaseFirestoreSettings.Builder()
                    .setPersistenceEnabled(true)
                    .build()
                db.firestoreSettings = settings
            } catch (e: Exception) {
                // Settings can only be set once
            }
            db
        } catch (e: Throwable) {
            Log.w("CloudDatabaseService", "FirebaseFirestore init notice: ${e.message}")
            null
        }
    }

    private val auth: FirebaseAuth? by lazy {
        if (isTestEnv) return@lazy null
        try {
            if (FirebaseApp.getApps(appContext).isEmpty()) {
                FirebaseApp.initializeApp(appContext)
            }
            FirebaseAuth.getInstance()
        } catch (e: Throwable) {
            Log.w("CloudDatabaseService", "FirebaseAuth init notice: ${e.message}")
            null
        }
    }

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitTask(): T =
        suspendCancellableCoroutine { cont ->
            addOnSuccessListener { result ->
                if (cont.isActive) cont.resumeWith(Result.success(result))
            }
            addOnFailureListener { ex ->
                if (cont.isActive) cont.resumeWith(Result.failure(ex))
            }
            addOnCanceledListener {
                if (cont.isActive) cont.cancel()
            }
        }

    fun isOffline(): Boolean {
        if (isTestEnv) return false
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return true
        val capabilities = cm.getNetworkCapabilities(network) ?: return true
        return !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // --- Firebase Authentication Integration ---

    suspend fun ensureFirebaseAuth(user: UserAccount, rawPassword: String? = null) {
        val fbAuth = auth ?: return
        try {
            if (fbAuth.currentUser != null && rawPassword == null) return
            val email = if (user.email.isNotBlank() && user.email.contains("@")) {
                user.email.trim().lowercase()
            } else {
                "${user.id.trim().lowercase().replace(" ", "")}@school.internal"
            }
            val password = rawPassword?.trim()?.takeIf { it.length >= 6 } ?: "SecuredSchoolPass123!"

            try {
                fbAuth.signInWithEmailAndPassword(email, password).awaitTask()
            } catch (signInEx: Exception) {
                try {
                    fbAuth.createUserWithEmailAndPassword(email, password).awaitTask()
                } catch (createEx: Exception) {
                    // Fallback to anonymous sign-in so requests have valid auth token
                    try {
                        fbAuth.signInAnonymously().awaitTask()
                    } catch (e: Exception) {
                        Log.w("CloudDatabaseService", "Auth notice: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Firebase Auth ensure notice: ${e.message}")
        }
    }

    // --- User Accounts in Firestore (/users/{userId}) ---

    suspend fun findCloudUser(userId: String): UserAccount? = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        if (cleanId.isBlank()) return@withContext null
        val db = firestore

        // 1. First attempt: Query Cloud Firestore
        if (db != null) {
            try {
                val doc = db.collection("users").document(cleanId).get().awaitTask()
                if (doc.exists()) {
                    val data = doc.data
                    if (data != null) {
                        val user = mapToUserAccount(data, cleanId)
                        ensureFirebaseAuth(user)
                        return@withContext user
                    }
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Firestore findCloudUser notice for $cleanId: ${e.message}")
            }
        }

        // 2. Second attempt: Check legacy persistent cloud store and auto-migrate to Firestore
        try {
            val docId = getCloudPointer("usr_$cleanId")
            if (!docId.isNullOrBlank()) {
                val userJson = fetchDocumentFromCloud(docId)
                if (userJson != null) {
                    val legacyUser = UserAccount(
                        id = userJson.getString("id"),
                        schoolId = userJson.optString("schoolId", "SCH_OAKRIDGE_101"),
                        name = userJson.getString("name"),
                        email = userJson.optString("email", ""),
                        phone = userJson.optString("phone", ""),
                        role = userJson.getString("role"),
                        passwordHash = userJson.getString("passwordHash"),
                        passwordSalt = userJson.optString("passwordSalt", ""),
                        securityQuestion = userJson.optString("securityQuestion", "First school?"),
                        securityAnswer = userJson.optString("securityAnswer", ""),
                        status = userJson.optString("status", AccountStatus.APPROVED.name),
                        assignedClassId = if (userJson.has("assignedClassId") && !userJson.isNull("assignedClassId")) userJson.getString("assignedClassId") else null,
                        linkedStudentIds = userJson.optString("linkedStudentIds", ""),
                        subject = if (userJson.has("subject") && !userJson.isNull("subject")) userJson.getString("subject") else null,
                        joiningDate = if (userJson.has("joiningDate") && !userJson.isNull("joiningDate")) userJson.getString("joiningDate") else null,
                        monthlySalary = if (userJson.has("monthlySalary") && !userJson.isNull("monthlySalary")) userJson.optDouble("monthlySalary") else null,
                        sessionVersion = userJson.optLong("sessionVersion", 1L),
                        createdAt = userJson.optLong("createdAt", System.currentTimeMillis())
                    )

                    // Auto-migrate legacy user into Firestore so future lookups are immediate
                    if (db != null) {
                        try {
                            db.collection("users").document(cleanId)
                                .set(userAccountToMap(legacyUser), SetOptions.merge())
                                .awaitTask()
                            ensureFirebaseAuth(legacyUser)
                        } catch (e: Exception) {
                            Log.w("CloudDatabaseService", "Auto-migration of $cleanId to Firestore notice: ${e.message}")
                        }
                    }

                    return@withContext legacyUser
                }
            }
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Legacy cloud user lookup notice for $cleanId: ${e.message}")
        }

        null
    }

    suspend fun registerCloudUser(user: UserAccount, rawPassword: String? = null): Result<UserAccount> = withContext(Dispatchers.IO) {
        val cleanId = user.id.trim()
        val db = firestore ?: return@withContext Result.success(user)
        try {
            ensureFirebaseAuth(user, rawPassword)
            val docRef = db.collection("users").document(cleanId)
            val existing = docRef.get().awaitTask()
            if (existing.exists()) {
                val existingData = existing.data
                if (existingData != null) {
                    val existingUser = mapToUserAccount(existingData, cleanId)
                    if (!existingUser.name.trim().equals(user.name.trim(), ignoreCase = true) ||
                        !existingUser.schoolId.equals(user.schoolId.trim(), ignoreCase = true)
                    ) {
                        return@withContext Result.failure(Exception("Account ID '$cleanId' is already registered."))
                    }
                }
            }
            docRef.set(userAccountToMap(user), SetOptions.merge()).awaitTask()
            Result.success(user)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "registerCloudUser notice: ${e.message}")
            Result.success(user) // Offline resilience: proceed with local cache
        }
    }

    suspend fun updateCloudUser(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
        val cleanId = user.id.trim()
        val db = firestore ?: return@withContext Result.success(user)
        try {
            db.collection("users").document(cleanId).set(userAccountToMap(user), SetOptions.merge()).awaitTask()
            Result.success(user)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "updateCloudUser notice: ${e.message}")
            Result.success(user)
        }
    }

    suspend fun updateCloudTeacherStatus(teacherId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = teacherId.trim()
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("users").document(cleanId).update(
                mapOf(
                    "status" to status,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "updateCloudTeacherStatus notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun updateCloudUserStatus(userId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        updateCloudTeacherStatus(userId, status)
    }

    suspend fun updateCloudParentStatus(parentId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        updateCloudTeacherStatus(parentId, status)
    }

    suspend fun linkParentStudentInCloud(parentId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanParentId = parentId.trim()
        val cleanStudentId = studentId.trim()
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            val docRef = db.collection("users").document(cleanParentId)
            val doc = docRef.get().awaitTask()
            if (doc.exists()) {
                val currentLinked = (doc.getString("linkedStudentIds") ?: "")
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .toMutableSet()
                currentLinked.add(cleanStudentId)
                docRef.update(
                    mapOf(
                        "linkedStudentIds" to currentLinked.joinToString(","),
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).awaitTask()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "linkParentStudentInCloud notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun unlinkParentStudentInCloud(parentId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanParentId = parentId.trim()
        val cleanStudentId = studentId.trim()
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            val docRef = db.collection("users").document(cleanParentId)
            val doc = docRef.get().awaitTask()
            if (doc.exists()) {
                val currentLinked = (doc.getString("linkedStudentIds") ?: "")
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .toMutableSet()
                currentLinked.remove(cleanStudentId)
                docRef.update(
                    mapOf(
                        "linkedStudentIds" to currentLinked.joinToString(","),
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).awaitTask()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "unlinkParentStudentInCloud notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun updateCloudUserPassword(userId: String, newHash: String, newSalt: String, newSessionVersion: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("users").document(cleanId).update(
                mapOf(
                    "passwordHash" to newHash,
                    "passwordSalt" to newSalt,
                    "sessionVersion" to newSessionVersion,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "updateCloudUserPassword notice: ${e.message}")
            Result.success(Unit)
        }
    }

    // --- Schools in Firestore (/schools/{schoolId}) ---

    suspend fun findCloudSchool(schoolId: String): School? = getCloudSchoolById(schoolId)

    suspend fun getCloudSchoolById(schoolId: String): School? = withContext(Dispatchers.IO) {
        val cleanId = schoolId.trim()
        if (cleanId.isBlank()) return@withContext null
        val db = firestore

        // 1. Check Cloud Firestore
        if (db != null) {
            try {
                val doc = db.collection("schools").document(cleanId).get().awaitTask()
                if (doc.exists()) {
                    val data = doc.data
                    if (data != null) {
                        return@withContext mapToSchool(data, cleanId)
                    }
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Firestore getCloudSchoolById notice: ${e.message}")
            }
        }

        // 2. Check legacy persistent cloud store and auto-migrate to Firestore
        try {
            val docId = getCloudPointer("sch_$cleanId")
            if (!docId.isNullOrBlank()) {
                val sJson = fetchDocumentFromCloud(docId)
                if (sJson != null) {
                    val legacySchool = School(
                        id = sJson.getString("id"),
                        name = sJson.getString("name"),
                        code = sJson.optString("code", ""),
                        address = sJson.optString("address", ""),
                        principalId = sJson.optString("principalId", "PRIN001"),
                        contactEmail = sJson.optString("contactEmail", ""),
                        contactPhone = sJson.optString("contactPhone", ""),
                        currency = sJson.optString("currency", "₹"),
                        currencyCode = sJson.optString("currencyCode", "INR"),
                        createdAt = sJson.optLong("createdAt", System.currentTimeMillis()),
                        currentAcademicYear = sJson.optString("currentAcademicYear", "2026-27")
                    )

                    if (db != null) {
                        try {
                            db.collection("schools").document(cleanId)
                                .set(schoolToMap(legacySchool), SetOptions.merge())
                                .awaitTask()
                        } catch (e: Exception) {
                            Log.w("CloudDatabaseService", "Auto-migration of school $cleanId to Firestore notice: ${e.message}")
                        }
                    }

                    return@withContext legacySchool
                }
            }
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Legacy school lookup notice: ${e.message}")
        }

        null
    }

    suspend fun registerSchool(school: School): Result<School> = withContext(Dispatchers.IO) {
        val cleanId = school.id.trim()
        val db = firestore ?: return@withContext Result.success(school)
        try {
            val docRef = db.collection("schools").document(cleanId)
            docRef.set(schoolToMap(school), SetOptions.merge()).awaitTask()
            Result.success(school)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "registerSchool notice: ${e.message}")
            Result.success(school)
        }
    }

    suspend fun updateCloudSchoolCurrency(schoolId: String, currency: String, currencyCode: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = schoolId.trim()
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(cleanId).update(
                mapOf(
                    "currency" to currency,
                    "currencyCode" to currencyCode,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "updateCloudSchoolCurrency notice: ${e.message}")
            Result.success(Unit)
        }
    }

    // --- Granular Firestore Writes for School Entities ---

    suspend fun saveCloudStudent(schoolId: String, student: Student): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("students").document(student.id.trim())
                .set(studentToMap(student), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudStudent notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudStudent(schoolId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("students").document(studentId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "deleteCloudStudent notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun updateCloudStudentParentUserId(schoolId: String, studentId: String, parentId: String?): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("students").document(studentId.trim())
                .update(
                    mapOf(
                        "parentUserId" to parentId,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "updateCloudStudentParentUserId notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudClass(schoolId: String, cls: SchoolClass): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("classes").document(cls.id.trim())
                .set(classToMap(cls), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudClass notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudEnrollment(schoolId: String, enrollment: StudentEnrollment): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        val docKey = "${enrollment.studentId.trim()}_${enrollment.academicYear.trim()}"
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("enrollments").document(docKey)
                .set(enrollmentToMap(enrollment), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudEnrollment notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudEnrollmentByStudent(schoolId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            val docs = db.collection("schools").document(schoolId.trim())
                .collection("enrollments").whereEqualTo("studentId", studentId.trim())
                .get().awaitTask()
            for (doc in docs.documents) {
                doc.reference.delete().awaitTask()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "deleteCloudEnrollment notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudFee(schoolId: String, fee: StudentFee): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        val docKey = "${fee.studentId.trim()}_${fee.academicYear.trim()}"
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("fees").document(docKey)
                .set(feeToMap(fee), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudFee notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudFeePayment(schoolId: String, payment: FeePayment): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("feePayments").document(payment.id.trim())
                .set(feePaymentToMap(payment), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudFeePayment notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudPayment(schoolId: String, payment: FeePayment): Result<Unit> = saveCloudFeePayment(schoolId, payment)

    suspend fun deleteCloudPayment(schoolId: String, paymentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("feePayments").document(paymentId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudClass(schoolId: String, classId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("classes").document(classId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudSalary(schoolId: String, salaryId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("salaries").document(salaryId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudAnnouncement(schoolId: String, announcementId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("announcements").document(announcementId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudHomework(schoolId: String, homeworkId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("homework").document(homeworkId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudTest(schoolId: String, testId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("tests").document(testId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun deleteCloudLeaveRequest(schoolId: String, leaveId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("leaveRequests").document(leaveId.trim())
                .delete().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.success(Unit)
        }
    }

    suspend fun saveCloudSalary(schoolId: String, salary: TeacherSalary): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("salaries").document(salary.id.trim())
                .set(salaryToMap(salary), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudSalary notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudAttendanceRecord(schoolId: String, record: AttendanceRecord): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("attendance").document(record.id.trim())
                .set(attendanceToMap(record), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudAttendanceRecord notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudAttendanceRecords(schoolId: String, records: List<AttendanceRecord>): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            val batch = db.batch()
            val collection = db.collection("schools").document(schoolId.trim()).collection("attendance")
            records.take(500).forEach { r ->
                val ref = collection.document(r.id.trim())
                batch.set(ref, attendanceToMap(r), SetOptions.merge())
            }
            batch.commit().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudAttendanceRecords notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudAttendanceSubmission(schoolId: String, sub: AttendanceSubmissionRecord): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("attendanceSubmissions").document(sub.id.trim())
                .set(attendanceSubToMap(sub), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudAttendanceSubmission notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudAnnouncement(schoolId: String, announcement: Announcement): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("announcements").document(announcement.id.trim())
                .set(announcementToMap(announcement), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudAnnouncement notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudHomework(schoolId: String, hw: Homework): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("homework").document(hw.id.trim())
                .set(homeworkToMap(hw), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudHomework notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudTest(schoolId: String, test: SchoolTest): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("tests").document(test.id.trim())
                .set(testToMap(test), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudTest notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudMarks(schoolId: String, marks: List<StudentMark>): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            val batch = db.batch()
            val collection = db.collection("schools").document(schoolId.trim()).collection("marks")
            marks.take(500).forEach { m ->
                val ref = collection.document(m.id.trim())
                batch.set(ref, markToMap(m), SetOptions.merge())
            }
            batch.commit().awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudMarks notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudLeaveRequest(schoolId: String, leave: LeaveRequest): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("leaveRequests").document(leave.id.trim())
                .set(leaveToMap(leave), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudLeaveRequest notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudActivity(schoolId: String, activity: ActivityRecord): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("activities").document(activity.id.trim())
                .set(activityToMap(activity), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudActivity notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun saveCloudMessage(message: ChatMessage): Result<ChatMessage> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(message)
        try {
            db.collection("schools").document(message.schoolId.trim())
                .collection("messages").document(message.id.trim())
                .set(messageToMap(message), SetOptions.merge()).awaitTask()
            Result.success(message)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudMessage notice: ${e.message}")
            Result.success(message)
        }
    }

    suspend fun sendCloudMessage(message: ChatMessage): Result<ChatMessage> = saveCloudMessage(message)

    suspend fun getCloudMessages(schoolId: String, studentId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext emptyList()
        try {
            val query = db.collection("schools").document(schoolId.trim())
                .collection("messages")
                .whereEqualTo("studentId", studentId.trim())
                .get().awaitTask()
            query.documents.mapNotNull { doc ->
                doc.data?.let { mapToMessage(it, doc.id) }
            }.sortedBy { it.timestamp }
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "getCloudMessages notice: ${e.message}")
            emptyList()
        }
    }

    suspend fun getCloudMessagesForSchool(schoolId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext emptyList()
        try {
            val query = db.collection("schools").document(schoolId.trim())
                .collection("messages")
                .get().awaitTask()
            query.documents.mapNotNull { doc ->
                doc.data?.let { mapToMessage(it, doc.id) }
            }.sortedBy { it.timestamp }
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "getCloudMessagesForSchool notice: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveCloudAcademicYear(schoolId: String, year: AcademicYear): Result<Unit> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            db.collection("schools").document(schoolId.trim())
                .collection("academicYears").document(year.yearCode.trim())
                .set(academicYearToMap(year), SetOptions.merge()).awaitTask()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "saveCloudAcademicYear notice: ${e.message}")
            Result.success(Unit)
        }
    }

    // --- Bulk Data Synchronization ---

    suspend fun syncSchoolDataToCloud(schoolId: String, bundle: SchoolDataBundle): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = schoolId.trim()
        val db = firestore ?: return@withContext Result.success(Unit)
        try {
            bundle.school?.let { registerSchool(it) }

            // Write students in per-document calls
            bundle.students.forEach { s -> saveCloudStudent(cleanId, s) }
            bundle.classes.forEach { c -> saveCloudClass(cleanId, c) }
            bundle.enrollments.forEach { e -> saveCloudEnrollment(cleanId, e) }
            bundle.fees.forEach { f -> saveCloudFee(cleanId, f) }
            bundle.feePayments.forEach { p -> saveCloudFeePayment(cleanId, p) }
            bundle.salaries.forEach { sal -> saveCloudSalary(cleanId, sal) }
            bundle.announcements.forEach { a -> saveCloudAnnouncement(cleanId, a) }
            bundle.homework.forEach { h -> saveCloudHomework(cleanId, h) }
            bundle.tests.forEach { t -> saveCloudTest(cleanId, t) }
            saveCloudMarks(cleanId, bundle.marks)
            bundle.leaveRequests.forEach { l -> saveCloudLeaveRequest(cleanId, l) }
            bundle.academicYears.forEach { y -> saveCloudAcademicYear(cleanId, y) }
            bundle.users.forEach { u -> registerCloudUser(u) }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "syncSchoolDataToCloud notice: ${e.message}")
            Result.success(Unit)
        }
    }

    suspend fun fetchSchoolDataFromCloud(schoolId: String): SchoolDataBundle? = withContext(Dispatchers.IO) {
        val cleanId = schoolId.trim()
        val db = firestore
        if (db != null) {
            try {
                val school = getCloudSchoolById(cleanId)

                val usersSnapshot = db.collection("users")
                    .whereEqualTo("schoolId", cleanId).get().awaitTask()
                val users = usersSnapshot.documents.mapNotNull { it.data?.let { m -> mapToUserAccount(m, it.id) } }

                val schoolRef = db.collection("schools").document(cleanId)

                val studentsSnap = schoolRef.collection("students").get().awaitTask()
                val students = studentsSnap.documents.mapNotNull { it.data?.let { m -> mapToStudent(m, it.id) } }

                val classesSnap = schoolRef.collection("classes").get().awaitTask()
                val classes = classesSnap.documents.mapNotNull { it.data?.let { m -> mapToClass(m, it.id) } }

                val enrollmentsSnap = schoolRef.collection("enrollments").get().awaitTask()
                val enrollments = enrollmentsSnap.documents.mapNotNull { it.data?.let { m -> mapToEnrollment(m) } }

                val feesSnap = schoolRef.collection("fees").get().awaitTask()
                val fees = feesSnap.documents.mapNotNull { it.data?.let { m -> mapToFee(m) } }

                val feePaymentsSnap = schoolRef.collection("feePayments").get().awaitTask()
                val feePayments = feePaymentsSnap.documents.mapNotNull { it.data?.let { m -> mapToFeePayment(m, it.id) } }

                val salariesSnap = schoolRef.collection("salaries").get().awaitTask()
                val salaries = salariesSnap.documents.mapNotNull { it.data?.let { m -> mapToSalary(m, it.id) } }

                val attendanceSnap = schoolRef.collection("attendance").get().awaitTask()
                val attendance = attendanceSnap.documents.mapNotNull { it.data?.let { m -> mapToAttendance(m, it.id) } }

                val submissionsSnap = schoolRef.collection("attendanceSubmissions").get().awaitTask()
                val submissions = submissionsSnap.documents.mapNotNull { it.data?.let { m -> mapToAttendanceSubmission(m, it.id) } }

                val announcementsSnap = schoolRef.collection("announcements").get().awaitTask()
                val announcements = announcementsSnap.documents.mapNotNull { it.data?.let { m -> mapToAnnouncement(m, it.id) } }

                val homeworkSnap = schoolRef.collection("homework").get().awaitTask()
                val homework = homeworkSnap.documents.mapNotNull { it.data?.let { m -> mapToHomework(m, it.id) } }

                val testsSnap = schoolRef.collection("tests").get().awaitTask()
                val tests = testsSnap.documents.mapNotNull { it.data?.let { m -> mapToTest(m, it.id) } }

                val marksSnap = schoolRef.collection("marks").get().awaitTask()
                val marks = marksSnap.documents.mapNotNull { it.data?.let { m -> mapToMark(m, it.id) } }

                val leavesSnap = schoolRef.collection("leaveRequests").get().awaitTask()
                val leaves = leavesSnap.documents.mapNotNull { it.data?.let { m -> mapToLeave(m, it.id) } }

                val activitiesSnap = schoolRef.collection("activities").get().awaitTask()
                val activities = activitiesSnap.documents.mapNotNull { it.data?.let { m -> mapToActivity(m, it.id) } }

                val messagesSnap = schoolRef.collection("messages").get().awaitTask()
                val messages = messagesSnap.documents.mapNotNull { it.data?.let { m -> mapToMessage(m, it.id) } }

                val yearsSnap = schoolRef.collection("academicYears").get().awaitTask()
                val years = yearsSnap.documents.mapNotNull { it.data?.let { m -> mapToAcademicYear(m) } }

                if (school != null || students.isNotEmpty() || classes.isNotEmpty() || users.isNotEmpty()) {
                    return@withContext SchoolDataBundle(
                        schoolId = cleanId,
                        lastUpdated = System.currentTimeMillis(),
                        school = school,
                        users = users,
                        classes = classes,
                        students = students,
                        announcements = announcements,
                        homework = homework,
                        tests = tests,
                        marks = marks,
                        attendance = attendance,
                        attendanceSubmissions = submissions,
                        fees = fees,
                        feePayments = feePayments,
                        salaries = salaries,
                        leaveRequests = leaves,
                        activityRecords = activities,
                        messages = messages,
                        academicYears = years,
                        enrollments = enrollments
                    )
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "fetchSchoolDataFromCloud notice: ${e.message}")
            }
        }

        // Fallback to legacy cloud document store and auto-migrate to Firestore
        try {
            val docId = getCloudPointer("sch_doc_$cleanId") ?: getCloudPointer("bnd_$cleanId")
            if (!docId.isNullOrBlank()) {
                val bundleJson = fetchDocumentFromCloud(docId)
                if (bundleJson != null) {
                    val bundle = SchoolDataBundle.fromJson(bundleJson)
                    // Auto-sync into Firestore so future fetches hit Firestore
                    syncSchoolDataToCloud(cleanId, bundle)
                    return@withContext bundle
                }
            }
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Legacy school bundle fetch notice: ${e.message}")
        }

        null
    }

    // --- Real-Time Listeners for Cross-Device Synchronization ---

    fun stopRealtimeSchoolListeners() {
        activeListeners.forEach { it.remove() }
        activeListeners.clear()
    }

    fun startRealtimeSchoolListeners(schoolId: String, listener: CloudDataChangeListener) {
        stopRealtimeSchoolListeners()
        val cleanId = schoolId.trim()
        val db = firestore ?: return
        val schoolRef = db.collection("schools").document(cleanId)

        // 1. Students Listener
        try {
            val reg = schoolRef.collection("students").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val changedStudents = mutableListOf<Student>()
                val removedIds = mutableListOf<String>()
                for (docChange in snapshot.documentChanges) {
                    when (docChange.type) {
                        DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                            val data = docChange.document.data
                            changedStudents.add(mapToStudent(data, docChange.document.id))
                        }
                        DocumentChange.Type.REMOVED -> {
                            removedIds.add(docChange.document.id)
                        }
                    }
                }
                if (changedStudents.isNotEmpty() || removedIds.isNotEmpty()) {
                    listener.onStudentsChanged(changedStudents, removedIds)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 2. Users Listener (Pending & Approved Teachers, Parents)
        try {
            val reg = db.collection("users").whereEqualTo("schoolId", cleanId).addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val users = snapshot.documents.mapNotNull { it.data?.let { m -> mapToUserAccount(m, it.id) } }
                if (users.isNotEmpty()) {
                    listener.onUsersChanged(users)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 3. Classes Listener
        try {
            val reg = schoolRef.collection("classes").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val classes = snapshot.documents.mapNotNull { it.data?.let { m -> mapToClass(m, it.id) } }
                if (classes.isNotEmpty()) {
                    listener.onClassesChanged(classes)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 4. Enrollments Listener
        try {
            val reg = schoolRef.collection("enrollments").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val enrollments = snapshot.documents.mapNotNull { it.data?.let { m -> mapToEnrollment(m) } }
                if (enrollments.isNotEmpty()) {
                    listener.onEnrollmentsChanged(enrollments)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 5. Fees Listener
        try {
            val reg = schoolRef.collection("fees").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val fees = snapshot.documents.mapNotNull { it.data?.let { m -> mapToFee(m) } }
                if (fees.isNotEmpty()) {
                    listener.onFeesChanged(fees)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 6. Fee Payments Listener
        try {
            val reg = schoolRef.collection("feePayments").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val payments = snapshot.documents.mapNotNull { it.data?.let { m -> mapToFeePayment(m, it.id) } }
                if (payments.isNotEmpty()) {
                    listener.onFeePaymentsChanged(payments)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 7. Announcements Listener
        try {
            val reg = schoolRef.collection("announcements").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val announcements = snapshot.documents.mapNotNull { it.data?.let { m -> mapToAnnouncement(m, it.id) } }
                if (announcements.isNotEmpty()) {
                    listener.onAnnouncementsChanged(announcements)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 8. Homework Listener
        try {
            val reg = schoolRef.collection("homework").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val hw = snapshot.documents.mapNotNull { it.data?.let { m -> mapToHomework(m, it.id) } }
                if (hw.isNotEmpty()) {
                    listener.onHomeworkChanged(hw)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 9. Leave Requests Listener
        try {
            val reg = schoolRef.collection("leaveRequests").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val leaves = snapshot.documents.mapNotNull { it.data?.let { m -> mapToLeave(m, it.id) } }
                if (leaves.isNotEmpty()) {
                    listener.onLeaveRequestsChanged(leaves)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 10. Messages Listener
        try {
            val reg = schoolRef.collection("messages").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val msgs = snapshot.documents.mapNotNull { it.data?.let { m -> mapToMessage(m, it.id) } }
                if (msgs.isNotEmpty()) {
                    listener.onMessagesChanged(msgs)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }

        // 11. Salaries Listener
        try {
            val reg = schoolRef.collection("salaries").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val salaries = snapshot.documents.mapNotNull { it.data?.let { m -> mapToSalary(m, it.id) } }
                if (salaries.isNotEmpty()) {
                    listener.onSalariesChanged(salaries)
                }
            }
            activeListeners.add(reg)
        } catch (e: Exception) {
            Log.w("CloudDatabaseService", "Listener error: ${e.message}")
        }
    }

    // --- Entity Mappers ---

    private fun userAccountToMap(u: UserAccount): Map<String, Any?> = mapOf(
        "id" to u.id,
        "schoolId" to u.schoolId,
        "name" to u.name,
        "email" to u.email,
        "phone" to u.phone,
        "role" to u.role,
        "passwordHash" to u.passwordHash,
        "passwordSalt" to u.passwordSalt,
        "securityQuestion" to u.securityQuestion,
        "securityAnswer" to u.securityAnswer,
        "status" to u.status,
        "assignedClassId" to u.assignedClassId,
        "linkedStudentIds" to u.linkedStudentIds,
        "subject" to u.subject,
        "joiningDate" to u.joiningDate,
        "monthlySalary" to u.monthlySalary,
        "sessionVersion" to u.sessionVersion,
        "createdAt" to u.createdAt,
        "updatedAt" to System.currentTimeMillis()
    )

    private fun mapToUserAccount(m: Map<String, Any?>, fallbackId: String): UserAccount = UserAccount(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "SCH_OAKRIDGE_101",
        name = (m["name"] as? String) ?: "",
        email = (m["email"] as? String) ?: "",
        phone = (m["phone"] as? String) ?: "",
        role = (m["role"] as? String) ?: UserRole.PRINCIPAL.name,
        passwordHash = (m["passwordHash"] as? String) ?: "",
        passwordSalt = (m["passwordSalt"] as? String) ?: "",
        securityQuestion = (m["securityQuestion"] as? String) ?: "",
        securityAnswer = (m["securityAnswer"] as? String) ?: "",
        status = (m["status"] as? String) ?: AccountStatus.APPROVED.name,
        assignedClassId = (m["assignedClassId"] as? String)?.ifBlank { null },
        linkedStudentIds = (m["linkedStudentIds"] as? String) ?: "",
        subject = (m["subject"] as? String)?.ifBlank { null },
        joiningDate = (m["joiningDate"] as? String)?.ifBlank { null },
        monthlySalary = (m["monthlySalary"] as? Number)?.toDouble(),
        sessionVersion = (m["sessionVersion"] as? Number)?.toLong() ?: 1L,
        createdAt = (m["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
    )

    private fun schoolToMap(s: School): Map<String, Any?> = mapOf(
        "id" to s.id,
        "name" to s.name,
        "code" to s.code,
        "address" to s.address,
        "principalId" to s.principalId,
        "contactEmail" to s.contactEmail,
        "contactPhone" to s.contactPhone,
        "currency" to s.currency,
        "currencyCode" to s.currencyCode,
        "createdAt" to s.createdAt,
        "currentAcademicYear" to s.currentAcademicYear,
        "updatedAt" to System.currentTimeMillis()
    )

    private fun mapToSchool(m: Map<String, Any?>, fallbackId: String): School = School(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        name = (m["name"] as? String) ?: "",
        code = (m["code"] as? String) ?: "",
        address = (m["address"] as? String) ?: "",
        principalId = (m["principalId"] as? String) ?: "PRIN001",
        contactEmail = (m["contactEmail"] as? String) ?: "",
        contactPhone = (m["contactPhone"] as? String) ?: "",
        currency = (m["currency"] as? String) ?: "₹",
        currencyCode = (m["currencyCode"] as? String) ?: "INR",
        createdAt = (m["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        currentAcademicYear = (m["currentAcademicYear"] as? String) ?: "2026-27"
    )

    private fun studentToMap(s: Student): Map<String, Any?> = mapOf(
        "id" to s.id,
        "schoolId" to s.schoolId,
        "rollNumber" to s.rollNumber,
        "name" to s.name,
        "classId" to s.classId,
        "gender" to s.gender,
        "parentName" to s.parentName,
        "parentPhone" to s.parentPhone,
        "parentUserId" to s.parentUserId,
        "emergencyContact" to s.emergencyContact,
        "address" to s.address,
        "updatedAt" to System.currentTimeMillis()
    )

    private fun mapToStudent(m: Map<String, Any?>, fallbackId: String): Student = Student(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        rollNumber = (m["rollNumber"] as? String) ?: "",
        name = (m["name"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        gender = (m["gender"] as? String) ?: "Male",
        parentName = (m["parentName"] as? String) ?: "",
        parentPhone = (m["parentPhone"] as? String) ?: "",
        parentUserId = (m["parentUserId"] as? String)?.ifBlank { null },
        emergencyContact = (m["emergencyContact"] as? String) ?: "",
        address = (m["address"] as? String) ?: ""
    )

    private fun classToMap(c: SchoolClass): Map<String, Any?> = mapOf(
        "id" to c.id,
        "schoolId" to c.schoolId,
        "name" to c.name,
        "grade" to c.grade,
        "section" to c.section,
        "classTeacherId" to c.classTeacherId,
        "roomNumber" to c.roomNumber,
        "updatedAt" to System.currentTimeMillis()
    )

    private fun mapToClass(m: Map<String, Any?>, fallbackId: String): SchoolClass = SchoolClass(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        name = (m["name"] as? String) ?: "",
        grade = (m["grade"] as? String) ?: "",
        section = (m["section"] as? String) ?: "",
        classTeacherId = (m["classTeacherId"] as? String)?.ifBlank { null },
        roomNumber = (m["roomNumber"] as? String) ?: ""
    )

    private fun enrollmentToMap(e: StudentEnrollment): Map<String, Any?> = mapOf(
        "studentId" to e.studentId,
        "schoolId" to e.schoolId,
        "academicYear" to e.academicYear,
        "classId" to e.classId,
        "rollNumber" to e.rollNumber,
        "status" to e.status,
        "promotedFromYear" to e.promotedFromYear,
        "promotedFromClassId" to e.promotedFromClassId,
        "promotionDate" to e.promotionDate,
        "remarks" to e.remarks,
        "createdAt" to e.createdAt,
        "updatedAt" to System.currentTimeMillis()
    )

    private fun mapToEnrollment(m: Map<String, Any?>): StudentEnrollment = StudentEnrollment(
        studentId = (m["studentId"] as? String) ?: "",
        schoolId = (m["schoolId"] as? String) ?: "",
        academicYear = (m["academicYear"] as? String) ?: "2026-27",
        classId = (m["classId"] as? String) ?: "",
        rollNumber = (m["rollNumber"] as? String) ?: "",
        status = (m["status"] as? String) ?: "ACTIVE",
        promotedFromYear = (m["promotedFromYear"] as? String)?.ifBlank { null },
        promotedFromClassId = (m["promotedFromClassId"] as? String)?.ifBlank { null },
        promotionDate = (m["promotionDate"] as? Number)?.toLong(),
        remarks = (m["remarks"] as? String)?.ifBlank { null },
        createdAt = (m["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
    )

    private fun feeToMap(f: StudentFee): Map<String, Any?> = mapOf(
        "studentId" to f.studentId,
        "schoolId" to f.schoolId,
        "studentName" to f.studentName,
        "rollNumber" to f.rollNumber,
        "classId" to f.classId,
        "totalFee" to f.totalFee,
        "totalPaid" to f.totalPaid,
        "remainingFee" to f.remainingFee,
        "status" to f.status,
        "lastPaymentDate" to f.lastPaymentDate,
        "currency" to f.currency,
        "updatedAt" to f.updatedAt,
        "academicYear" to f.academicYear
    )

    private fun mapToFee(m: Map<String, Any?>): StudentFee = StudentFee(
        studentId = (m["studentId"] as? String) ?: "",
        schoolId = (m["schoolId"] as? String) ?: "",
        studentName = (m["studentName"] as? String) ?: "",
        rollNumber = (m["rollNumber"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        totalFee = (m["totalFee"] as? Number)?.toDouble() ?: 0.0,
        totalPaid = (m["totalPaid"] as? Number)?.toDouble() ?: 0.0,
        remainingFee = (m["remainingFee"] as? Number)?.toDouble() ?: 0.0,
        status = (m["status"] as? String) ?: "UNPAID",
        lastPaymentDate = (m["lastPaymentDate"] as? String)?.ifBlank { null },
        currency = (m["currency"] as? String) ?: "₹",
        updatedAt = (m["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun feePaymentToMap(p: FeePayment): Map<String, Any?> = mapOf(
        "id" to p.id,
        "schoolId" to p.schoolId,
        "studentId" to p.studentId,
        "studentName" to p.studentName,
        "rollNumber" to p.rollNumber,
        "classId" to p.classId,
        "amount" to p.amount,
        "date" to p.date,
        "paymentMode" to p.paymentMode,
        "note" to p.note,
        "receiptNumber" to p.receiptNumber,
        "recordedBy" to p.recordedBy,
        "currency" to p.currency,
        "timestamp" to p.timestamp,
        "academicYear" to p.academicYear
    )

    private fun mapToFeePayment(m: Map<String, Any?>, fallbackId: String): FeePayment = FeePayment(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        studentId = (m["studentId"] as? String) ?: "",
        studentName = (m["studentName"] as? String) ?: "",
        rollNumber = (m["rollNumber"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        amount = (m["amount"] as? Number)?.toDouble() ?: 0.0,
        date = (m["date"] as? String) ?: "",
        paymentMode = (m["paymentMode"] as? String) ?: "Cash",
        note = (m["note"] as? String) ?: "",
        receiptNumber = (m["receiptNumber"] as? String) ?: "",
        recordedBy = (m["recordedBy"] as? String) ?: "Principal",
        currency = (m["currency"] as? String) ?: "₹",
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun salaryToMap(s: TeacherSalary): Map<String, Any?> = mapOf(
        "id" to s.id,
        "schoolId" to s.schoolId,
        "teacherId" to s.teacherId,
        "teacherName" to s.teacherName,
        "month" to s.month,
        "monthlySalary" to s.monthlySalary,
        "amountPaid" to s.amountPaid,
        "paymentDate" to s.paymentDate,
        "remainingAmount" to s.remainingAmount,
        "currency" to s.currency,
        "paymentMode" to s.paymentMode,
        "transactionRef" to s.transactionRef,
        "remarks" to s.remarks,
        "status" to s.status,
        "recordedBy" to s.recordedBy,
        "timestamp" to s.timestamp
    )

    private fun mapToSalary(m: Map<String, Any?>, fallbackId: String): TeacherSalary = TeacherSalary(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        teacherId = (m["teacherId"] as? String) ?: "",
        teacherName = (m["teacherName"] as? String) ?: "",
        month = (m["month"] as? String) ?: "",
        monthlySalary = (m["monthlySalary"] as? Number)?.toDouble() ?: 0.0,
        amountPaid = (m["amountPaid"] as? Number)?.toDouble() ?: 0.0,
        paymentDate = (m["paymentDate"] as? String) ?: "",
        remainingAmount = (m["remainingAmount"] as? Number)?.toDouble() ?: 0.0,
        currency = (m["currency"] as? String) ?: "₹",
        paymentMode = (m["paymentMode"] as? String) ?: "Bank Transfer",
        transactionRef = (m["transactionRef"] as? String) ?: "",
        remarks = (m["remarks"] as? String) ?: "",
        status = (m["status"] as? String) ?: "PAID",
        recordedBy = (m["recordedBy"] as? String) ?: "Principal",
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
    )

    private fun attendanceToMap(a: AttendanceRecord): Map<String, Any?> = mapOf(
        "id" to a.id,
        "schoolId" to a.schoolId,
        "date" to a.date,
        "studentId" to a.studentId,
        "studentName" to a.studentName,
        "rollNumber" to a.rollNumber,
        "classId" to a.classId,
        "status" to a.status,
        "markedByTeacherId" to a.markedByTeacherId,
        "remarks" to a.remarks,
        "isSubmitted" to a.isSubmitted,
        "timestamp" to a.timestamp,
        "academicYear" to a.academicYear
    )

    private fun mapToAttendance(m: Map<String, Any?>, fallbackId: String): AttendanceRecord = AttendanceRecord(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        date = (m["date"] as? String) ?: "",
        studentId = (m["studentId"] as? String) ?: "",
        studentName = (m["studentName"] as? String) ?: "",
        rollNumber = (m["rollNumber"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        status = (m["status"] as? String) ?: AttendanceStatus.PRESENT.name,
        markedByTeacherId = (m["markedByTeacherId"] as? String) ?: "",
        remarks = (m["remarks"] as? String)?.ifBlank { null },
        isSubmitted = (m["isSubmitted"] as? Boolean) ?: true,
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun attendanceSubToMap(s: AttendanceSubmissionRecord): Map<String, Any?> = mapOf(
        "id" to s.id,
        "schoolId" to s.schoolId,
        "date" to s.date,
        "classId" to s.classId,
        "className" to s.className,
        "classTeacherId" to s.classTeacherId,
        "classTeacherName" to s.classTeacherName,
        "totalStudents" to s.totalStudents,
        "presentStudents" to s.presentStudents,
        "absentStudents" to s.absentStudents,
        "absentStudentNames" to s.absentStudentNames,
        "absentNotes" to s.absentNotes,
        "submittedStatus" to s.submittedStatus,
        "submittedAt" to s.submittedAt,
        "academicYear" to s.academicYear
    )

    private fun mapToAttendanceSubmission(m: Map<String, Any?>, fallbackId: String): AttendanceSubmissionRecord = AttendanceSubmissionRecord(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        date = (m["date"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        className = (m["className"] as? String) ?: "",
        classTeacherId = (m["classTeacherId"] as? String) ?: "",
        classTeacherName = (m["classTeacherName"] as? String) ?: "",
        totalStudents = (m["totalStudents"] as? Number)?.toInt() ?: 0,
        presentStudents = (m["presentStudents"] as? Number)?.toInt() ?: 0,
        absentStudents = (m["absentStudents"] as? Number)?.toInt() ?: 0,
        absentStudentNames = (m["absentStudentNames"] as? String) ?: "None",
        absentNotes = (m["absentNotes"] as? String) ?: "No notes",
        submittedStatus = (m["submittedStatus"] as? String) ?: "SUBMITTED",
        submittedAt = (m["submittedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun announcementToMap(a: Announcement): Map<String, Any?> = mapOf(
        "id" to a.id,
        "schoolId" to a.schoolId,
        "title" to a.title,
        "content" to a.content,
        "targetAudience" to a.targetAudience,
        "priority" to a.priority,
        "authorName" to a.authorName,
        "date" to a.date,
        "timestamp" to a.timestamp
    )

    private fun mapToAnnouncement(m: Map<String, Any?>, fallbackId: String): Announcement = Announcement(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        title = (m["title"] as? String) ?: "",
        content = (m["content"] as? String) ?: "",
        targetAudience = (m["targetAudience"] as? String) ?: AnnouncementTarget.ALL_SCHOOL,
        priority = (m["priority"] as? String) ?: AnnouncementPriority.NORMAL.name,
        authorName = (m["authorName"] as? String) ?: "Principal",
        date = (m["date"] as? String) ?: "",
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
    )

    private fun homeworkToMap(h: Homework): Map<String, Any?> = mapOf(
        "id" to h.id,
        "schoolId" to h.schoolId,
        "classId" to h.classId,
        "teacherId" to h.teacherId,
        "teacherName" to h.teacherName,
        "subject" to h.subject,
        "title" to h.title,
        "description" to h.description,
        "assignedDate" to h.assignedDate,
        "dueDate" to h.dueDate,
        "status" to h.status,
        "academicYear" to h.academicYear
    )

    private fun mapToHomework(m: Map<String, Any?>, fallbackId: String): Homework = Homework(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        teacherId = (m["teacherId"] as? String) ?: "",
        teacherName = (m["teacherName"] as? String) ?: "",
        subject = (m["subject"] as? String) ?: "",
        title = (m["title"] as? String) ?: "",
        description = (m["description"] as? String) ?: "",
        assignedDate = (m["assignedDate"] as? String) ?: "",
        dueDate = (m["dueDate"] as? String) ?: "",
        status = (m["status"] as? String) ?: "ACTIVE",
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun testToMap(t: SchoolTest): Map<String, Any?> = mapOf(
        "id" to t.id,
        "schoolId" to t.schoolId,
        "classId" to t.classId,
        "className" to t.className,
        "testName" to t.testName,
        "subject" to t.subject,
        "date" to t.date,
        "maxMarks" to t.maxMarks,
        "createdByTeacherId" to t.createdByTeacherId,
        "createdByTeacherName" to t.createdByTeacherName,
        "totalStudents" to t.totalStudents,
        "averageScore" to t.averageScore,
        "highestScore" to t.highestScore,
        "timestamp" to t.timestamp,
        "academicYear" to t.academicYear
    )

    private fun mapToTest(m: Map<String, Any?>, fallbackId: String): SchoolTest = SchoolTest(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        className = (m["className"] as? String) ?: "",
        testName = (m["testName"] as? String) ?: "",
        subject = (m["subject"] as? String) ?: "",
        date = (m["date"] as? String) ?: "",
        maxMarks = (m["maxMarks"] as? Number)?.toDouble() ?: 100.0,
        createdByTeacherId = (m["createdByTeacherId"] as? String) ?: "",
        createdByTeacherName = (m["createdByTeacherName"] as? String) ?: "",
        totalStudents = (m["totalStudents"] as? Number)?.toInt() ?: 0,
        averageScore = (m["averageScore"] as? Number)?.toDouble() ?: 0.0,
        highestScore = (m["highestScore"] as? Number)?.toDouble() ?: 0.0,
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun markToMap(m: StudentMark): Map<String, Any?> = mapOf(
        "id" to m.id,
        "testId" to m.testId,
        "schoolId" to m.schoolId,
        "studentId" to m.studentId,
        "studentName" to m.studentName,
        "rollNumber" to m.rollNumber,
        "classId" to m.classId,
        "examName" to m.examName,
        "subject" to m.subject,
        "maxMarks" to m.maxMarks,
        "marksObtained" to m.marksObtained,
        "percentage" to m.percentage,
        "rank" to m.rank,
        "grade" to m.grade,
        "remarks" to m.remarks,
        "date" to m.date,
        "timestamp" to m.timestamp,
        "academicYear" to m.academicYear
    )

    private fun mapToMark(m: Map<String, Any?>, fallbackId: String): StudentMark = StudentMark(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        testId = (m["testId"] as? String) ?: "",
        schoolId = (m["schoolId"] as? String) ?: "",
        studentId = (m["studentId"] as? String) ?: "",
        studentName = (m["studentName"] as? String) ?: "",
        rollNumber = (m["rollNumber"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        examName = (m["examName"] as? String) ?: "",
        subject = (m["subject"] as? String) ?: "",
        maxMarks = (m["maxMarks"] as? Number)?.toDouble() ?: 100.0,
        marksObtained = (m["marksObtained"] as? Number)?.toDouble() ?: 0.0,
        percentage = (m["percentage"] as? Number)?.toDouble() ?: 0.0,
        rank = (m["rank"] as? Number)?.toInt() ?: 1,
        grade = (m["grade"] as? String) ?: "A",
        remarks = (m["remarks"] as? String)?.ifBlank { null },
        date = (m["date"] as? String) ?: "",
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        academicYear = (m["academicYear"] as? String) ?: "2026-27"
    )

    private fun leaveToMap(l: LeaveRequest): Map<String, Any?> = mapOf(
        "id" to l.id,
        "schoolId" to l.schoolId,
        "teacherId" to l.teacherId,
        "teacherName" to l.teacherName,
        "leaveType" to l.leaveType,
        "startDate" to l.startDate,
        "endDate" to l.endDate,
        "daysCount" to l.daysCount,
        "reason" to l.reason,
        "status" to l.status,
        "principalComment" to l.principalComment,
        "appliedAt" to l.appliedAt
    )

    private fun mapToLeave(m: Map<String, Any?>, fallbackId: String): LeaveRequest = LeaveRequest(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        teacherId = (m["teacherId"] as? String) ?: "",
        teacherName = (m["teacherName"] as? String) ?: "",
        leaveType = (m["leaveType"] as? String) ?: LeaveType.CASUAL.name,
        startDate = (m["startDate"] as? String) ?: "",
        endDate = (m["endDate"] as? String) ?: "",
        daysCount = (m["daysCount"] as? Number)?.toInt() ?: 1,
        reason = (m["reason"] as? String) ?: "",
        status = (m["status"] as? String) ?: LeaveStatus.PENDING.name,
        principalComment = (m["principalComment"] as? String)?.ifBlank { null },
        appliedAt = (m["appliedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
    )

    private fun activityToMap(a: ActivityRecord): Map<String, Any?> = mapOf(
        "id" to a.id,
        "schoolId" to a.schoolId,
        "date" to a.date,
        "time" to a.time,
        "timestamp" to a.timestamp,
        "category" to a.category,
        "personName" to a.personName,
        "personRole" to a.personRole,
        "personId" to a.personId,
        "classId" to a.classId,
        "className" to a.className,
        "action" to a.action,
        "amount" to a.amount,
        "marks" to a.marks,
        "details" to a.details,
        "performedBy" to a.performedBy
    )

    private fun mapToActivity(m: Map<String, Any?>, fallbackId: String): ActivityRecord = ActivityRecord(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        date = (m["date"] as? String) ?: "",
        time = (m["time"] as? String) ?: "",
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        category = (m["category"] as? String) ?: "OTHER",
        personName = (m["personName"] as? String) ?: "",
        personRole = (m["personRole"] as? String) ?: "STUDENT",
        personId = (m["personId"] as? String) ?: "",
        classId = (m["classId"] as? String) ?: "",
        className = (m["className"] as? String) ?: "",
        action = (m["action"] as? String) ?: "",
        amount = (m["amount"] as? Number)?.toDouble(),
        marks = (m["marks"] as? String)?.ifBlank { null },
        details = (m["details"] as? String) ?: "",
        performedBy = (m["performedBy"] as? String) ?: "Principal"
    )

    private fun messageToMap(msg: ChatMessage): Map<String, Any?> = mapOf(
        "id" to msg.id,
        "schoolId" to msg.schoolId,
        "studentId" to msg.studentId,
        "studentName" to msg.studentName,
        "senderId" to msg.senderId,
        "senderName" to msg.senderName,
        "senderRole" to msg.senderRole,
        "receiverId" to msg.receiverId,
        "receiverName" to msg.receiverName,
        "receiverRole" to msg.receiverRole,
        "message" to msg.message,
        "timestamp" to msg.timestamp,
        "status" to msg.status
    )

    private fun mapToMessage(m: Map<String, Any?>, fallbackId: String): ChatMessage = ChatMessage(
        id = (m["id"] as? String)?.ifBlank { null } ?: fallbackId,
        schoolId = (m["schoolId"] as? String) ?: "",
        studentId = (m["studentId"] as? String) ?: "",
        studentName = (m["studentName"] as? String) ?: "",
        senderId = (m["senderId"] as? String) ?: "",
        senderName = (m["senderName"] as? String) ?: "",
        senderRole = (m["senderRole"] as? String) ?: "PRINCIPAL",
        receiverId = (m["receiverId"] as? String) ?: "",
        receiverName = (m["receiverName"] as? String) ?: "",
        receiverRole = (m["receiverRole"] as? String) ?: "TEACHER",
        message = (m["message"] as? String) ?: "",
        timestamp = (m["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
        status = (m["status"] as? String) ?: "SENT"
    )

    private fun academicYearToMap(y: AcademicYear): Map<String, Any?> = mapOf(
        "schoolId" to y.schoolId,
        "yearCode" to y.yearCode,
        "displayName" to y.displayName,
        "isCurrent" to y.isCurrent,
        "startDate" to y.startDate,
        "endDate" to y.endDate,
        "status" to y.status,
        "createdAt" to y.createdAt
    )

    private fun mapToAcademicYear(m: Map<String, Any?>): AcademicYear = AcademicYear(
        schoolId = (m["schoolId"] as? String) ?: "",
        yearCode = (m["yearCode"] as? String) ?: "2026-27",
        displayName = (m["displayName"] as? String) ?: "Academic Year 2026-27",
        isCurrent = (m["isCurrent"] as? Boolean) ?: false,
        startDate = (m["startDate"] as? String) ?: "",
        endDate = (m["endDate"] as? String) ?: "",
        status = (m["status"] as? String) ?: "ACTIVE",
        createdAt = (m["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
    )

    companion object {
        @Volatile
        private var INSTANCE: CloudDatabaseService? = null

        fun getInstance(context: Context): CloudDatabaseService {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudDatabaseService(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
