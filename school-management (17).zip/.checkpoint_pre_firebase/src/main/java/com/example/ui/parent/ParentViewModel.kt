package com.example.ui.parent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AcademicYear
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.School
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentEnrollment
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.data.session.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class ParentTab {
    OVERVIEW,
    MESSAGES,
    ATTENDANCE,
    HOMEWORK,
    MARKS,
    FEES,
    ANNOUNCEMENTS,
    PROFILE
}

data class ChildAttendanceStats(
    val totalDays: Int = 0,
    val presentDays: Int = 0,
    val absentDays: Int = 0,
    val lateDays: Int = 0,
    val excusedDays: Int = 0,
    val percentage: Double = 0.0
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class ParentViewModel(
    val repository: SchoolRepository,
    val parentId: String
) : ViewModel() {

    val sessionState: StateFlow<UserSession?> = repository.sessionState

    private val _currentTab = MutableStateFlow(ParentTab.OVERVIEW)
    val currentTab: StateFlow<ParentTab> = _currentTab.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    val parentProfile: StateFlow<UserAccount?> = repository.getUserByIdFlow(parentId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // School Details
    val schoolDetails: StateFlow<School?> = repository.getSchoolByIdFlow(repository.currentSchoolId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Academic Year Management
    val academicYears: StateFlow<List<AcademicYear>> = repository.getAllAcademicYears()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentAcademicYear: StateFlow<AcademicYear?> = repository.getCurrentAcademicYearFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedAcademicYear = MutableStateFlow<String>("2026-27")
    val selectedAcademicYear: StateFlow<String> = _selectedAcademicYear.asStateFlow()

    val isViewingHistoricalYear: StateFlow<Boolean> = combine(
        _selectedAcademicYear,
        currentAcademicYear
    ) { selected, current ->
        if (current != null) selected != current.yearCode else false
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun selectAcademicYear(yearCode: String) {
        _selectedAcademicYear.value = yearCode.trim()
    }

    init {
        viewModelScope.launch {
            repository.validateSession()
        }
        viewModelScope.launch {
            repository.getCurrentAcademicYearFlow().collect { year ->
                if (year != null && _selectedAcademicYear.value.isBlank()) {
                    _selectedAcademicYear.value = year.yearCode
                }
            }
        }
    }

    // Linked children (Strictly requires APPROVED status and explicit linking by Student ID or parentUserId)
    val linkedChildren: StateFlow<List<Student>> = parentProfile.flatMapLatest { profile ->
        if (profile == null || profile.status != AccountStatus.APPROVED.name) return@flatMapLatest flowOf(emptyList())
        val ids = profile.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        repository.getAllStudents().map { all ->
            all.filter { ids.contains(it.id) || it.parentUserId == parentId }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedChildId = MutableStateFlow<String?>(null)
    val selectedChildId: StateFlow<String?> = _selectedChildId.asStateFlow()

    val selectedChild: StateFlow<Student?> = kotlinx.coroutines.flow.combine(
        linkedChildren,
        _selectedChildId
    ) { children, selectedId ->
        if (children.isEmpty()) null
        else if (selectedId != null) children.find { it.id == selectedId } ?: children.firstOrNull()
        else children.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Child's Multi-Year Enrollment History
    val childEnrollments: StateFlow<List<StudentEnrollment>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getEnrollmentsForStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected child's Class info
    val childClass: StateFlow<SchoolClass?> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getClassByIdFlow(child.classId)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Class Teacher
    val classTeacher: StateFlow<UserAccount?> = childClass.flatMapLatest { cls ->
        if (cls?.classTeacherId != null) repository.getUserByIdFlow(cls.classTeacherId)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Attendance history (Filtered by selected academic year)
    val childAttendanceHistory: StateFlow<List<AttendanceRecord>> = combine(
        selectedChild,
        _selectedAcademicYear
    ) { child, year -> Pair(child, year) }.flatMapLatest { (child, year) ->
        if (child != null) repository.getAttendanceForStudent(child.id).map { list ->
            list.filter { it.academicYear == year }
        }
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Child Attendance Stats
    val attendanceStats: StateFlow<ChildAttendanceStats> = childAttendanceHistory.map { rawRecords ->
        val records = rawRecords
            .groupBy { it.date }
            .mapValues { (_, recList) -> recList.maxByOrNull { it.timestamp } ?: recList.first() }
            .values
            .toList()

        if (records.isEmpty()) {
            ChildAttendanceStats()
        } else {
            val total = records.size
            val present = records.count { it.status.equals("PRESENT", ignoreCase = true) }
            val absent = records.count { it.status.equals("ABSENT", ignoreCase = true) }
            val late = records.count { it.status.equals("LATE", ignoreCase = true) }
            val excused = records.count { it.status.equals("EXCUSED", ignoreCase = true) }
            val attended = (present + late).coerceAtMost(total)
            val pct = if (total > 0) ((attended.toDouble() / total.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
            ChildAttendanceStats(
                totalDays = total,
                presentDays = present,
                absentDays = absent,
                lateDays = late,
                excusedDays = excused,
                percentage = pct
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChildAttendanceStats())

    // Selected child's Homework (Filtered by Selected Academic Year)
    val childHomework: StateFlow<List<Homework>> = combine(
        selectedChild,
        _selectedAcademicYear
    ) { child, year -> Pair(child?.classId, year) }.flatMapLatest { (classId, year) ->
        if (classId != null) repository.getHomeworkByClassAndYear(classId, year)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected child's Marks (Filtered by Selected Academic Year)
    val childMarks: StateFlow<List<StudentMark>> = combine(
        selectedChild,
        _selectedAcademicYear
    ) { child, year -> Pair(child?.id, year) }.flatMapLatest { (studentId, year) ->
        if (studentId != null) repository.getMarksByStudentAndYear(studentId, year)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected child's Fee Status (Filtered by Selected Academic Year)
    val childFee: StateFlow<StudentFee?> = combine(
        selectedChild,
        _selectedAcademicYear
    ) { child, year -> Pair(child?.id, year) }.flatMapLatest { (studentId, year) ->
        if (studentId != null) repository.getFeeForStudentAndYear(studentId, year)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Selected child's Fee Payment Receipts
    val childFeePayments: StateFlow<List<FeePayment>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getPaymentsByStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // School Announcements (Strict Parent & Class Security)
    val announcements: StateFlow<List<Announcement>> = combine(selectedChild, linkedChildren) { child, children ->
        val classIds = mutableSetOf<String>()
        child?.classId?.let { if (it.isNotBlank()) classIds.add(it) }
        children.forEach { if (it.classId.isNotBlank()) classIds.add(it.classId) }
        classIds
    }.flatMapLatest { classIds ->
        repository.getAnnouncementsForParentClasses(classIds)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Child Messages with School Staff
    val childMessages: StateFlow<List<ChatMessage>> = selectedChild.flatMapLatest { child ->
        if (child != null) repository.getMessagesForStudent(child.id)
        else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun sendMessageToSchool(messageText: String) {
        val child = selectedChild.value ?: return
        val profile = parentProfile.value ?: return
        val teacher = classTeacher.value
        val recipientId = teacher?.id ?: "PRIN001"
        val recipientName = teacher?.name ?: "School Administration"
        val recipientRole = if (teacher != null) UserRole.TEACHER.name else UserRole.PRINCIPAL.name

        viewModelScope.launch {
            val chatMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                schoolId = repository.currentSchoolId,
                studentId = child.id,
                studentName = child.name,
                senderId = parentId,
                senderName = profile.name,
                senderRole = UserRole.PARENT.name,
                receiverId = recipientId,
                receiverName = recipientName,
                receiverRole = recipientRole,
                message = messageText.trim(),
                timestamp = System.currentTimeMillis(),
                status = "DELIVERED"
            )
            repository.sendMessage(chatMsg)
        }
    }


    fun selectTab(tab: ParentTab) {
        _currentTab.value = tab
    }

    fun selectChild(childId: String) {
        _selectedChildId.value = childId
    }

    fun clearMessage() {
        _message.value = null
    }

    fun changePassword(currentPassword: String, newPassword: String, confirmPassword: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repository.changePassword(parentId, currentPassword, newPassword, confirmPassword)
            res.onSuccess {
                _message.value = "Password updated successfully!"
            }.onFailure { err ->
                _message.value = err.localizedMessage ?: "Failed to update password"
            }
            onResult(res)
        }
    }

    fun logout() {
        repository.logout()
    }
}

class ParentViewModelFactory(
    private val repository: SchoolRepository,
    private val parentId: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ParentViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ParentViewModel(repository, parentId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
