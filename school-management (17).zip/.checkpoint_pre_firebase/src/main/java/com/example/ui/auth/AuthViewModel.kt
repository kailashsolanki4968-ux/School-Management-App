package com.example.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountStatus
import com.example.data.model.School
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.data.session.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val selectedRole: UserRole = UserRole.PRINCIPAL,
    val loginSchoolId: String = "",
    val loginId: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    // Registration dialog state
    val showRegisterDialog: Boolean = false,
    val regSchoolId: String = "",
    val regSchoolName: String = "",
    val regId: String = "",
    val regName: String = "",
    val regEmail: String = "",
    val regPhone: String = "",
    val regRole: UserRole = UserRole.TEACHER,
    val regSubject: String = "",
    val regLinkedStudentIds: String = "",
    val regPassword: String = "",
    val regConfirmPassword: String = "",
    val regSecurityQuestion: String = "What was your first school?",
    val regSecurityAnswer: String = "",
    // Forgot Password dialog state
    val showForgotDialog: Boolean = false,
    val forgotUserId: String = "",
    val forgotSecurityAnswer: String = "",
    val forgotNewPassword: String = "",
    val forgotConfirmPassword: String = "",
    val forgotSecurityQuestionHint: String? = null
)

class AuthViewModel(private val repository: SchoolRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    val sessionState: StateFlow<UserSession?> = repository.sessionState

    fun onRoleSelected(role: UserRole) {
        _uiState.value = _uiState.value.copy(
            selectedRole = role,
            errorMessage = null,
            successMessage = null
        )
    }

    fun onSchoolIdChanged(schoolId: String) {
        _uiState.value = _uiState.value.copy(loginSchoolId = schoolId, errorMessage = null)
    }

    fun onLoginIdChanged(id: String) {
        _uiState.value = _uiState.value.copy(loginId = id, errorMessage = null)
    }

    fun onPasswordChanged(password: String) {
        _uiState.value = _uiState.value.copy(password = password, errorMessage = null)
    }

    fun login() {
        val state = _uiState.value
        val id = state.loginId.trim()
        val password = state.password.trim()
        val schoolId = state.loginSchoolId.trim()

        if (id.isEmpty()) {
            _uiState.value = state.copy(errorMessage = "Please enter your User ID")
            return
        }
        if (password.isEmpty()) {
            _uiState.value = state.copy(errorMessage = "Please enter your password")
            return
        }

        _uiState.value = state.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            try {
                val result = repository.login(id, password, state.selectedRole.name, schoolId.ifBlank { null })
                result.onSuccess {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = null,
                        successMessage = "Welcome, ${it.name}!"
                    )
                }.onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "Login failed. Please verify credentials."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Network or server connection failed: ${e.localizedMessage}"
                )
            }
        }
    }

    fun showRegister(show: Boolean) {
        val role = _uiState.value.selectedRole
        val generatedPrefix = when (role) {
            UserRole.PRINCIPAL -> "PRIN_"
            UserRole.TEACHER -> "TCH_"
            UserRole.PARENT -> "PAR_"
        }
        _uiState.value = _uiState.value.copy(
            showRegisterDialog = show,
            regRole = role,
            regSchoolId = _uiState.value.loginSchoolId,
            regSchoolName = "",
            regId = generatedPrefix + System.currentTimeMillis().toString().takeLast(4),
            regName = "",
            regEmail = "",
            regPhone = "",
            regSubject = "",
            regLinkedStudentIds = "",
            regPassword = "",
            regConfirmPassword = "",
            regSecurityAnswer = "",
            errorMessage = null,
            successMessage = null
        )
    }

    fun onRegFieldChanged(
        schoolId: String? = null,
        schoolName: String? = null,
        id: String? = null,
        name: String? = null,
        email: String? = null,
        phone: String? = null,
        role: UserRole? = null,
        subject: String? = null,
        linkedStudentIds: String? = null,
        password: String? = null,
        confirmPassword: String? = null,
        securityQuestion: String? = null,
        securityAnswer: String? = null
    ) {
        val current = _uiState.value
        _uiState.value = current.copy(
            regSchoolId = schoolId ?: current.regSchoolId,
            regSchoolName = schoolName ?: current.regSchoolName,
            regId = id ?: current.regId,
            regName = name ?: current.regName,
            regEmail = email ?: current.regEmail,
            regPhone = phone ?: current.regPhone,
            regRole = role ?: current.regRole,
            regSubject = subject ?: current.regSubject,
            regLinkedStudentIds = linkedStudentIds ?: current.regLinkedStudentIds,
            regPassword = password ?: current.regPassword,
            regConfirmPassword = confirmPassword ?: current.regConfirmPassword,
            regSecurityQuestion = securityQuestion ?: current.regSecurityQuestion,
            regSecurityAnswer = securityAnswer ?: current.regSecurityAnswer,
            errorMessage = null
        )
    }

    fun register() {
        val state = _uiState.value
        if (state.regId.isBlank() || state.regName.isBlank() || state.regPassword.isBlank() || state.regSecurityAnswer.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Please fill all required fields.")
            return
        }
        if (state.regSchoolId.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Please enter a valid School ID.")
            return
        }
        if (state.regPassword != state.regConfirmPassword) {
            _uiState.value = state.copy(errorMessage = "Passwords do not match.")
            return
        }
        if (state.regPassword.length < 6) {
            _uiState.value = state.copy(errorMessage = "Password must be at least 6 characters.")
            return
        }

        if (state.regRole == UserRole.PARENT && state.regLinkedStudentIds.isBlank()) {
            _uiState.value = state.copy(errorMessage = "Please enter the permanent Student ID provided by your school (e.g. STU_1001).")
            return
        }

        // Status: Principal is approved; Teacher and Parent are PENDING approval
        val accountStatus = when (state.regRole) {
            UserRole.PRINCIPAL -> AccountStatus.APPROVED.name
            UserRole.PARENT -> AccountStatus.PENDING.name
            UserRole.TEACHER -> AccountStatus.PENDING.name
        }

        val newUser = UserAccount(
            id = state.regId.trim(),
            schoolId = state.regSchoolId.trim(),
            name = state.regName.trim(),
            email = state.regEmail.trim(),
            phone = state.regPhone.trim(),
            role = state.regRole.name,
            passwordHash = "", // will be hashed in repository
            securityQuestion = state.regSecurityQuestion.trim(),
            securityAnswer = "", // will be hashed in repository
            status = accountStatus,
            assignedClassId = null,
            linkedStudentIds = if (state.regRole == UserRole.PARENT) state.regLinkedStudentIds.trim() else "",
            subject = if (state.regRole == UserRole.TEACHER) state.regSubject.trim().ifBlank { "General" } else if (state.regRole == UserRole.PRINCIPAL) "Administration" else null
        )

        _uiState.value = state.copy(isLoading = true)
        viewModelScope.launch {
            try {
                // If Parent registration, validate that the Student ID exists in the school and is eligible for linking
                if (newUser.role == UserRole.PARENT.name) {
                    val studentId = newUser.linkedStudentIds
                    val student = repository.getStudentByIdAndSchool(studentId, newUser.schoolId)
                    if (student == null) {
                        _uiState.value = state.copy(
                            isLoading = false,
                            errorMessage = "Student ID '$studentId' was not found in School '${newUser.schoolId}'. Please enter the valid Student ID provided by your school."
                        )
                        return@launch
                    }
                    if (!student.parentUserId.isNullOrBlank()) {
                        val existingParent = repository.getUserById(student.parentUserId)
                        if (existingParent != null && existingParent.status == AccountStatus.APPROVED.name) {
                            _uiState.value = state.copy(
                                isLoading = false,
                                errorMessage = "Student '${student.name}' ($studentId) is already linked to an approved parent account. Please contact the school Principal."
                            )
                            return@launch
                        }
                    }
                    val pendingParent = repository.getPendingParentForStudent(studentId, newUser.schoolId)
                    if (pendingParent != null && pendingParent.id != newUser.id) {
                        _uiState.value = state.copy(
                            isLoading = false,
                            errorMessage = "A parent registration request is already pending approval for Student '${student.name}' ($studentId)."
                        )
                        return@launch
                    }
                }

                // If it's a principal registering a new school, register school first
                if (newUser.role == UserRole.PRINCIPAL.name) {
                    val school = School(
                        id = newUser.schoolId,
                        name = state.regSchoolName.trim().ifBlank { "${newUser.name}'s Academy" },
                        code = newUser.schoolId.takeLast(4).uppercase(),
                        principalId = newUser.id
                    )
                    repository.registerSchool(school)
                }

                val res = repository.registerUser(newUser, state.regPassword.trim(), state.regSecurityAnswer.trim())
                res.onSuccess {
                    val msg = when (newUser.role) {
                        UserRole.PRINCIPAL.name -> "Principal account '${newUser.id}' registered with School '${newUser.schoolId}'. You can now log in."
                        UserRole.PARENT.name -> "Parent registration submitted for student '${newUser.linkedStudentIds}'. Requires Principal approval before accessing student records."
                        else -> "Teacher account '${newUser.id}' registered! Requires Principal approval before logging in."
                    }
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        showRegisterDialog = false,
                        loginSchoolId = newUser.schoolId,
                        loginId = newUser.id,
                        password = if (newUser.role == UserRole.PRINCIPAL.name) state.regPassword.trim() else "",
                        selectedRole = state.regRole,
                        successMessage = msg,
                        errorMessage = null
                    )
                }.onFailure { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "Failed to create account"
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Account registration failed: ${e.localizedMessage}"
                )
            }
        }
    }

    fun showForgotPassword(show: Boolean) {
        _uiState.value = _uiState.value.copy(
            showForgotDialog = show,
            forgotUserId = _uiState.value.loginId,
            forgotSecurityAnswer = "",
            forgotNewPassword = "",
            forgotConfirmPassword = "",
            forgotSecurityQuestionHint = null,
            errorMessage = null,
            successMessage = null
        )
    }

    fun onForgotFieldChanged(
        userId: String? = null,
        answer: String? = null,
        newPass: String? = null,
        confirmPass: String? = null
    ) {
        val cur = _uiState.value
        _uiState.value = cur.copy(
            forgotUserId = userId ?: cur.forgotUserId,
            forgotSecurityAnswer = answer ?: cur.forgotSecurityAnswer,
            forgotNewPassword = newPass ?: cur.forgotNewPassword,
            forgotConfirmPassword = confirmPass ?: cur.forgotConfirmPassword,
            errorMessage = null
        )
    }

    fun fetchSecurityQuestion() {
        val id = _uiState.value.forgotUserId.trim()
        if (id.isEmpty()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Please enter your User ID first.")
            return
        }
        viewModelScope.launch {
            val user = repository.getUserById(id)
            if (user != null) {
                _uiState.value = _uiState.value.copy(
                    forgotSecurityQuestionHint = user.securityQuestion,
                    errorMessage = null
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    forgotSecurityQuestionHint = null,
                    errorMessage = "User ID '$id' not found in database or cloud."
                )
            }
        }
    }

    fun recoverPassword() {
        val state = _uiState.value
        val id = state.forgotUserId.trim()
        val answer = state.forgotSecurityAnswer.trim()
        val newPass = state.forgotNewPassword.trim()
        val confirmPass = state.forgotConfirmPassword.trim()

        if (id.isEmpty() || answer.isEmpty() || newPass.isEmpty()) {
            _uiState.value = state.copy(errorMessage = "Please complete all password recovery fields.")
            return
        }
        if (newPass != confirmPass) {
            _uiState.value = state.copy(errorMessage = "New passwords do not match.")
            return
        }
        if (newPass.length < 6) {
            _uiState.value = state.copy(errorMessage = "New password must be at least 6 characters.")
            return
        }

        _uiState.value = state.copy(isLoading = true)
        viewModelScope.launch {
            val result = repository.resetPasswordWithSecurity(id, answer, newPass)
            result.onSuccess {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    showForgotDialog = false,
                    password = newPass,
                    loginId = id,
                    successMessage = "Password reset successfully! Please log in with your new password.",
                    errorMessage = null
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = err.localizedMessage ?: "Password recovery failed."
                )
            }
        }
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, successMessage = null)
    }

    fun logout() {
        repository.logout()
    }
}

class AuthViewModelFactory(private val repository: SchoolRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
