package com.example.ui.principal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AcademicYear
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentEnrollment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AcademicYearPromotionDialog(
    viewModel: PrincipalViewModel,
    initialTab: Int = 0,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(initialTab) }
    val academicYears by viewModel.academicYears.collectAsStateWithLifecycle()
    val currentYear by viewModel.currentAcademicYear.collectAsStateWithLifecycle()
    val selectedViewYear by viewModel.selectedAcademicYear.collectAsStateWithLifecycle()

    var showCreateYearDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.DateRange,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Academic Years & Student Promotion",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Active Year: ${currentYear?.yearCode ?: "2026-27"} • Viewing: $selectedViewYear",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Tab Selector
                SecondaryTabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Academic Years (${academicYears.size})")
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Upgrade, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Student Promotion")
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Timeline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Progression History")
                            }
                        }
                    )
                }

                // Status / Error Notification Banner
                val bannerMessage by viewModel.message.collectAsStateWithLifecycle()
                if (bannerMessage != null) {
                    val isError = bannerMessage!!.contains("error", ignoreCase = true) ||
                            bannerMessage!!.contains("failed", ignoreCase = true) ||
                            bannerMessage!!.contains("prevented", ignoreCase = true) ||
                            bannerMessage!!.contains("already enrolled", ignoreCase = true)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isError) MaterialTheme.colorScheme.errorContainer
                            else MaterialTheme.colorScheme.primaryContainer
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (isError) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = bannerMessage!!,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                            IconButton(
                                onClick = { viewModel.clearMessage() },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Tab Contents
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        0 -> AcademicYearsTabContent(
                            viewModel = viewModel,
                            onOpenCreateYear = { showCreateYearDialog = true }
                        )
                        1 -> StudentPromotionTabContent(viewModel = viewModel)
                        2 -> StudentHistoryTabContent(viewModel = viewModel)
                    }
                }
            }
        }
    }

    if (showCreateYearDialog) {
        CreateAcademicYearDialog(
            onDismiss = { showCreateYearDialog = false },
            onCreate = { code, name, start, end ->
                viewModel.createAcademicYear(code, name, start, end)
                showCreateYearDialog = false
            }
        )
    }
}

// ---------------- TAB 0: ACADEMIC YEARS ----------------

@Composable
fun AcademicYearsTabContent(
    viewModel: PrincipalViewModel,
    onOpenCreateYear: () -> Unit
) {
    val academicYears by viewModel.academicYears.collectAsStateWithLifecycle()
    val currentYear by viewModel.currentAcademicYear.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedAcademicYear.collectAsStateWithLifecycle()
    val enrollments by viewModel.enrollmentsForSelectedYear.collectAsStateWithLifecycle()

    var yearToSetCurrent by remember { mutableStateOf<AcademicYear?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Manage School Academic Years",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Records are fully isolated per academic year. Past years remain safe and historical.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            Button(
                onClick = onOpenCreateYear,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("btn_add_academic_year")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Academic Year")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Banner if viewing historical year
        if (currentYear != null && selectedYear != currentYear?.yearCode) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Historical View Active: $selectedYear",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Current operational academic year is ${currentYear?.yearCode}. Past records are read-only.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    OutlinedButton(
                        onClick = { viewModel.selectAcademicYear(currentYear!!.yearCode) },
                        modifier = Modifier.testTag("btn_switch_to_current_year")
                    ) {
                        Text("Switch to Current")
                    }
                }
            }
        }

        // List of Academic Years
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(academicYears) { year ->
                val isCurrent = year.isCurrent
                val isViewing = year.yearCode == selectedYear

                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isCurrent) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.outlineVariant
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.DateRange,
                                        contentDescription = null,
                                        tint = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = year.displayName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        if (isCurrent) {
                                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                                Text("ACTIVE / CURRENT")
                                            }
                                        } else if (year.status == "UPCOMING") {
                                            Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                                                Text("UPCOMING")
                                            }
                                        } else {
                                            Badge(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                                                Text("COMPLETED")
                                            }
                                        }
                                    }
                                    Text(
                                        text = "Code: ${year.yearCode} • Duration: ${year.startDate} to ${year.endDate}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isViewing) {
                                    Text(
                                        text = "Currently Viewing",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                } else {
                                    OutlinedButton(
                                        onClick = { viewModel.selectAcademicYear(year.yearCode) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("View Records")
                                    }
                                }

                                if (!isCurrent) {
                                    Button(
                                        onClick = { yearToSetCurrent = year },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text("Set Active")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (yearToSetCurrent != null) {
        AlertDialog(
            onDismissRequest = { yearToSetCurrent = null },
            icon = { Icon(Icons.Default.School, contentDescription = null) },
            title = { Text("Set Active Academic Year") },
            text = {
                Text(
                    "Set ${yearToSetCurrent!!.displayName} (${yearToSetCurrent!!.yearCode}) as the active operational academic year?\n\n" +
                            "• Previous years' data (attendance, fees, marks, homework) will remain safe and accessible.\n" +
                            "• Daily operations (attendance, new fees, mark entries) will now default to ${yearToSetCurrent!!.yearCode}."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCurrentAcademicYear(yearToSetCurrent!!.yearCode)
                        yearToSetCurrent = null
                    }
                ) {
                    Text("Confirm & Set Active")
                }
            },
            dismissButton = {
                TextButton(onClick = { yearToSetCurrent = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// Helper to intelligently suggest next grade/class (e.g. Grade 10 A -> Grade 11 A)
fun suggestTargetClass(sourceClassId: String?, classes: List<SchoolClass>): String? {
    if (sourceClassId == null || classes.isEmpty()) return classes.firstOrNull()?.id
    val src = classes.find { it.id == sourceClassId } ?: return classes.firstOrNull()?.id

    val gradeNumber = Regex("""\d+""").find(src.grade)?.value?.toIntOrNull()
    if (gradeNumber != null) {
        val nextGradeNumber = gradeNumber + 1
        // Look for next grade with same section first
        val matchingNextGradeSameSection = classes.find {
            val num = Regex("""\d+""").find(it.grade)?.value?.toIntOrNull()
            num == nextGradeNumber && it.section.equals(src.section, ignoreCase = true)
        }
        if (matchingNextGradeSameSection != null) return matchingNextGradeSameSection.id

        // Look for next grade with any section
        val matchingNextGrade = classes.find {
            val num = Regex("""\d+""").find(it.grade)?.value?.toIntOrNull()
            num == nextGradeNumber
        }
        if (matchingNextGrade != null) return matchingNextGrade.id
    }

    val currentIndex = classes.indexOfFirst { it.id == sourceClassId }
    if (currentIndex >= 0 && currentIndex + 1 < classes.size) {
        return classes[currentIndex + 1].id
    }
    return classes.firstOrNull()?.id
}

// ---------------- TAB 1: STUDENT PROMOTION ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentPromotionTabContent(viewModel: PrincipalViewModel) {
    val academicYears by viewModel.academicYears.collectAsStateWithLifecycle()
    val allClasses by viewModel.allClasses.collectAsStateWithLifecycle()
    val currentYear by viewModel.currentAcademicYear.collectAsStateWithLifecycle()

    var sourceYear by remember { mutableStateOf(currentYear?.yearCode ?: "2026-27") }
    var targetYear by remember {
        val next = academicYears.find { it.yearCode != (currentYear?.yearCode ?: "2026-27") }?.yearCode ?: "2027-28"
        mutableStateOf(next)
    }

    var selectedSourceClassId by remember { mutableStateOf<String?>(allClasses.firstOrNull()?.id) }
    var selectedTargetClassId by remember { mutableStateOf<String?>(suggestTargetClass(allClasses.firstOrNull()?.id, allClasses)) }

    // Initialize when allClasses loads
    LaunchedEffect(allClasses) {
        if (selectedSourceClassId == null && allClasses.isNotEmpty()) {
            val firstId = allClasses.first().id
            selectedSourceClassId = firstId
            selectedTargetClassId = suggestTargetClass(firstId, allClasses)
        }
    }

    // Auto-adjust targetYear if sourceYear equals targetYear
    LaunchedEffect(sourceYear) {
        if (targetYear == sourceYear) {
            val other = academicYears.find { it.yearCode != sourceYear }?.yearCode
            if (other != null) {
                targetYear = other
            }
        }
    }

    // Clear student selection whenever source or target direction changes
    val selectedStudentIds = remember { mutableStateMapOf<String, Boolean>() }
    LaunchedEffect(sourceYear, selectedSourceClassId, targetYear) {
        selectedStudentIds.clear()
    }

    // Query actual students enrolled in source class and source year
    val enrolledInSourceClass by remember(selectedSourceClassId, sourceYear) {
        if (selectedSourceClassId.isNullOrBlank()) {
            kotlinx.coroutines.flow.flowOf(emptyList())
        } else {
            viewModel.repository.getStudentsByClassAndYear(selectedSourceClassId!!, sourceYear)
        }
    }.collectAsState(emptyList())

    // Target enrollments to identify already promoted students
    val targetEnrollments by viewModel.repository.getEnrollmentsByYear(targetYear).collectAsState(emptyList())
    val eligibleStudents = enrolledInSourceClass.filter { s -> targetEnrollments.none { it.studentId == s.id } }

    val isDirectionValid = sourceYear.isNotBlank() && targetYear.isNotBlank() &&
            sourceYear != targetYear && !selectedTargetClassId.isNullOrBlank()

    val selectedCount = eligibleStudents.count { selectedStudentIds[it.id] == true }
    val isAllSelected = eligibleStudents.isNotEmpty() && eligibleStudents.all { selectedStudentIds[it.id] == true }

    var showBatchConfirmDialog by remember { mutableStateOf(false) }
    var studentForSinglePromotion by remember { mutableStateOf<Student?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Controls Card: Source & Target Year / Class
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Select Promotion Direction",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Source Academic Year Dropdown
                    var sourceYearExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = sourceYearExpanded,
                        onExpandedChange = { sourceYearExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = "From: $sourceYear",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Source Year") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceYearExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = sourceYearExpanded,
                            onDismissRequest = { sourceYearExpanded = false }
                        ) {
                            academicYears.forEach { yr ->
                                DropdownMenuItem(
                                    text = { Text("${yr.yearCode} (${yr.displayName})") },
                                    onClick = {
                                        sourceYear = yr.yearCode
                                        sourceYearExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )

                    // Target Academic Year Dropdown
                    var targetYearExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = targetYearExpanded,
                        onExpandedChange = { targetYearExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = "To: $targetYear",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target Year") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = targetYearExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = targetYearExpanded,
                            onDismissRequest = { targetYearExpanded = false }
                        ) {
                            academicYears.forEach { yr ->
                                DropdownMenuItem(
                                    text = {
                                        Text(yr.yearCode + if (yr.yearCode == sourceYear) " (Source - Invalid)" else " (${yr.displayName})")
                                    },
                                    onClick = {
                                        targetYear = yr.yearCode
                                        targetYearExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Source Class Dropdown
                    var sourceClassExpanded by remember { mutableStateOf(false) }
                    val sourceClass = allClasses.find { it.id == selectedSourceClassId }
                    ExposedDropdownMenuBox(
                        expanded = sourceClassExpanded,
                        onExpandedChange = { sourceClassExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = sourceClass?.name ?: "Select Class",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Source Class") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = sourceClassExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = sourceClassExpanded,
                            onDismissRequest = { sourceClassExpanded = false }
                        ) {
                            allClasses.forEach { cls ->
                                DropdownMenuItem(
                                    text = { Text(cls.name) },
                                    onClick = {
                                        selectedSourceClassId = cls.id
                                        selectedTargetClassId = suggestTargetClass(cls.id, allClasses)
                                        sourceClassExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )

                    // Target Class Dropdown
                    var targetClassExpanded by remember { mutableStateOf(false) }
                    val targetClass = allClasses.find { it.id == selectedTargetClassId }
                    ExposedDropdownMenuBox(
                        expanded = targetClassExpanded,
                        onExpandedChange = { targetClassExpanded = it },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = targetClass?.name ?: "Select Target Class",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target Class (Promote To)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = targetClassExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = targetClassExpanded,
                            onDismissRequest = { targetClassExpanded = false }
                        ) {
                            allClasses.forEach { cls ->
                                DropdownMenuItem(
                                    text = { Text(cls.name) },
                                    onClick = {
                                        selectedTargetClassId = cls.id
                                        targetClassExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Invalid Direction Warning Banner
                if (sourceYear == targetYear) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Target Academic Year cannot be the same as Source Year ($sourceYear). Student Promotion is for advancing students into a new academic year.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Medium)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Student Selection & Action Header
        val currentSourceClassName = allClasses.find { it.id == selectedSourceClassId }?.name ?: "Selected Class"
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Checkbox(
                    checked = isAllSelected,
                    onCheckedChange = { checkAll ->
                        eligibleStudents.forEach { s ->
                            selectedStudentIds[s.id] = checkAll
                        }
                    },
                    enabled = eligibleStudents.isNotEmpty()
                )
                Text(
                    text = "Select All (${eligibleStudents.size} eligible of ${enrolledInSourceClass.size} in $currentSourceClassName)",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            Button(
                onClick = { showBatchConfirmDialog = true },
                enabled = selectedCount > 0 && isDirectionValid,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("btn_promote_selected")
            ) {
                Icon(Icons.Default.Upgrade, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Promote Selected ($selectedCount)")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Student List
        if (enrolledInSourceClass.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.School,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No students enrolled in $currentSourceClassName for Academic Year $sourceYear",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(enrolledInSourceClass) { student ->
                    val isAlreadyPromoted = targetEnrollments.any { it.studentId == student.id }
                    val existingTargetEnrollment = targetEnrollments.find { it.studentId == student.id }
                    val isChecked = selectedStudentIds[student.id] ?: false

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isAlreadyPromoted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { selectedStudentIds[student.id] = it },
                                    enabled = !isAlreadyPromoted
                                )

                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = student.name.take(1).uppercase(),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = student.name,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "(Roll: ${student.rollNumber})",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        )
                                    }
                                    Text(
                                        text = "Permanent ID: ${student.id} • ${student.gender ?: "Student"}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }

                            if (isAlreadyPromoted) {
                                val targetClassName = allClasses.find { it.id == existingTargetEnrollment?.classId }?.name ?: "Enrolled"
                                Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                                    Text("Enrolled in $targetYear ($targetClassName)")
                                }
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { studentForSinglePromotion = student },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Promote / Retain", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Single Student Promotion Dialog
    if (studentForSinglePromotion != null) {
        val s = studentForSinglePromotion!!
        SingleStudentPromotionDialog(
            student = s,
            sourceYear = sourceYear,
            academicYears = academicYears,
            classes = allClasses,
            defaultTargetClassId = selectedTargetClassId ?: suggestTargetClass(s.classId, allClasses) ?: allClasses.firstOrNull()?.id ?: "",
            onDismiss = { studentForSinglePromotion = null },
            onPromote = { tYear, targetClsId, newRoll ->
                viewModel.promoteStudent(s.id, sourceYear, tYear, targetClsId, newRoll)
                studentForSinglePromotion = null
            },
            onRetain = { tYear, targetClsId, newRoll ->
                viewModel.retainStudent(s.id, sourceYear, tYear, targetClsId, newRoll)
                studentForSinglePromotion = null
            },
            onChangeClass = { targetClsId, newRoll, reason ->
                viewModel.changeStudentClass(s.id, targetClsId, newRoll, reason)
                studentForSinglePromotion = null
            },
            onStatusChange = { status, remarks ->
                viewModel.updateStudentStatus(s.id, sourceYear, status, remarks)
                studentForSinglePromotion = null
            }
        )
    }

    // Batch Promotion Confirmation Dialog
    if (showBatchConfirmDialog) {
        val selectedStudents = eligibleStudents.filter { selectedStudentIds[it.id] == true }
        val count = selectedStudents.size
        val targetClassName = allClasses.find { it.id == selectedTargetClassId }?.name ?: "Selected Class"
        AlertDialog(
            onDismissRequest = { showBatchConfirmDialog = false },
            icon = { Icon(Icons.Default.Upgrade, contentDescription = null) },
            title = { Text("Confirm Student Promotion") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Promote $count students from $sourceYear to $targetYear into $targetClassName?",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Selected students: " + selectedStudents.take(5).joinToString { it.name } +
                                if (count > 5) " and ${count - 5} more" else "",
                        style = MaterialTheme.typography.bodySmall
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "• Student permanent IDs and personal identities are completely preserved.\n" +
                                "• Previous year ($sourceYear) attendance, marks, homework, and fees remain 100% intact.\n" +
                                "• New student enrollments and fee profiles will be initialized for $targetYear in $targetClassName.\n" +
                                "• Duplicate enrollments in $targetYear are strictly prevented.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ids = selectedStudents.map { it.id }
                        viewModel.promoteBatchStudents(ids, sourceYear, targetYear, selectedTargetClassId ?: "")
                        showBatchConfirmDialog = false
                        selectedStudentIds.clear()
                    }
                ) {
                    Text("Confirm Promotion")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBatchConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ---------------- TAB 2: PROGRESSION HISTORY ----------------

@Composable
fun StudentHistoryTabContent(viewModel: PrincipalViewModel) {
    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val allClasses by viewModel.allClasses.collectAsStateWithLifecycle()
    val academicYears by viewModel.academicYears.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedStudent by remember { mutableStateOf<Student?>(allStudents.firstOrNull()) }

    val filteredStudents = remember(allStudents, searchQuery) {
        if (searchQuery.isBlank()) allStudents
        else allStudents.filter {
            it.name.contains(searchQuery.trim(), ignoreCase = true) ||
                    it.id.contains(searchQuery.trim(), ignoreCase = true) ||
                    it.rollNumber.contains(searchQuery.trim(), ignoreCase = true)
        }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Student Selector List
        Card(
            modifier = Modifier
                .weight(0.42f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by name or ID...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredStudents) { student ->
                        val isSelected = student.id == selectedStudent?.id
                        val currentClass = allClasses.find { it.id == student.classId }?.name ?: "Class"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                    else Color.Transparent
                                )
                                .clickable { selectedStudent = student }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = student.name.take(1).uppercase(),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = student.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "ID: ${student.id} • $currentClass",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Student Timeline across Academic Years
        Card(
            modifier = Modifier
                .weight(0.58f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (selectedStudent == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Select a student to view their multi-year academic progression")
                }
            } else {
                val student = selectedStudent!!
                val enrollments by viewModel.getStudentEnrollments(student.id).collectAsState(emptyList())

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Student Permanent Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = student.name.take(1).uppercase(),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Column {
                            Text(
                                text = student.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Permanent Student ID: ${student.id}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Text(
                                text = "Parent: ${student.parentName.ifBlank { "Not linked" }} • Phone: ${student.emergencyContact.ifBlank { "N/A" }}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Academic Progression & Yearly Enrollments",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (enrollments.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No enrollment history recorded yet. Default enrolled in 2026-27.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(enrollments.sortedByDescending { it.academicYear }) { enrollment ->
                                val yrInfo = academicYears.find { it.yearCode == enrollment.academicYear }
                                val clsName = allClasses.find { it.id == enrollment.classId }?.name ?: enrollment.classId

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (enrollment.status == "ACTIVE") MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "Academic Year ${enrollment.academicYear}",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Badge(
                                                    containerColor = when (enrollment.status) {
                                                        "ACTIVE" -> MaterialTheme.colorScheme.primary
                                                        "PROMOTED" -> MaterialTheme.colorScheme.secondary
                                                        "RETAINED" -> MaterialTheme.colorScheme.error
                                                        else -> MaterialTheme.colorScheme.surfaceVariant
                                                    }
                                                ) {
                                                    Text(enrollment.status)
                                                }
                                            }

                                            Text(
                                                text = "Class: $clsName • Roll Number: ${enrollment.rollNumber}",
                                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            )

                                            if (yrInfo != null) {
                                                Text(
                                                    text = "Dates: ${yrInfo.startDate} to ${yrInfo.endDate}",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        fontSize = 11.sp
                                                    )
                                                )
                                            }
                                        }

                                        Icon(
                                            imageVector = when (enrollment.status) {
                                                "PROMOTED" -> Icons.Default.Upgrade
                                                "ACTIVE" -> Icons.Default.CheckCircle
                                                else -> Icons.Default.History
                                            },
                                            contentDescription = null,
                                            tint = when (enrollment.status) {
                                                "PROMOTED" -> MaterialTheme.colorScheme.secondary
                                                "ACTIVE" -> MaterialTheme.colorScheme.primary
                                                else -> MaterialTheme.colorScheme.outline
                                            },
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- CREATE ACADEMIC YEAR DIALOG ----------------

@Composable
fun CreateAcademicYearDialog(
    onDismiss: () -> Unit,
    onCreate: (yearCode: String, name: String, startDate: String, endDate: String) -> Unit
) {
    var yearCode by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf("") }
    var endDate by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
        title = { Text("Create New Academic Year") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = yearCode,
                    onValueChange = {
                        yearCode = it
                        if (name.isBlank() || name.startsWith("Academic Year")) {
                            name = "Academic Year $it"
                        }
                    },
                    label = { Text("Year Code (e.g. 2027-28)") },
                    placeholder = { Text("2027-28") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Academic Year Name") },
                    placeholder = { Text("Academic Year 2027-28") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = startDate,
                    onValueChange = { startDate = it },
                    label = { Text("Start Date (YYYY-MM-DD)") },
                    placeholder = { Text("2027-04-01") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = endDate,
                    onValueChange = { endDate = it },
                    label = { Text("End Date (YYYY-MM-DD)") },
                    placeholder = { Text("2028-03-31") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val code = yearCode.trim()
                    val sDate = startDate.trim().ifBlank { "2027-04-01" }
                    val eDate = endDate.trim().ifBlank { "2028-03-31" }
                    val yName = name.trim().ifBlank { "Academic Year $code" }
                    if (code.isNotBlank()) {
                        onCreate(code, yName, sDate, eDate)
                    }
                },
                enabled = yearCode.isNotBlank()
            ) {
                Text("Create Year")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ---------------- SINGLE STUDENT PROMOTION DIALOG ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SingleStudentPromotionDialog(
    student: Student,
    sourceYear: String,
    academicYears: List<AcademicYear>,
    classes: List<SchoolClass>,
    defaultTargetClassId: String,
    initialActionType: String = "PROMOTE",
    existingStudents: List<Student> = emptyList(),
    onDismiss: () -> Unit,
    onPromote: (targetYear: String, targetClassId: String, newRollNumber: String) -> Unit,
    onRetain: (targetYear: String, targetClassId: String, newRollNumber: String) -> Unit,
    onChangeClass: (targetClassId: String, newRollNumber: String, reason: String) -> Unit = { _, _, _ -> },
    onStatusChange: (status: String, remarks: String) -> Unit = { _, _ -> }
) {
    val nonSourceYears = academicYears.filter { it.yearCode != sourceYear }
    var selectedTargetYear by remember {
        mutableStateOf(nonSourceYears.firstOrNull()?.yearCode ?: "2027-28")
    }
    var selectedTargetClassId by remember { mutableStateOf(defaultTargetClassId) }
    var newRollNumber by remember { mutableStateOf(student.rollNumber) }
    var actionType by remember { mutableStateOf(initialActionType) } // PROMOTE, RETAIN, CHANGE_CLASS, STATUS
    var transferReason by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf("LEFT") } // LEFT, GRADUATED, TRANSFERRED

    val currentClassObj = classes.find { it.id == student.classId }
    val targetClassObj = classes.find { it.id == selectedTargetClassId }

    val studentsInTargetClass = remember(selectedTargetClassId, existingStudents) {
        existingStudents.filter { it.classId == selectedTargetClassId }
    }
    val conflictingStudent = remember(selectedTargetClassId, newRollNumber, existingStudents) {
        studentsInTargetClass.firstOrNull {
            it.rollNumber.trim().equals(newRollNumber.trim(), ignoreCase = true) && it.id != student.id
        }
    }
    val isRollCollision = conflictingStudent != null
    val isSameClassAndRoll = selectedTargetClassId == student.classId && newRollNumber.trim().equals(student.rollNumber.trim(), ignoreCase = true)

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { 
            Icon(
                when (actionType) {
                    "CHANGE_CLASS" -> Icons.Default.School
                    "STATUS" -> Icons.Default.Close
                    else -> Icons.Default.Upgrade
                },
                contentDescription = null
            ) 
        },
        title = { 
            Text(
                when (actionType) {
                    "CHANGE_CLASS" -> "Change Student Class / Section"
                    "STATUS" -> "Student Departure / Graduation"
                    "RETAIN" -> "Repeat / Retain Student"
                    else -> "Promote Student to Next Academic Year"
                }
            ) 
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Student: ${student.name} (ID: ${student.id})",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Current Class: ${student.classId} • Roll: ${student.rollNumber} • Academic Year: $sourceYear",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Action Mode Chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = actionType == "PROMOTE",
                        onClick = { actionType = "PROMOTE" },
                        label = { Text("Promote", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = actionType == "RETAIN",
                        onClick = { actionType = "RETAIN" },
                        label = { Text("Repeat", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = actionType == "CHANGE_CLASS",
                        onClick = { actionType = "CHANGE_CLASS" },
                        label = { Text("Class Change", fontSize = 12.sp) },
                        modifier = Modifier.weight(1.1f)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = actionType == "STATUS",
                        onClick = { actionType = "STATUS" },
                        label = { Text("Leave / Graduate School", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                when (actionType) {
                    "PROMOTE", "RETAIN" -> {
                        // Target Year Selection
                        var yearExpanded by remember { mutableStateOf(false) }
                        val yearOptions = academicYears.map { it.yearCode }
                        ExposedDropdownMenuBox(
                            expanded = yearExpanded,
                            onExpandedChange = { yearExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedTargetYear,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Target Academic Year *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = yearExpanded) },
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = yearExpanded,
                                onDismissRequest = { yearExpanded = false }
                            ) {
                                yearOptions.forEach { yr ->
                                    DropdownMenuItem(
                                        text = { Text(yr + if (yr == sourceYear) " (Source - Invalid)" else "") },
                                        onClick = {
                                            selectedTargetYear = yr
                                            yearExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (selectedTargetYear == sourceYear) {
                            Text(
                                text = "Target Academic Year cannot be the same as Source Year ($sourceYear).",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        // Target Class Selection
                        var classExpanded by remember { mutableStateOf(false) }
                        val targetClass = classes.find { it.id == selectedTargetClassId }
                        ExposedDropdownMenuBox(
                            expanded = classExpanded,
                            onExpandedChange = { classExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = targetClass?.name ?: "Select Class",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text(if (actionType == "PROMOTE") "Target Next Class *" else "Target Class to Repeat *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = classExpanded) },
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = classExpanded,
                                onDismissRequest = { classExpanded = false }
                            ) {
                                classes.forEach { cls ->
                                    DropdownMenuItem(
                                        text = { Text(cls.name) },
                                        onClick = {
                                            selectedTargetClassId = cls.id
                                            classExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = newRollNumber,
                            onValueChange = { newRollNumber = it },
                            label = { Text("Roll Number for $selectedTargetYear *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    "CHANGE_CLASS" -> {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Class & Section Change (Academic Year: $sourceYear)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                )
                                Text(
                                    text = "Moves student within $sourceYear. Preserves student ID, fees, marks, and attendance history. Does not create a new academic year or promote student.",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        // Target Grade and Section Quick Selector
                        val currentGrade = currentClassObj?.grade ?: ""
                        val siblingSections = classes.filter { it.grade.equals(currentGrade, ignoreCase = true) }
                        if (siblingSections.size > 1) {
                            Text(
                                text = "Switch Section in $currentGrade:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                siblingSections.forEach { cls ->
                                    FilterChip(
                                        selected = selectedTargetClassId == cls.id,
                                        onClick = { 
                                            selectedTargetClassId = cls.id
                                            val maxRoll = existingStudents.filter { it.classId == cls.id }
                                                .mapNotNull { it.rollNumber.toIntOrNull() }.maxOrNull() ?: 0
                                            if (cls.id != student.classId && maxRoll > 0) {
                                                newRollNumber = (maxRoll + 1).toString()
                                            }
                                        },
                                        label = { Text("Section ${cls.section}", fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // Target Class & Section Dropdown
                        var classExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = classExpanded,
                            onExpandedChange = { classExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = targetClassObj?.name ?: "Select Target Class & Section",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Target Class & Section *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = classExpanded) },
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = classExpanded,
                                onDismissRequest = { classExpanded = false }
                            ) {
                                classes.forEach { cls ->
                                    DropdownMenuItem(
                                        text = { 
                                            Column {
                                                Text(cls.name, fontWeight = if (cls.id == selectedTargetClassId) FontWeight.Bold else FontWeight.Normal)
                                                Text("Grade ${cls.grade} • Section ${cls.section} • ${cls.roomNumber}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        onClick = {
                                            selectedTargetClassId = cls.id
                                            val maxRoll = existingStudents.filter { it.classId == cls.id }
                                                .mapNotNull { it.rollNumber.toIntOrNull() }.maxOrNull() ?: 0
                                            if (cls.id != student.classId && maxRoll > 0) {
                                                newRollNumber = (maxRoll + 1).toString()
                                            }
                                            classExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Column {
                            OutlinedTextField(
                                value = newRollNumber,
                                onValueChange = { newRollNumber = it },
                                label = { Text("New Roll Number in Target Class *") },
                                isError = isRollCollision || isSameClassAndRoll,
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            
                            val maxRoll = studentsInTargetClass.mapNotNull { it.rollNumber.toIntOrNull() }.maxOrNull() ?: 0
                            val suggestedRoll = if (maxRoll > 0) (maxRoll + 1).toString() else "1"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { newRollNumber = suggestedRoll },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("Suggest Next Roll ($suggestedRoll)", fontSize = 11.sp)
                                }
                            }
                        }

                        if (isRollCollision) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Roll number '${newRollNumber.trim()}' is already taken by '${conflictingStudent?.name}' in ${targetClassObj?.name}.",
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        } else if (isSameClassAndRoll) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Student is already in this class with roll number ${student.rollNumber}. Please choose a different class/section or roll number.",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = transferReason,
                            onValueChange = { transferReason = it },
                            label = { Text("Reason for Transfer / Class Change (Optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }

                    "STATUS" -> {
                        Text(
                            text = "Mark student departure or graduation. Their historical records in $sourceYear and previous years will be kept safe and unchanged.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            FilterChip(
                                selected = selectedStatus == "LEFT",
                                onClick = { selectedStatus = "LEFT" },
                                label = { Text("Left School") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedStatus == "GRADUATED",
                                onClick = { selectedStatus = "GRADUATED" },
                                label = { Text("Graduated") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedStatus == "TRANSFERRED",
                                onClick = { selectedStatus = "TRANSFERRED" },
                                label = { Text("Transferred Out") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = transferReason,
                            onValueChange = { transferReason = it },
                            label = { Text("Remarks / Reason (e.g. TC issued, family relocation)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = false
                        )
                    }
                }
            }
        },
        confirmButton = {
            val isFormValid = when (actionType) {
                "PROMOTE", "RETAIN" -> selectedTargetYear.isNotBlank() && selectedTargetYear != sourceYear && selectedTargetClassId.isNotBlank() && newRollNumber.isNotBlank()
                "CHANGE_CLASS" -> selectedTargetClassId.isNotBlank() && newRollNumber.isNotBlank() && !isRollCollision && !isSameClassAndRoll
                "STATUS" -> selectedStatus.isNotBlank()
                else -> false
            }
            Button(
                onClick = {
                    val roll = newRollNumber.trim().ifBlank { student.rollNumber }
                    when (actionType) {
                        "PROMOTE" -> {
                            onPromote(selectedTargetYear, selectedTargetClassId, roll)
                        }
                        "RETAIN" -> {
                            onRetain(selectedTargetYear, selectedTargetClassId, roll)
                        }
                        "CHANGE_CLASS" -> {
                            onChangeClass(selectedTargetClassId, roll, transferReason)
                        }
                        "STATUS" -> {
                            onStatusChange(selectedStatus, transferReason.ifBlank { "Status updated to $selectedStatus" })
                        }
                    }
                },
                enabled = isFormValid
            ) {
                Text(
                    when (actionType) {
                        "PROMOTE" -> "Promote Student"
                        "RETAIN" -> "Retain Student"
                        "CHANGE_CLASS" -> "Confirm Class Change"
                        else -> "Save Status"
                    }
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
