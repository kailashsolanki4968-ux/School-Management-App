package com.example.ui.principal

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.automirrored.filled.EventNote
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ActivityCategory
import com.example.data.model.ActivityRecord
import com.example.data.model.TeacherSalary
import com.example.data.model.UserAccount
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusAbsentBg
import com.example.ui.theme.StatusLate
import com.example.ui.theme.StatusLateBg
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.StatusPresentBg
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalHistoryView(viewModel: PrincipalViewModel) {
    val allActivities by viewModel.allActivities.collectAsStateWithLifecycle()
    val filteredActivities by viewModel.filteredActivities.collectAsStateWithLifecycle()
    val allTeacherSalaries by viewModel.allTeacherSalaries.collectAsStateWithLifecycle()
    val teachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()

    val searchQuery by viewModel.historySearchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.historyCategoryFilter.collectAsStateWithLifecycle()
    val selectedDateFilter by viewModel.historyDateFilter.collectAsStateWithLifecycle()
    val selectedClassFilter by viewModel.historyClassFilter.collectAsStateWithLifecycle()
    val selectedPersonFilter by viewModel.historyPersonFilter.collectAsStateWithLifecycle()
    val currentSchool by viewModel.currentSchool.collectAsStateWithLifecycle()
    val schoolCurrency = currentSchool?.currency ?: "₹"

    var historySectionTab by remember { mutableStateOf(0) } // 0: All Operations History, 1: Teacher Salary Ledger
    var showRecordSalaryDialog by remember { mutableStateOf(false) }
    var showLogActivityDialog by remember { mutableStateOf(false) }
    var activityToDelete by remember { mutableStateOf<ActivityRecord?>(null) }
    var salaryToDelete by remember { mutableStateOf<TeacherSalary?>(null) }

    // Quick Stats
    val totalRecords = allActivities.size
    val feeRecordsCount = allActivities.count { it.category == "FEE_PAYMENT" }
    val salaryRecordsCount = allActivities.count { it.category == "SALARY_PAYMENT" }
    val attendanceRecordsCount = allActivities.count { it.category == "ATTENDANCE" }
    val totalSalariesPaid = allTeacherSalaries.sumOf { it.amountPaid }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card with Title & Quick Actions
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "School History & Logs",
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Permanent audit log of all school operations",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Metric counters row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HistoryStatBadge(
                                label = "Total Logs",
                                value = "$totalRecords",
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            HistoryStatBadge(
                                label = "Attendance",
                                value = "$attendanceRecordsCount",
                                color = StatusPresent,
                                modifier = Modifier.weight(1f)
                            )
                            HistoryStatBadge(
                                label = "Fee Logs",
                                value = "$feeRecordsCount",
                                color = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.weight(1f)
                            )
                            HistoryStatBadge(
                                label = "Salaries",
                                value = "$salaryRecordsCount",
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showRecordSalaryDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_disburse_salary")
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pay Salary", fontSize = 13.sp)
                            }

                            OutlinedButton(
                                onClick = { showLogActivityDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_log_activity")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Log Activity", fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // Tabs to switch between All History and Teacher Salary Ledger
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    PrimaryTabRow(
                        selectedTabIndex = historySectionTab,
                        containerColor = Color.Transparent,
                        divider = {}
                    ) {
                        Tab(
                            selected = historySectionTab == 0,
                            onClick = { historySectionTab = 0 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("All History ($totalRecords)", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        )
                        Tab(
                            selected = historySectionTab == 1,
                            onClick = { historySectionTab = 1 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Teacher Salaries (${allTeacherSalaries.size})", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        )
                    }
                }
            }

            if (historySectionTab == 0) {
                // ------------------ ALL HISTORY TAB ------------------

                // Search Bar
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setHistorySearchQuery(it) },
                        placeholder = { Text("Search by name, action, date, class, or amount...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setHistorySearchQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_history_search")
                    )
                }

                // Category Filter Chips
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Filter by Category",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        val categories = listOf(
                            "ALL" to "All Categories",
                            ActivityCategory.ATTENDANCE.name to "Attendance",
                            ActivityCategory.MARKS_TESTS.name to "Marks & Tests",
                            ActivityCategory.FEE_PAYMENT.name to "Fee Payments",
                            ActivityCategory.SALARY_PAYMENT.name to "Teacher Salaries",
                            ActivityCategory.STUDENT_RECORD.name to "Student Records",
                            ActivityCategory.TEACHER_RECORD.name to "Teacher Records",
                            ActivityCategory.ANNOUNCEMENT.name to "Notices & Broadcasts",
                            ActivityCategory.LEAVE_REQUEST.name to "Leave Requests",
                            ActivityCategory.OTHER.name to "Other Activities"
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(categories) { (catKey, catLabel) ->
                                val isSelected = selectedCategory == catKey
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.setHistoryCategoryFilter(catKey) },
                                    label = { Text(catLabel, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                        }
                    }
                }

                // Secondary Filters (Date, Class, Person)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Advanced Filters",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            val hasActiveFilters = searchQuery.isNotEmpty() ||
                                    selectedCategory != "ALL" ||
                                    selectedDateFilter.isNotEmpty() ||
                                    selectedClassFilter.isNotEmpty() ||
                                    selectedPersonFilter.isNotEmpty()

                            if (hasActiveFilters) {
                                TextButton(
                                    onClick = { viewModel.clearHistoryFilters() },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reset All", fontSize = 12.sp)
                                }
                            }
                        }

                        // Date filter & Class filter row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = selectedDateFilter,
                                onValueChange = { viewModel.setHistoryDateFilter(it) },
                                label = { Text("Filter Date (YYYY-MM-DD)", fontSize = 11.sp) },
                                placeholder = { Text("2026-09-03", fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (selectedDateFilter.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.setHistoryDateFilter("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = selectedClassFilter,
                                onValueChange = { viewModel.setHistoryClassFilter(it) },
                                label = { Text("Filter Class", fontSize = 11.sp) },
                                placeholder = { Text("Class 1A", fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Class, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (selectedClassFilter.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.setHistoryClassFilter("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Person / Student / Teacher filter
                        OutlinedTextField(
                            value = selectedPersonFilter,
                            onValueChange = { viewModel.setHistoryPersonFilter(it) },
                            label = { Text("Filter by Student or Teacher Name", fontSize = 11.sp) },
                            placeholder = { Text("e.g. Sarah Jenkins or Alex Rivera", fontSize = 11.sp) },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (selectedPersonFilter.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setHistoryPersonFilter("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Results Counter
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Showing ${filteredActivities.size} records",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // History Records List
                if (filteredActivities.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "No history records found",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Try adjusting your search query or filters above.",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                    }
                } else {
                    items(filteredActivities, key = { it.id }) { record ->
                        ActivityRecordCard(
                            record = record,
                            schoolCurrency = schoolCurrency,
                            onDelete = { activityToDelete = record }
                        )
                    }
                }
            } else {
                // ------------------ TEACHER SALARY LEDGER TAB ------------------
                item {
                    TeacherSalaryLedgerSection(
                        salaries = allTeacherSalaries,
                        schoolCurrency = schoolCurrency,
                        onAddSalary = { showRecordSalaryDialog = true },
                        onDeleteSalary = { salaryToDelete = it }
                    )
                }
            }
        }
    }

    // Record Teacher Salary Dialog
    if (showRecordSalaryDialog) {
        RecordTeacherSalaryDialog(
            teachers = teachers.filter { it.status == "APPROVED" },
            currency = schoolCurrency,
            onDismiss = { showRecordSalaryDialog = false },
            onSave = { teacherId, teacherName, month, salary, paid, date, remaining, mode, ref, remarks ->
                viewModel.recordTeacherSalary(
                    teacherId = teacherId,
                    teacherName = teacherName,
                    month = month,
                    monthlySalary = salary,
                    amountPaid = paid,
                    paymentDate = date,
                    remainingAmount = remaining,
                    paymentMode = mode,
                    transactionRef = ref,
                    remarks = remarks
                )
                showRecordSalaryDialog = false
            }
        )
    }

    // Log Custom School Activity Dialog
    if (showLogActivityDialog) {
        LogCustomActivityDialog(
            classes = classes,
            onDismiss = { showLogActivityDialog = false },
            onSave = { category, personName, action, details, amount, marks, className ->
                viewModel.logCustomActivity(
                    category = category,
                    personName = personName,
                    action = action,
                    details = details,
                    amount = amount,
                    marks = marks,
                    className = className
                )
                showLogActivityDialog = false
            }
        )
    }

    // Delete Activity Confirmation Dialog
    activityToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = { activityToDelete = null },
            title = { Text("Delete History Record") },
            text = { Text("Are you sure you want to remove this log entry? (\"${record.action}\" on ${record.date})") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteActivity(record.id)
                        activityToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { activityToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Salary Confirmation Dialog
    salaryToDelete?.let { salary ->
        AlertDialog(
            onDismissRequest = { salaryToDelete = null },
            title = { Text("Delete Salary Record") },
            text = { Text("Are you sure you want to remove the salary record for ${salary.teacherName} for ${salary.month}?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTeacherSalary(salary.id)
                        salaryToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { salaryToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun HistoryStatBadge(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
fun ActivityRecordCard(
    record: ActivityRecord,
    schoolCurrency: String = "₹",
    onDelete: () -> Unit
) {
    val (catColor, catIcon, catLabel) = getCategoryVisuals(record.category)

    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Category chip, Date & Time, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(catColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = catIcon,
                        contentDescription = null,
                        tint = catColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = catLabel,
                        color = catColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Date & Time
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${record.date} • ${record.time}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete record",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Title
            Text(
                text = record.action,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Person involved row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (record.personName.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (record.personRole == "TEACHER") Icons.Default.Badge else Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${record.personRole}: ${record.personName}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (record.className.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = record.className,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Amount Pill
                record.amount?.let { amt ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(StatusPresentBg)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "$schoolCurrency${String.format(Locale.getDefault(), "%.2f", amt)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusPresent
                        )
                    }
                }

                // Marks Pill
                record.marks?.let { m ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(StatusLateBg)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = m,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StatusLate
                        )
                    }
                }
            }

            // Details description
            if (record.details.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = record.details,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                )
            }

            // Footer info
            if (record.performedBy.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Logged by: ${record.performedBy}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }
    }
}

@Composable
fun TeacherSalaryLedgerSection(
    salaries: List<TeacherSalary>,
    schoolCurrency: String = "₹",
    onAddSalary: () -> Unit,
    onDeleteSalary: (TeacherSalary) -> Unit
) {
    val totalPaid = salaries.sumOf { it.amountPaid }
    val totalDue = salaries.sumOf { it.remainingAmount }
    var salarySearchQuery by remember { mutableStateOf("") }
    var selectedMonthFilter by remember { mutableStateOf("ALL") }

    val months = remember(salaries) {
        listOf("ALL") + salaries.map { it.month }.distinct()
    }

    val filteredSalaries = remember(salaries, salarySearchQuery, selectedMonthFilter) {
        salaries.filter { sal ->
            val matchMonth = selectedMonthFilter == "ALL" || sal.month == selectedMonthFilter
            val matchSearch = salarySearchQuery.isBlank() ||
                    sal.teacherName.contains(salarySearchQuery, ignoreCase = true) ||
                    sal.paymentMode.contains(salarySearchQuery, ignoreCase = true) ||
                    sal.transactionRef.contains(salarySearchQuery, ignoreCase = true) ||
                    sal.remarks.contains(salarySearchQuery, ignoreCase = true)
            matchMonth && matchSearch
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Overview Card
        ElevatedCard(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Teacher Salaries Ledger",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Full school salary disbursements history (Principal Only)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }

                    Button(
                        onClick = onAddSalary,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_add_salary_ledger")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Record Payment", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$schoolCurrency${String.format(Locale.getDefault(), "%,.2f", totalPaid)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = StatusPresent
                            )
                        )
                        Text("Total Disbursed", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$schoolCurrency${String.format(Locale.getDefault(), "%,.2f", totalDue)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (totalDue > 0) MaterialTheme.colorScheme.error else StatusPresent
                            )
                        )
                        Text("Remaining Due", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${salaries.size}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text("Total Records", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    }
                }
            }
        }

        // Search & Month filters
        OutlinedTextField(
            value = salarySearchQuery,
            onValueChange = { salarySearchQuery = it },
            placeholder = { Text("Search by teacher name, reference, remarks...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (salarySearchQuery.isNotEmpty()) {
                    IconButton(onClick = { salarySearchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = null)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        // Month filter row
        if (months.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(months) { m ->
                    FilterChip(
                        selected = selectedMonthFilter == m,
                        onClick = { selectedMonthFilter = m },
                        label = { Text(if (m == "ALL") "All Months" else m, fontSize = 12.sp) }
                    )
                }
            }
        }

        // Salary Cards List
        if (filteredSalaries.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No teacher salary records match your filter.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            filteredSalaries.forEach { sal ->
                ElevatedCard(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = sal.teacherName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Period: ${sal.month} • Paid: ${sal.paymentDate}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val statusBg = if (sal.status == "PAID") StatusPresentBg else StatusLateBg
                                val statusColor = if (sal.status == "PAID") StatusPresent else StatusLate
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(statusBg)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = sal.status,
                                        color = statusColor,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = { onDeleteSalary(sal) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Monthly Salary", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                                Text("${sal.currency}${String.format(Locale.getDefault(), "%,.2f", sal.monthlySalary)}", fontWeight = FontWeight.SemiBold)
                            }
                            Column {
                                Text("Amount Paid", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                                Text("${sal.currency}${String.format(Locale.getDefault(), "%,.2f", sal.amountPaid)}", fontWeight = FontWeight.Bold, color = StatusPresent)
                            }
                            Column {
                                Text("Remaining Due", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                                Text(
                                    text = "${sal.currency}${String.format(Locale.getDefault(), "%,.2f", sal.remainingAmount)}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (sal.remainingAmount > 0) MaterialTheme.colorScheme.error else StatusPresent
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Mode: ${sal.paymentMode} • Ref: ${sal.transactionRef.ifBlank { "N/A" }}",
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )

                        if (sal.remarks.isNotBlank()) {
                            Text(
                                text = "Remarks: ${sal.remarks}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Processed by: ${sal.recordedBy}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordTeacherSalaryDialog(
    teachers: List<UserAccount>,
    currency: String = "₹",
    onDismiss: () -> Unit,
    onSave: (
        teacherId: String,
        teacherName: String,
        month: String,
        monthlySalary: Double,
        amountPaid: Double,
        paymentDate: String,
        remainingAmount: Double,
        paymentMode: String,
        transactionRef: String,
        remarks: String
    ) -> Unit
) {
    var selectedTeacher by remember { mutableStateOf(teachers.firstOrNull()) }
    var teacherExpanded by remember { mutableStateOf(false) }

    val currentMonthStr = remember {
        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())
    }
    val todayDateStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    var month by remember { mutableStateOf(currentMonthStr) }
    var monthlySalaryText by remember { mutableStateOf("3200.00") }
    var amountPaidText by remember { mutableStateOf("3200.00") }
    var paymentDate by remember { mutableStateOf(todayDateStr) }
    var paymentMode by remember { mutableStateOf("Bank Transfer") }
    var modeExpanded by remember { mutableStateOf(false) }
    var transactionRef by remember { mutableStateOf("TXN-${System.currentTimeMillis().toString().takeLast(6)}") }
    var remarks by remember { mutableStateOf("Monthly base salary payment disbursed") }
    var manualRemainingText by remember { mutableStateOf("") }

    val monthlySalary = monthlySalaryText.toDoubleOrNull() ?: 0.0
    val amountPaid = amountPaidText.toDoubleOrNull() ?: 0.0
    val autoRemaining = maxOf(0.0, monthlySalary - amountPaid)
    val remaining = if (manualRemainingText.isNotBlank()) {
        manualRemainingText.toDoubleOrNull() ?: autoRemaining
    } else {
        autoRemaining
    }

    val paymentModes = listOf("Bank Transfer", "Direct Deposit", "Cash", "Cheque", "Online Portal")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Teacher Salary") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    // Teacher Dropdown
                    ExposedDropdownMenuBox(
                        expanded = teacherExpanded,
                        onExpandedChange = { teacherExpanded = !teacherExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedTeacher?.let { "${it.name} (${it.id})" } ?: "Select Teacher",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Teacher") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = teacherExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = teacherExpanded,
                            onDismissRequest = { teacherExpanded = false }
                        ) {
                            teachers.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text("${t.name} (${t.id})") },
                                    onClick = {
                                        selectedTeacher = t
                                        teacherExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = month,
                        onValueChange = { month = it },
                        label = { Text("Salary Period / Month") },
                        placeholder = { Text("e.g. September 2026") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = monthlySalaryText,
                            onValueChange = { monthlySalaryText = it },
                            label = { Text("Monthly Salary ($currency)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = amountPaidText,
                            onValueChange = { amountPaidText = it },
                            label = { Text("Amount Paid ($)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = paymentDate,
                            onValueChange = { paymentDate = it },
                            label = { Text("Payment Date") },
                            placeholder = { Text("YYYY-MM-DD") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = String.format(Locale.getDefault(), "%.2f", remaining),
                            onValueChange = { manualRemainingText = it },
                            label = { Text("Remaining ($)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    // Payment Mode Dropdown
                    ExposedDropdownMenuBox(
                        expanded = modeExpanded,
                        onExpandedChange = { modeExpanded = !modeExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = paymentMode,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Mode") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modeExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = modeExpanded,
                            onDismissRequest = { modeExpanded = false }
                        ) {
                            paymentModes.forEach { mode ->
                                DropdownMenuItem(
                                    text = { Text(mode) },
                                    onClick = {
                                        paymentMode = mode
                                        modeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = transactionRef,
                        onValueChange = { transactionRef = it },
                        label = { Text("Reference / Receipt No.") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Remarks & Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    selectedTeacher?.let { teacher ->
                        if (monthlySalary >= 0 && amountPaid >= 0) {
                            onSave(
                                teacher.id,
                                teacher.name,
                                month,
                                monthlySalary,
                                amountPaid,
                                paymentDate,
                                remaining,
                                paymentMode,
                                transactionRef,
                                remarks
                            )
                        }
                    }
                },
                enabled = selectedTeacher != null && monthlySalary >= 0 && amountPaid >= 0
            ) {
                Text("Record Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogCustomActivityDialog(
    classes: List<com.example.data.model.SchoolClass>,
    onDismiss: () -> Unit,
    onSave: (
        category: String,
        personName: String,
        action: String,
        details: String,
        amount: Double?,
        marks: String?,
        className: String
    ) -> Unit
) {
    val categories = listOf(
        ActivityCategory.STUDENT_RECORD.name to "Student Record / Update",
        ActivityCategory.TEACHER_RECORD.name to "Teacher Record / Update",
        ActivityCategory.ATTENDANCE.name to "Attendance Activity",
        ActivityCategory.MARKS_TESTS.name to "Marks / Academic Result",
        ActivityCategory.FEE_PAYMENT.name to "Student Fee Activity",
        ActivityCategory.SALARY_PAYMENT.name to "Teacher Salary Activity",
        ActivityCategory.ANNOUNCEMENT.name to "Notice / Announcement",
        ActivityCategory.OTHER.name to "Other Important School Activity"
    )

    var selectedCategory by remember { mutableStateOf(categories[0].first) }
    var catExpanded by remember { mutableStateOf(false) }

    var personName by remember { mutableStateOf("") }
    var action by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var marksText by remember { mutableStateOf("") }
    var selectedClassName by remember { mutableStateOf("") }
    var classExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log School Activity") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    // Category Dropdown
                    ExposedDropdownMenuBox(
                        expanded = catExpanded,
                        onExpandedChange = { catExpanded = !catExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = categories.find { it.first == selectedCategory }?.second ?: selectedCategory,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Activity Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = catExpanded,
                            onDismissRequest = { catExpanded = false }
                        ) {
                            categories.forEach { (catKey, catLabel) ->
                                DropdownMenuItem(
                                    text = { Text(catLabel) },
                                    onClick = {
                                        selectedCategory = catKey
                                        catExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = action,
                        onValueChange = { action = it },
                        label = { Text("Action / Summary Title") },
                        placeholder = { Text("e.g. Promoted to Next Grade or Transfer Issued") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = personName,
                        onValueChange = { personName = it },
                        label = { Text("Person Involved (Student / Teacher)") },
                        placeholder = { Text("e.g. Alex Rivera") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    // Class Dropdown (Optional)
                    ExposedDropdownMenuBox(
                        expanded = classExpanded,
                        onExpandedChange = { classExpanded = !classExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedClassName.ifBlank { "Select Class (Optional)" },
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Associated Class") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = classExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = classExpanded,
                            onDismissRequest = { classExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None") },
                                onClick = {
                                    selectedClassName = ""
                                    classExpanded = false
                                }
                            )
                            classes.forEach { cls ->
                                DropdownMenuItem(
                                    text = { Text(cls.name) },
                                    onClick = {
                                        selectedClassName = cls.name
                                        classExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Amount ($) (Optional)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = marksText,
                            onValueChange = { marksText = it },
                            label = { Text("Marks / Score (Optional)") },
                            placeholder = { Text("e.g. 95/100") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it },
                        label = { Text("Detailed Notes & Context") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (action.isNotBlank() && personName.isNotBlank()) {
                        val amount = amountText.toDoubleOrNull()
                        onSave(
                            selectedCategory,
                            personName.trim(),
                            action.trim(),
                            details.trim(),
                            amount,
                            marksText.trim().ifBlank { null },
                            selectedClassName
                        )
                    }
                },
                enabled = action.isNotBlank() && personName.isNotBlank()
            ) {
                Text("Save to History")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

fun getCategoryVisuals(category: String): Triple<Color, ImageVector, String> {
    return when (category) {
        "ATTENDANCE" -> Triple(Color(0xFF00897B), Icons.Default.HowToReg, "Attendance")
        "MARKS_TESTS" -> Triple(Color(0xFFE65100), Icons.Default.Grade, "Marks & Results")
        "FEE_PAYMENT" -> Triple(Color(0xFF2E7D32), Icons.Default.Receipt, "Fee Payment")
        "SALARY_PAYMENT" -> Triple(Color(0xFF5E35B1), Icons.Default.AccountBalanceWallet, "Teacher Salary")
        "STUDENT_RECORD" -> Triple(Color(0xFF0277BD), Icons.Default.Person, "Student Record")
        "TEACHER_RECORD" -> Triple(Color(0xFF1565C0), Icons.Default.Badge, "Teacher Record")
        "ANNOUNCEMENT" -> Triple(Color(0xFFC2185B), Icons.Default.Campaign, "Announcement")
        "LEAVE_REQUEST" -> Triple(Color(0xFFD84315), Icons.AutoMirrored.Filled.EventNote, "Leave Request")
        else -> Triple(Color(0xFF546E7A), Icons.Default.History, "School Activity")
    }
}
