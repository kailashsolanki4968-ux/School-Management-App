package com.example.data.cloud

import java.io.IOException

class OfflineException(
    message: String = "Online authentication is unavailable because this device is offline. Please check your internet connection to log in or sync accounts across devices."
) : IOException(message)
