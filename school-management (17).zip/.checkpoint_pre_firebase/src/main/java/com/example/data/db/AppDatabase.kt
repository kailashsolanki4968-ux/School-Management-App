package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AcademicYear
import com.example.data.model.StudentEnrollment
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.LeaveStatus
import com.example.data.model.LeaveType
import com.example.data.model.School
import com.example.data.model.SchoolClass
import com.example.data.model.SchoolTest
import com.example.data.model.Student
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.TeacherSalary
import com.example.data.model.ActivityRecord
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.security.PasswordSecurity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Database(
    entities = [
        School::class,
        AcademicYear::class,
        StudentEnrollment::class,
        UserAccount::class,
        SchoolClass::class,
        Student::class,
        AttendanceRecord::class,
        AttendanceSubmissionRecord::class,
        Homework::class,
        SchoolTest::class,
        StudentMark::class,
        StudentFee::class,
        FeePayment::class,
        Announcement::class,
        LeaveRequest::class,
        ChatMessage::class,
        TeacherSalary::class,
        ActivityRecord::class
    ],
    version = 9,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao
    abstract fun academicYearDao(): AcademicYearDao
    abstract fun studentEnrollmentDao(): StudentEnrollmentDao
    abstract fun userDao(): UserDao
    abstract fun classDao(): ClassDao
    abstract fun studentDao(): StudentDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun attendanceSubmissionDao(): AttendanceSubmissionDao
    abstract fun homeworkDao(): HomeworkDao
    abstract fun testDao(): TestDao
    abstract fun markDao(): MarkDao
    abstract fun feeDao(): FeeDao
    abstract fun feePaymentDao(): FeePaymentDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun leaveDao(): LeaveDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun teacherSalaryDao(): TeacherSalaryDao
    abstract fun activityRecordDao(): ActivityRecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS academic_years (
                        schoolId TEXT NOT NULL,
                        yearCode TEXT NOT NULL,
                        displayName TEXT NOT NULL,
                        isCurrent INTEGER NOT NULL,
                        startDate TEXT NOT NULL,
                        endDate TEXT NOT NULL,
                        status TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        PRIMARY KEY(schoolId, yearCode)
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS student_enrollments (
                        studentId TEXT NOT NULL,
                        schoolId TEXT NOT NULL,
                        academicYear TEXT NOT NULL,
                        classId TEXT NOT NULL,
                        rollNumber TEXT NOT NULL,
                        status TEXT NOT NULL,
                        promotedFromYear TEXT,
                        promotedFromClassId TEXT,
                        promotionDate INTEGER,
                        remarks TEXT,
                        createdAt INTEGER NOT NULL,
                        PRIMARY KEY(studentId, academicYear)
                    )
                """.trimIndent())

                try { db.execSQL("ALTER TABLE schools ADD COLUMN currentAcademicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE attendance_records ADD COLUMN academicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE attendance_submissions ADD COLUMN academicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE homework ADD COLUMN academicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE school_tests ADD COLUMN academicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE student_marks ADD COLUMN academicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE fee_payments ADD COLUMN academicYear TEXT NOT NULL DEFAULT '2026-27'") } catch (_: Exception) {}

                try {
                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS student_fees_new (
                            studentId TEXT NOT NULL,
                            schoolId TEXT NOT NULL,
                            studentName TEXT NOT NULL,
                            rollNumber TEXT NOT NULL,
                            classId TEXT NOT NULL,
                            totalFee REAL NOT NULL,
                            totalPaid REAL NOT NULL,
                            remainingFee REAL NOT NULL,
                            status TEXT NOT NULL,
                            lastPaymentDate TEXT,
                            currency TEXT NOT NULL,
                            updatedAt INTEGER NOT NULL,
                            academicYear TEXT NOT NULL DEFAULT '2026-27',
                            PRIMARY KEY(studentId, academicYear)
                        )
                    """.trimIndent())
                    db.execSQL("""
                        INSERT OR REPLACE INTO student_fees_new (studentId, schoolId, studentName, rollNumber, classId, totalFee, totalPaid, remainingFee, status, lastPaymentDate, currency, updatedAt, academicYear)
                        SELECT studentId, schoolId, studentName, rollNumber, classId, totalFee, totalPaid, remainingFee, status, lastPaymentDate, currency, updatedAt, '2026-27' FROM student_fees
                    """.trimIndent())
                    db.execSQL("DROP TABLE student_fees")
                    db.execSQL("ALTER TABLE student_fees_new RENAME TO student_fees")
                } catch (_: Exception) {}

                try {
                    db.execSQL("""
                        INSERT OR IGNORE INTO student_enrollments (studentId, schoolId, academicYear, classId, rollNumber, status, promotedFromYear, promotedFromClassId, promotionDate, remarks, createdAt)
                        SELECT id, schoolId, '2026-27', classId, rollNumber, 'ACTIVE', NULL, NULL, NULL, NULL, 1726000000000 FROM students
                    """.trimIndent())
                } catch (_: Exception) {}

                try {
                    db.execSQL("INSERT OR IGNORE INTO academic_years (schoolId, yearCode, displayName, isCurrent, startDate, endDate, status, createdAt) VALUES ('SCH_OAKRIDGE_101', '2026-27', 'Academic Year 2026-27', 1, '2026-04-01', '2027-03-31', 'ACTIVE', 1726000000000)")
                    db.execSQL("INSERT OR IGNORE INTO academic_years (schoolId, yearCode, displayName, isCurrent, startDate, endDate, status, createdAt) VALUES ('SCH_OAKRIDGE_101', '2027-28', 'Academic Year 2027-28', 0, '2027-04-01', '2028-03-31', 'UPCOMING', 1726000000000)")
                    db.execSQL("INSERT OR IGNORE INTO academic_years (schoolId, yearCode, displayName, isCurrent, startDate, endDate, status, createdAt) VALUES ('SCH_OAKRIDGE_101', '2028-29', 'Academic Year 2028-29', 0, '2028-04-01', '2029-03-31', 'UPCOMING', 1726000000000)")
                } catch (_: Exception) {}
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "school_management.db"
                )
                    .addMigrations(MIGRATION_8_9)
                    .fallbackToDestructiveMigration(true)
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                CoroutineScope(Dispatchers.IO).launch {
                    ensureSeedData(instance)
                }
                instance
            }
        }

        suspend fun ensureSeedData(db: AppDatabase) {
            val defaultSchoolId = "SCH_OAKRIDGE_101"
            try {
                if (db.schoolDao().getSchoolCount() == 0 || db.userDao().getTotalPrincipalCount() == 0) {
                    populateInitialData(db)
                } else {
                    if (db.teacherSalaryDao().getSalaryCount() == 0) {
                        populateInitialTeacherSalaries(db)
                    }
                    if (db.activityRecordDao().getActivityCount() == 0) {
                        populateInitialActivityRecords(db)
                    }
                    if (db.academicYearDao().getAcademicYearCount(defaultSchoolId) == 0) {
                        populateAcademicYears(db, defaultSchoolId)
                    }
                    if (db.classDao().getClassById("CLASS_11A") == null) {
                        db.classDao().insertClasses(listOf(
                            SchoolClass("CLASS_11A", defaultSchoolId, "Grade 11 - Section A", "Grade 11", "A", null, "Room 301"),
                            SchoolClass("CLASS_11B", defaultSchoolId, "Grade 11 - Section B", "Grade 11", "B", null, "Room 302"),
                            SchoolClass("CLASS_12A", defaultSchoolId, "Grade 12 - Section A", "Grade 12", "A", null, "Room 401")
                        ))
                    }
                    if (db.studentEnrollmentDao().getEnrollmentCount(defaultSchoolId, "2026-27") == 0) {
                        populateInitialEnrollments(db, defaultSchoolId)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        suspend fun populateAcademicYears(db: AppDatabase, schoolId: String) {
            val years = listOf(
                AcademicYear(schoolId, "2026-27", "Academic Year 2026-27", isCurrent = true, startDate = "2026-04-01", endDate = "2027-03-31", status = "ACTIVE"),
                AcademicYear(schoolId, "2027-28", "Academic Year 2027-28", isCurrent = false, startDate = "2027-04-01", endDate = "2028-03-31", status = "UPCOMING"),
                AcademicYear(schoolId, "2028-29", "Academic Year 2028-29", isCurrent = false, startDate = "2028-04-01", endDate = "2029-03-31", status = "UPCOMING")
            )
            db.academicYearDao().insertAcademicYears(years)
        }

        suspend fun populateInitialEnrollments(db: AppDatabase, schoolId: String) {
            val students = db.studentDao().getStudentsBySchoolDirect(schoolId)
            val enrollments = students.map { s ->
                StudentEnrollment(
                    studentId = s.id,
                    schoolId = schoolId,
                    academicYear = "2026-27",
                    classId = s.classId,
                    rollNumber = s.rollNumber,
                    status = "ACTIVE"
                )
            }
            if (enrollments.isNotEmpty()) {
                db.studentEnrollmentDao().insertEnrollments(enrollments)
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            val defaultSchoolId = "SCH_OAKRIDGE_101"
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            // 1. Initial School
            val school = School(
                id = defaultSchoolId,
                name = "Oakridge International School",
                code = "OAK101",
                address = "101 Crestview Boulevard",
                principalId = "PRIN001",
                contactEmail = "principal@oakridge.edu",
                contactPhone = "+1 (555) 234-5678",
                currency = "₹",
                currencyCode = "INR"
            )
            db.schoolDao().insertSchool(school)

            // 2. Initial Users with Salting
            val salt1 = PasswordSecurity.generateSalt()
            val salt2 = PasswordSecurity.generateSalt()
            val salt3 = PasswordSecurity.generateSalt()
            val salt4 = PasswordSecurity.generateSalt()
            val salt5 = PasswordSecurity.generateSalt()

            val initialUsers = listOf(
                UserAccount(
                    id = "PRIN001",
                    schoolId = defaultSchoolId,
                    name = "Dr. Eleanor Vance",
                    email = "eleanor.vance@oakridge.edu",
                    phone = "+1 555-0101",
                    role = UserRole.PRINCIPAL.name,
                    passwordHash = PasswordSecurity.hashPassword("principal123", salt1),
                    passwordSalt = salt1,
                    securityQuestion = "What was the name of your first school?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Lincoln High"),
                    status = AccountStatus.APPROVED.name,
                    subject = "Administration"
                ),
                UserAccount(
                    id = "TCH101",
                    schoolId = defaultSchoolId,
                    name = "Sarah Jenkins",
                    email = "sarah.jenkins@oakridge.edu",
                    phone = "+1 555-0102",
                    role = UserRole.TEACHER.name,
                    passwordHash = PasswordSecurity.hashPassword("teacher123", salt2),
                    passwordSalt = salt2,
                    securityQuestion = "What was the name of your first school?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Springfield Academy"),
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_10A",
                    subject = "Mathematics",
                    joiningDate = "2023-08-15",
                    monthlySalary = 48000.0
                ),
                UserAccount(
                    id = "TCH102",
                    schoolId = defaultSchoolId,
                    name = "Robert Sterling",
                    email = "robert.sterling@oakridge.edu",
                    phone = "+1 555-0103",
                    role = UserRole.TEACHER.name,
                    passwordHash = PasswordSecurity.hashPassword("teacher123", salt3),
                    passwordSalt = salt3,
                    securityQuestion = "What is your mother's maiden name?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Sterling"),
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_10B",
                    subject = "Science",
                    joiningDate = "2024-01-10",
                    monthlySalary = 45000.0
                ),
                UserAccount(
                    id = "TCH103",
                    schoolId = defaultSchoolId,
                    name = "Elena Rostova",
                    email = "elena.rostova@oakridge.edu",
                    phone = "+1 555-0104",
                    role = UserRole.TEACHER.name,
                    passwordHash = PasswordSecurity.hashPassword("teacher123", salt4),
                    passwordSalt = salt4,
                    securityQuestion = "What was your childhood nickname?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Ellie"),
                    status = AccountStatus.PENDING.name,
                    assignedClassId = null,
                    subject = "English Literature",
                    joiningDate = "2024-07-01",
                    monthlySalary = 42000.0
                ),
                UserAccount(
                    id = "PAR101",
                    schoolId = defaultSchoolId,
                    name = "Michael Hayes",
                    email = "michael.hayes@example.com",
                    phone = "+1 555-0105",
                    role = UserRole.PARENT.name,
                    passwordHash = PasswordSecurity.hashPassword("parent123", salt5),
                    passwordSalt = salt5,
                    securityQuestion = "What city were you born in?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Chicago"),
                    status = AccountStatus.APPROVED.name,
                    linkedStudentIds = "STU_1001,STU_1002"
                )
            )
            db.userDao().insertUsers(initialUsers)

            // 3. Initial Classes
            val initialClasses = listOf(
                SchoolClass("CLASS_10A", defaultSchoolId, "Grade 10 - Section A", "Grade 10", "A", "TCH101", "Room 101"),
                SchoolClass("CLASS_10B", defaultSchoolId, "Grade 10 - Section B", "Grade 10", "B", "TCH102", "Room 102"),
                SchoolClass("CLASS_09A", defaultSchoolId, "Grade 9 - Section A", "Grade 9", "A", null, "Room 201"),
                SchoolClass("CLASS_09B", defaultSchoolId, "Grade 9 - Section B", "Grade 9", "B", null, "Room 202"),
                SchoolClass("CLASS_11A", defaultSchoolId, "Grade 11 - Section A", "Grade 11", "A", null, "Room 301"),
                SchoolClass("CLASS_11B", defaultSchoolId, "Grade 11 - Section B", "Grade 11", "B", null, "Room 302"),
                SchoolClass("CLASS_12A", defaultSchoolId, "Grade 12 - Section A", "Grade 12", "A", null, "Room 401")
            )
            db.classDao().insertClasses(initialClasses)

            // 4. Initial Students
            val initialStudents = listOf(
                Student("STU_1001", defaultSchoolId, "101", "Liam Hayes", "CLASS_10A", "Male", "Michael Hayes", "+1 555-0105", "PAR101", "+1 555-0199", "12 Maple St"),
                Student("STU_1002", defaultSchoolId, "102", "Emma Hayes", "CLASS_10A", "Female", "Michael Hayes", "+1 555-0105", "PAR101", "+1 555-0198", "12 Maple St"),
                Student("STU_1003", defaultSchoolId, "103", "Noah Williams", "CLASS_10A", "Male", "David Williams", "+1 555-0123", null, "+1 555-0197", "45 Oak Ave"),
                Student("STU_1004", defaultSchoolId, "104", "Olivia Brown", "CLASS_10A", "Female", "James Brown", "+1 555-0124", null, "+1 555-0196", "78 Pine Rd"),
                Student("STU_1005", defaultSchoolId, "105", "James Davis", "CLASS_10A", "Male", "Robert Davis", "+1 555-0125", null, "+1 555-0195", "90 Cedar Ln"),
                Student("STU_1006", defaultSchoolId, "106", "Sophia Miller", "CLASS_10A", "Female", "William Miller", "+1 555-0126", null, "+1 555-0194", "23 Birch Ct"),
                Student("STU_1007", defaultSchoolId, "107", "Benjamin Wilson", "CLASS_10A", "Male", "Richard Wilson", "+1 555-0127", null, "+1 555-0193", "56 Elm St"),
                Student("STU_1008", defaultSchoolId, "108", "Isabella Taylor", "CLASS_10A", "Female", "Joseph Taylor", "+1 555-0128", null, "+1 555-0192", "89 Ash Way"),

                Student("STU_2001", defaultSchoolId, "201", "Lucas Anderson", "CLASS_10B", "Male", "Thomas Anderson", "+1 555-0131", null, "+1 555-0181", "14 Walnut St"),
                Student("STU_2002", defaultSchoolId, "202", "Mia Martinez", "CLASS_10B", "Female", "Charles Martinez", "+1 555-0132", null, "+1 555-0182", "36 Cherry Dr"),
                Student("STU_2003", defaultSchoolId, "203", "Ethan Garcia", "CLASS_10B", "Male", "Daniel Garcia", "+1 555-0133", null, "+1 555-0183", "58 Spruce St")
            )
            db.studentDao().insertStudents(initialStudents)

            // 5. Initial Attendance
            val initialAttendance = listOf(
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1001", "Liam Hayes", "101", "CLASS_10A", AttendanceStatus.PRESENT.name, "TCH101"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1002", "Emma Hayes", "102", "CLASS_10A", AttendanceStatus.PRESENT.name, "TCH101"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1003", "Noah Williams", "103", "CLASS_10A", AttendanceStatus.PRESENT.name, "TCH101"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1004", "Olivia Brown", "104", "CLASS_10A", AttendanceStatus.ABSENT.name, "TCH101", "Mild Fever, parent informed"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1005", "James Davis", "105", "CLASS_10A", AttendanceStatus.PRESENT.name, "TCH101"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1006", "Sophia Miller", "106", "CLASS_10A", AttendanceStatus.PRESENT.name, "TCH101"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1007", "Benjamin Wilson", "107", "CLASS_10A", AttendanceStatus.LATE.name, "TCH101", "Bus delay"),
                AttendanceRecord(UUID.randomUUID().toString(), defaultSchoolId, today, "STU_1008", "Isabella Taylor", "108", "CLASS_10A", AttendanceStatus.PRESENT.name, "TCH101")
            )
            db.attendanceDao().insertAttendance(initialAttendance)

            // 6. Initial Attendance Submission
            val submission = AttendanceSubmissionRecord(
                id = "CLASS_10A_$today",
                schoolId = defaultSchoolId,
                date = today,
                classId = "CLASS_10A",
                className = "Grade 10 - Section A",
                classTeacherId = "TCH101",
                classTeacherName = "Sarah Jenkins",
                totalStudents = 8,
                presentStudents = 6,
                absentStudents = 1,
                absentStudentNames = "Olivia Brown",
                absentNotes = "Olivia Brown: Mild Fever, parent informed",
                submittedStatus = "SUBMITTED"
            )
            db.attendanceSubmissionDao().insertSubmission(submission)

            // 7. Initial Homework
            val initialHomework = listOf(
                Homework(UUID.randomUUID().toString(), defaultSchoolId, "CLASS_10A", "TCH101", "Sarah Jenkins", "Mathematics", "Trigonometry Exercises 4.1 to 4.3", "Solve problems 1 through 15 in chapter 4.", today, today),
                Homework(UUID.randomUUID().toString(), defaultSchoolId, "CLASS_10A", "TCH101", "Sarah Jenkins", "Mathematics", "Quadratic Equations Worksheet", "Complete practice set C on page 84.", today, today)
            )
            db.homeworkDao().insertHomeworkList(initialHomework)

            // 8. Initial Tests & Marks
            val test1Id = "TEST_10A_MATH_01"
            val test2Id = "TEST_10A_SCI_01"
            val initialTests = listOf(
                SchoolTest(
                    id = test1Id,
                    schoolId = defaultSchoolId,
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    testName = "Unit Test 1",
                    subject = "Mathematics",
                    date = today,
                    maxMarks = 100.0,
                    createdByTeacherId = "TCH101",
                    createdByTeacherName = "Sarah Jenkins",
                    totalStudents = 8,
                    averageScore = 77.0,
                    highestScore = 94.0
                ),
                SchoolTest(
                    id = test2Id,
                    schoolId = defaultSchoolId,
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    testName = "Mid-Term Examination",
                    subject = "Science",
                    date = today,
                    maxMarks = 100.0,
                    createdByTeacherId = "TCH101",
                    createdByTeacherName = "Sarah Jenkins",
                    totalStudents = 8,
                    averageScore = 78.0,
                    highestScore = 96.0
                )
            )
            db.testDao().insertTests(initialTests)

            val initialMarks = listOf(
                // Math Test Marks with Ranks
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1001", "Liam Hayes", "101", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 94.0, 94.0, 1, "A+", "Outstanding problem solving and algebraic precision", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1004", "Olivia Brown", "104", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 91.0, 91.0, 2, "A+", "Excellent performance on geometric proofs", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1002", "Emma Hayes", "102", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 88.0, 88.0, 3, "A", "Very strong conceptual understanding", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1003", "Noah Williams", "103", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 78.0, 78.0, 4, "B+", "Good effort, practice quadratic calculations", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1005", "James Davis", "105", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 74.0, 74.0, 5, "B", "Consistent work, revise trigonometry formulas", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1006", "Sophia Miller", "106", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 71.0, 71.0, 6, "B", "Good progress throughout the term", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1008", "Isabella Taylor", "108", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 68.0, 68.0, 7, "B", "Focus on stepwise solutions", today),
                StudentMark(UUID.randomUUID().toString(), test1Id, defaultSchoolId, "STU_1007", "Benjamin Wilson", "107", "CLASS_10A", "Unit Test 1", "Mathematics", 100.0, 62.0, 62.0, 8, "C", "Needs additional practice in graphing", today),

                // Science Test Marks with Ranks
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1004", "Olivia Brown", "104", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 96.0, 96.0, 1, "A+", "Top score in lab physics and chemistry", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1001", "Liam Hayes", "101", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 92.0, 92.0, 2, "A+", "Great analytical reasoning in biology", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1002", "Emma Hayes", "102", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 85.0, 85.0, 3, "A", "Very thorough and neat answers", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1005", "James Davis", "105", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 80.0, 80.0, 4, "A", "Commendable lab report quality", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1003", "Noah Williams", "103", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 76.0, 76.0, 5, "B+", "Satisfactory grasp of physical systems", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1006", "Sophia Miller", "106", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 70.0, 70.0, 6, "B", "Steady progress", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1008", "Isabella Taylor", "108", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 65.0, 65.0, 7, "C", "Review chemical equation balancing", today),
                StudentMark(UUID.randomUUID().toString(), test2Id, defaultSchoolId, "STU_1007", "Benjamin Wilson", "107", "CLASS_10A", "Mid-Term Examination", "Science", 100.0, 60.0, 60.0, 8, "C", "Attend remedial science review session", today)
            )
            db.markDao().insertMarks(initialMarks)

            // 8b. Initial Student Fees & Payment History
            val initialFees = listOf(
                StudentFee("STU_1001", defaultSchoolId, "Liam Hayes", "101", "CLASS_10A", 4500.0, 4500.0, 0.0, "PAID", today),
                StudentFee("STU_1002", defaultSchoolId, "Emma Hayes", "102", "CLASS_10A", 4500.0, 3000.0, 1500.0, "PARTIAL", today),
                StudentFee("STU_1003", defaultSchoolId, "Noah Williams", "103", "CLASS_10A", 4500.0, 2000.0, 2500.0, "PARTIAL", today),
                StudentFee("STU_1004", defaultSchoolId, "Olivia Brown", "104", "CLASS_10A", 4500.0, 4500.0, 0.0, "PAID", today),
                StudentFee("STU_1005", defaultSchoolId, "James Davis", "105", "CLASS_10A", 4500.0, 0.0, 4500.0, "UNPAID", null),
                StudentFee("STU_1006", defaultSchoolId, "Sophia Miller", "106", "CLASS_10A", 4500.0, 4500.0, 0.0, "PAID", today),
                StudentFee("STU_1007", defaultSchoolId, "Benjamin Wilson", "107", "CLASS_10A", 4500.0, 1500.0, 3000.0, "PARTIAL", today),
                StudentFee("STU_1008", defaultSchoolId, "Isabella Taylor", "108", "CLASS_10A", 4500.0, 0.0, 4500.0, "UNPAID", null),

                StudentFee("STU_2001", defaultSchoolId, "Lucas Anderson", "201", "CLASS_10B", 4500.0, 4500.0, 0.0, "PAID", today),
                StudentFee("STU_2002", defaultSchoolId, "Mia Martinez", "202", "CLASS_10B", 4500.0, 2500.0, 2000.0, "PARTIAL", today),
                StudentFee("STU_2003", defaultSchoolId, "Ethan Garcia", "203", "CLASS_10B", 4500.0, 0.0, 4500.0, "UNPAID", null)
            )
            db.feeDao().insertStudentFees(initialFees)

            val initialPayments = listOf(
                // Liam Hayes Payments
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1001", "Liam Hayes", "101", "CLASS_10A", 2500.0, today, "Bank Transfer", "Term 1 Tuition & Science Laboratory Fee", "REC-2026-101", "Dr. Eleanor Vance"),
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1001", "Liam Hayes", "101", "CLASS_10A", 2000.0, today, "Online", "Term 2 Tuition & Sports Activity Fee", "REC-2026-102", "Dr. Eleanor Vance"),

                // Emma Hayes Payments
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1002", "Emma Hayes", "102", "CLASS_10A", 3000.0, today, "Bank Transfer", "Term 1 Tuition Fee Paid by Parent", "REC-2026-103", "Dr. Eleanor Vance"),

                // Noah Williams Payment
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1003", "Noah Williams", "103", "CLASS_10A", 2000.0, today, "Cheque", "Cheque #883921 Cleared", "REC-2026-104", "Dr. Eleanor Vance"),

                // Olivia Brown Payment
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1004", "Olivia Brown", "104", "CLASS_10A", 4500.0, today, "Online", "Full Annual Tuition Fee Payment", "REC-2026-105", "Dr. Eleanor Vance"),

                // Sophia Miller Payment
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1006", "Sophia Miller", "106", "CLASS_10A", 4500.0, today, "Card", "Annual Fee Payment at School Office", "REC-2026-106", "Dr. Eleanor Vance"),

                // Benjamin Wilson Payment
                FeePayment(UUID.randomUUID().toString(), defaultSchoolId, "STU_1007", "Benjamin Wilson", "107", "CLASS_10A", 1500.0, today, "Cash", "First Installment Cash Receipt", "REC-2026-107", "Dr. Eleanor Vance")
            )
            db.feePaymentDao().insertPayments(initialPayments)

            // 9. Initial Announcements
            val initialAnnouncements = listOf(
                Announcement(UUID.randomUUID().toString(), defaultSchoolId, "Annual Science Exhibition", "The annual inter-school science fair will take place next Friday.", "ALL", AnnouncementPriority.EVENT.name, "Dr. Eleanor Vance", today),
                Announcement(UUID.randomUUID().toString(), defaultSchoolId, "Mid-Term Examination Schedule", "Mid-term examinations will commence from the 15th of next month.", "ALL", AnnouncementPriority.URGENT.name, "Dr. Eleanor Vance", today)
            )
            db.announcementDao().insertAnnouncements(initialAnnouncements)

            // 10. Initial Leave Requests
            val initialLeaves = listOf(
                LeaveRequest(UUID.randomUUID().toString(), defaultSchoolId, "TCH101", "Sarah Jenkins", LeaveType.CASUAL.name, today, today, 1, "Family function", LeaveStatus.APPROVED.name, "Approved by Principal")
            )
            db.leaveDao().insertLeaveRequests(initialLeaves)

            // 11. Initial Chat Messages
            val initialMessages = listOf(
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    studentId = "STU_1001",
                    studentName = "Liam Hayes",
                    senderId = "TCH101",
                    senderName = "Sarah Jenkins",
                    senderRole = "TEACHER",
                    receiverId = "PAR101",
                    receiverName = "Michael Hayes",
                    receiverRole = "PARENT",
                    message = "Hello Mr. Hayes, Liam showed exceptional understanding in today's Mathematics session on Trigonometry.",
                    timestamp = System.currentTimeMillis() - 7200000,
                    status = "DELIVERED"
                ),
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    studentId = "STU_1001",
                    studentName = "Liam Hayes",
                    senderId = "PAR101",
                    senderName = "Michael Hayes",
                    senderRole = "PARENT",
                    receiverId = "TCH101",
                    receiverName = "Sarah Jenkins",
                    receiverRole = "TEACHER",
                    message = "Thank you so much Ms. Jenkins! We have been encouraging him to practice the chapter problems daily.",
                    timestamp = System.currentTimeMillis() - 3600000,
                    status = "DELIVERED"
                ),
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    studentId = "STU_1002",
                    studentName = "Emma Hayes",
                    senderId = "PRIN001",
                    senderName = "Dr. Eleanor Vance",
                    senderRole = "PRINCIPAL",
                    receiverId = "PAR101",
                    receiverName = "Michael Hayes",
                    receiverRole = "PARENT",
                    message = "Dear Mr. Hayes, Emma has been selected to represent Grade 10 in the upcoming Science Fair exhibition.",
                    timestamp = System.currentTimeMillis() - 1800000,
                    status = "DELIVERED"
                )
            )
            db.chatMessageDao().insertMessages(initialMessages)

            // 12. Initial Teacher Salaries
            populateInitialTeacherSalaries(db)

            // 13. Initial School Activity & Operations History
            populateInitialActivityRecords(db)

            // 14. Initial Academic Years and Student Enrollments
            populateAcademicYears(db, defaultSchoolId)
            populateInitialEnrollments(db, defaultSchoolId)
        }

        suspend fun populateInitialTeacherSalaries(db: AppDatabase) {
            val defaultSchoolId = "SCH_OAKRIDGE_101"
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            val initialSalaries = listOf(
                TeacherSalary(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    teacherId = "TCH101",
                    teacherName = "Sarah Jenkins",
                    month = "September 2026",
                    monthlySalary = 4500.0,
                    amountPaid = 4500.0,
                    paymentDate = today,
                    remainingAmount = 0.0,
                    paymentMode = "Bank Transfer",
                    transactionRef = "TXN-SAL-9821",
                    remarks = "Full monthly salary disbarment for September 2026",
                    status = "PAID",
                    recordedBy = "Dr. Eleanor Vance",
                    timestamp = System.currentTimeMillis() - 86400000L
                ),
                TeacherSalary(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    teacherId = "TCH101",
                    teacherName = "Sarah Jenkins",
                    month = "August 2026",
                    monthlySalary = 4500.0,
                    amountPaid = 4500.0,
                    paymentDate = "2026-08-01",
                    remainingAmount = 0.0,
                    paymentMode = "Bank Transfer",
                    transactionRef = "TXN-SAL-8824",
                    remarks = "August 2026 regular payroll",
                    status = "PAID",
                    recordedBy = "Dr. Eleanor Vance",
                    timestamp = System.currentTimeMillis() - (86400000L * 33)
                ),
                TeacherSalary(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    teacherId = "TCH102",
                    teacherName = "Michael Chang",
                    month = "September 2026",
                    monthlySalary = 4200.0,
                    amountPaid = 4200.0,
                    paymentDate = today,
                    remainingAmount = 0.0,
                    paymentMode = "Bank Transfer",
                    transactionRef = "TXN-SAL-9822",
                    remarks = "September 2026 payroll including physics lab coordinator allowance",
                    status = "PAID",
                    recordedBy = "Dr. Eleanor Vance",
                    timestamp = System.currentTimeMillis() - 82800000L
                ),
                TeacherSalary(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    teacherId = "TCH102",
                    teacherName = "Michael Chang",
                    month = "August 2026",
                    monthlySalary = 4200.0,
                    amountPaid = 4200.0,
                    paymentDate = "2026-08-01",
                    remainingAmount = 0.0,
                    paymentMode = "Bank Transfer",
                    transactionRef = "TXN-SAL-8825",
                    remarks = "August 2026 regular payroll",
                    status = "PAID",
                    recordedBy = "Dr. Eleanor Vance",
                    timestamp = System.currentTimeMillis() - (86400000L * 33)
                ),
                TeacherSalary(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    teacherId = "TCH103",
                    teacherName = "Emily Davis",
                    month = "September 2026",
                    monthlySalary = 4000.0,
                    amountPaid = 2500.0,
                    paymentDate = today,
                    remainingAmount = 1500.0,
                    paymentMode = "Cheque",
                    transactionRef = "CHQ-778102",
                    remarks = "First installment disbursed. Balance due on 15th.",
                    status = "PARTIAL",
                    recordedBy = "Dr. Eleanor Vance",
                    timestamp = System.currentTimeMillis() - 43200000L
                ),
                TeacherSalary(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    teacherId = "TCH103",
                    teacherName = "Emily Davis",
                    month = "August 2026",
                    monthlySalary = 4000.0,
                    amountPaid = 4000.0,
                    paymentDate = "2026-08-01",
                    remainingAmount = 0.0,
                    paymentMode = "Bank Transfer",
                    transactionRef = "TXN-SAL-8826",
                    remarks = "August 2026 payroll",
                    status = "PAID",
                    recordedBy = "Dr. Eleanor Vance",
                    timestamp = System.currentTimeMillis() - (86400000L * 33)
                )
            )
            db.teacherSalaryDao().insertSalaries(initialSalaries)
        }

        suspend fun populateInitialActivityRecords(db: AppDatabase) {
            val defaultSchoolId = "SCH_OAKRIDGE_101"
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())

            val initialActivities = listOf(
                // Attendance Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "08:45 AM",
                    timestamp = System.currentTimeMillis() - 14400000L,
                    category = "ATTENDANCE",
                    personName = "Sarah Jenkins",
                    personRole = "TEACHER",
                    personId = "TCH101",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Daily Attendance Submitted",
                    amount = null,
                    marks = null,
                    details = "Total Students: 8 • Present: 7 • Absent: 1 (Benjamin Wilson - Medical excuse verified). All records locked.",
                    performedBy = "Sarah Jenkins"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "08:50 AM",
                    timestamp = System.currentTimeMillis() - 14100000L,
                    category = "ATTENDANCE",
                    personName = "Michael Chang",
                    personRole = "TEACHER",
                    personId = "TCH102",
                    classId = "CLASS_10B",
                    className = "Grade 10 - Section B",
                    action = "Daily Attendance Submitted",
                    amount = null,
                    marks = null,
                    details = "Total Students: 3 • Present: 3 • Absent: 0. 100% attendance achieved.",
                    performedBy = "Michael Chang"
                ),

                // Tests & Marks Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "10:15 AM",
                    timestamp = System.currentTimeMillis() - 12000000L,
                    category = "MARKS_TESTS",
                    personName = "Sarah Jenkins",
                    personRole = "TEACHER",
                    personId = "TCH101",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Unit Test 1 Marks Uploaded (Mathematics)",
                    amount = null,
                    marks = "Avg: 78.1% • Top: 94/100 (Liam Hayes)",
                    details = "8 student scorecards created. Top performers: Liam Hayes (94%), Olivia Brown (91%), Emma Hayes (88%).",
                    performedBy = "Sarah Jenkins"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "11:30 AM",
                    timestamp = System.currentTimeMillis() - 9600000L,
                    category = "MARKS_TESTS",
                    personName = "Michael Chang",
                    personRole = "TEACHER",
                    personId = "TCH102",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Mid-Term Examination Results Published (Science)",
                    amount = null,
                    marks = "Avg: 77.4% • Top: 96/100 (Olivia Brown)",
                    details = "Lab practical and theory evaluation completed. High average in Physics and Chemistry modules.",
                    performedBy = "Michael Chang"
                ),

                // Student Records Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "09:10 AM",
                    timestamp = System.currentTimeMillis() - 13000000L,
                    category = "STUDENT_RECORD",
                    personName = "Liam Hayes",
                    personRole = "STUDENT",
                    personId = "STU_1001",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Student Enrollment & Profile Configured",
                    amount = null,
                    marks = null,
                    details = "Roll No: 101 • Parent: Michael Hayes (+1 555-0144) • Emergency Contact: Elena Hayes (+1 555-0145) • Address: 742 Evergreen Terrace",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "09:20 AM",
                    timestamp = System.currentTimeMillis() - 12800000L,
                    category = "STUDENT_RECORD",
                    personName = "Emma Hayes",
                    personRole = "STUDENT",
                    personId = "STU_1002",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Parent Account Linked",
                    amount = null,
                    marks = null,
                    details = "Linked to verified parent account PAR101 (Michael Hayes) with full portal access.",
                    performedBy = "Dr. Eleanor Vance"
                ),

                // Teacher Records Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "08:00 AM",
                    timestamp = System.currentTimeMillis() - 16000000L,
                    category = "TEACHER_RECORD",
                    personName = "Sarah Jenkins",
                    personRole = "TEACHER",
                    personId = "TCH101",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Class Teacher Assignment Approved",
                    amount = null,
                    marks = null,
                    details = "Role: Mathematics Faculty & Lead Class Teacher for Grade 10-A. Permissions granted for attendance and marks management.",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "08:15 AM",
                    timestamp = System.currentTimeMillis() - 15500000L,
                    category = "TEACHER_RECORD",
                    personName = "Michael Chang",
                    personRole = "TEACHER",
                    personId = "TCH102",
                    classId = "CLASS_10B",
                    className = "Grade 10 - Section B",
                    action = "Faculty Profile Registered",
                    amount = null,
                    marks = null,
                    details = "Department: Physical & Natural Sciences • Subject: Science • Email: michael.chang@oakridge.edu",
                    performedBy = "Dr. Eleanor Vance"
                ),

                // Fee Payments Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "10:30 AM",
                    timestamp = System.currentTimeMillis() - 11000000L,
                    category = "FEE_PAYMENT",
                    personName = "Liam Hayes",
                    personRole = "STUDENT",
                    personId = "STU_1001",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Tuition Fee Collected (REC-2026-101)",
                    amount = 2500.0,
                    marks = null,
                    details = "Term 1 Tuition & Science Laboratory Fee collected via Bank Transfer. Official receipt issued to Michael Hayes.",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "11:00 AM",
                    timestamp = System.currentTimeMillis() - 10000000L,
                    category = "FEE_PAYMENT",
                    personName = "Olivia Brown",
                    personRole = "STUDENT",
                    personId = "STU_1004",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Full Annual Tuition Fee Collected (REC-2026-105)",
                    amount = 4500.0,
                    marks = null,
                    details = "Full annual fee payment processed online. Account status marked PAID (Remaining: $0.00).",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "11:45 AM",
                    timestamp = System.currentTimeMillis() - 9000000L,
                    category = "FEE_PAYMENT",
                    personName = "Emma Hayes",
                    personRole = "STUDENT",
                    personId = "STU_1002",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Term 1 Installment Collected (REC-2026-103)",
                    amount = 3000.0,
                    marks = null,
                    details = "Paid via Bank Transfer. Remaining balance: $1,500.00 scheduled for Term 2.",
                    performedBy = "Dr. Eleanor Vance"
                ),

                // Teacher Salary Payments Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "01:15 PM",
                    timestamp = System.currentTimeMillis() - 7000000L,
                    category = "SALARY_PAYMENT",
                    personName = "Sarah Jenkins",
                    personRole = "TEACHER",
                    personId = "TCH101",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Monthly Salary Disbursed (September 2026)",
                    amount = 4500.0,
                    marks = null,
                    details = "Disbursed $4,500.00 via Bank Transfer (Ref: TXN-SAL-9821). Full payment cleared. Remaining dues: $0.00.",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "01:20 PM",
                    timestamp = System.currentTimeMillis() - 6800000L,
                    category = "SALARY_PAYMENT",
                    personName = "Michael Chang",
                    personRole = "TEACHER",
                    personId = "TCH102",
                    classId = "CLASS_10B",
                    className = "Grade 10 - Section B",
                    action = "Monthly Salary Disbursed (September 2026)",
                    amount = 4200.0,
                    marks = null,
                    details = "Disbursed $4,200.00 via Bank Transfer (Ref: TXN-SAL-9822). Physics lab coordinator allowance included.",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "01:30 PM",
                    timestamp = System.currentTimeMillis() - 6400000L,
                    category = "SALARY_PAYMENT",
                    personName = "Emily Davis",
                    personRole = "TEACHER",
                    personId = "TCH103",
                    classId = "",
                    className = "",
                    action = "Partial Salary Disbursed (September 2026)",
                    amount = 2500.0,
                    marks = null,
                    details = "Paid $2,500.00 via Cheque #CHQ-778102 against monthly salary $4,000.00. Remaining balance: $1,500.00.",
                    performedBy = "Dr. Eleanor Vance"
                ),

                // Notices & Broadcasts Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "02:00 PM",
                    timestamp = System.currentTimeMillis() - 5000000L,
                    category = "ANNOUNCEMENT",
                    personName = "Dr. Eleanor Vance",
                    personRole = "PRINCIPAL",
                    personId = "PRIN001",
                    classId = "ALL",
                    className = "All Classes",
                    action = "Notice Broadcasted: Annual Science Exhibition",
                    amount = null,
                    marks = null,
                    details = "Priority: EVENT • Target: ALL • The annual inter-school science fair will take place next Friday.",
                    performedBy = "Dr. Eleanor Vance"
                ),
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "02:15 PM",
                    timestamp = System.currentTimeMillis() - 4500000L,
                    category = "ANNOUNCEMENT",
                    personName = "Dr. Eleanor Vance",
                    personRole = "PRINCIPAL",
                    personId = "PRIN001",
                    classId = "ALL",
                    className = "All Classes",
                    action = "Notice Broadcasted: Mid-Term Examination Schedule",
                    amount = null,
                    marks = null,
                    details = "Priority: URGENT • Target: ALL • Mid-term examinations will commence from the 15th of next month.",
                    performedBy = "Dr. Eleanor Vance"
                ),

                // Leaves Activities
                ActivityRecord(
                    id = UUID.randomUUID().toString(),
                    schoolId = defaultSchoolId,
                    date = today,
                    time = "03:00 PM",
                    timestamp = System.currentTimeMillis() - 3000000L,
                    category = "LEAVE_REQUEST",
                    personName = "Sarah Jenkins",
                    personRole = "TEACHER",
                    personId = "TCH101",
                    classId = "CLASS_10A",
                    className = "Grade 10 - Section A",
                    action = "Leave Request Approved",
                    amount = null,
                    marks = null,
                    details = "Type: CASUAL • Duration: 1 day ($today) • Reason: Family function • Comment: Approved by Principal. Substitute assigned.",
                    performedBy = "Dr. Eleanor Vance"
                )
            )

            db.activityRecordDao().insertActivities(initialActivities)
        }

    }
}

