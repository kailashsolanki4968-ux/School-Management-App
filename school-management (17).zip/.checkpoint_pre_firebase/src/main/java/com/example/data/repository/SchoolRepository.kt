package com.example.data.repository

import android.content.Context
import com.example.data.cloud.CloudDatabaseService
import com.example.data.cloud.OfflineException
import com.example.data.cloud.SchoolDataBundle
import com.example.data.db.AppDatabase
import com.example.data.model.AcademicYear
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementTarget
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.PromotionBatchResult
import com.example.data.model.School
import com.example.data.model.SchoolClass
import com.example.data.model.SchoolTest
import com.example.data.model.Student
import com.example.data.model.StudentEnrollment
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.TeacherSalary
import com.example.data.model.ActivityRecord
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.security.PasswordSecurity
import com.example.data.session.SessionManager
import com.example.data.session.UserSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class SchoolRepository(
    private val database: AppDatabase,
    private val sessionManager: SessionManager,
    private val cloudService: CloudDatabaseService
) {
    val sessionState: StateFlow<UserSession?> = sessionManager.sessionState

    val currentSchoolId: String
        get() = sessionManager.sessionState.value?.schoolId ?: "SCH_OAKRIDGE_101"

    // --- Schools ---
    fun getAllSchools(): Flow<List<School>> = database.schoolDao().getAllSchools()
    fun getSchoolByIdFlow(id: String): Flow<School?> = database.schoolDao().getSchoolByIdFlow(id)
    fun getCurrentSchoolFlow(): Flow<School?> = database.schoolDao().getSchoolByIdFlow(currentSchoolId)

    suspend fun getSchoolById(id: String): School? = withContext(Dispatchers.IO) {
        database.schoolDao().getSchoolById(id) ?: cloudService.getCloudSchoolById(id)
    }

    suspend fun updateSchoolCurrency(currency: String, currencyCode: String) = withContext(Dispatchers.IO) {
        database.schoolDao().updateSchoolCurrency(currentSchoolId, currency, currencyCode)
        cloudService.updateCloudSchoolCurrency(currentSchoolId, currency, currencyCode)
    }

    suspend fun registerSchool(school: School): Result<School> = withContext(Dispatchers.IO) {
        val cloudRes = cloudService.registerSchool(school)
        if (cloudRes.isFailure) return@withContext cloudRes
        database.schoolDao().insertSchool(school)
        Result.success(school)
    }

    // --- Academic Years & Student Promotions (Isolated per School & Year) ---
    fun getAllAcademicYears(): Flow<List<AcademicYear>> =
        database.academicYearDao().getAllAcademicYears(currentSchoolId)

    fun getCurrentAcademicYearFlow(): Flow<AcademicYear?> =
        database.academicYearDao().getCurrentAcademicYearFlow(currentSchoolId)

    suspend fun getCurrentAcademicYearCodeDirect(): String = withContext(Dispatchers.IO) {
        database.academicYearDao().getCurrentAcademicYear(currentSchoolId)?.yearCode
            ?: database.schoolDao().getSchoolById(currentSchoolId)?.currentAcademicYear
            ?: "2026-27"
    }

    suspend fun createAcademicYear(
        yearCode: String,
        displayName: String = "Academic Year $yearCode",
        startDate: String = "",
        endDate: String = ""
    ): Result<AcademicYear> = withContext(Dispatchers.IO) {
        val cleanCode = yearCode.trim()
        if (cleanCode.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Academic year code cannot be empty"))
        }
        val existing = database.academicYearDao().getAcademicYear(currentSchoolId, cleanCode)
        if (existing != null) {
            return@withContext Result.failure(IllegalArgumentException("Academic year $cleanCode already exists"))
        }
        val academicYear = AcademicYear(
            schoolId = currentSchoolId,
            yearCode = cleanCode,
            displayName = displayName.ifBlank { "Academic Year $cleanCode" },
            isCurrent = false,
            startDate = startDate,
            endDate = endDate,
            status = "UPCOMING"
        )
        database.academicYearDao().insertAcademicYear(academicYear)
        syncSchoolDataToCloud(currentSchoolId)
        Result.success(academicYear)
    }

    suspend fun setCurrentAcademicYear(yearCode: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.academicYearDao().clearCurrentFlags(currentSchoolId)
            database.academicYearDao().setCurrentYear(currentSchoolId, yearCode)
            database.academicYearDao().updateYearStatus(currentSchoolId, yearCode, "ACTIVE")
            database.schoolDao().updateSchoolAcademicYear(currentSchoolId, yearCode)

            // Sync all students enrolled in this newly active year to their active class & roll number
            val activeEnrollments = database.studentEnrollmentDao().getEnrollmentsByYearDirect(currentSchoolId, yearCode)
            for (enrollment in activeEnrollments) {
                val stu = database.studentDao().getStudentById(enrollment.studentId)
                if (stu != null) {
                    database.studentDao().updateStudent(
                        stu.copy(
                            classId = enrollment.classId,
                            rollNumber = enrollment.rollNumber
                        )
                    )
                }
            }

            syncSchoolDataToCloud(currentSchoolId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getEnrollmentsByYear(academicYear: String): Flow<List<StudentEnrollment>> =
        database.studentEnrollmentDao().getEnrollmentsByYear(currentSchoolId, academicYear)

    fun getEnrollmentsByClassAndYear(classId: String, academicYear: String): Flow<List<StudentEnrollment>> =
        database.studentEnrollmentDao().getEnrollmentsByClassAndYear(currentSchoolId, classId, academicYear)

    fun getEnrollmentsForStudent(studentId: String): Flow<List<StudentEnrollment>> =
        database.studentEnrollmentDao().getEnrollmentsForStudent(studentId)

    suspend fun getEnrollmentsForStudentDirect(studentId: String): List<StudentEnrollment> = withContext(Dispatchers.IO) {
        database.studentEnrollmentDao().getEnrollmentsForStudentDirect(studentId)
    }

    suspend fun getEnrollmentForStudentAndYear(studentId: String, academicYear: String): StudentEnrollment? = withContext(Dispatchers.IO) {
        database.studentEnrollmentDao().getEnrollment(studentId, academicYear)
    }

    suspend fun promoteStudent(
        studentId: String,
        fromYear: String,
        toYear: String,
        targetClassId: String,
        targetRollNumber: String,
        newYearFee: Double = 0.0,
        remarks: String? = null
    ): Result<StudentEnrollment> = withContext(Dispatchers.IO) {
        val cleanStudentId = studentId.trim()
        val cleanFromYear = fromYear.trim()
        val cleanToYear = toYear.trim()
        val cleanTargetClassId = targetClassId.trim()

        if (cleanStudentId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Student identifier cannot be blank."))
        }
        if (cleanFromYear.isBlank() || cleanToYear.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Source and Target Academic Years must not be blank."))
        }
        if (cleanFromYear.equals(cleanToYear, ignoreCase = true)) {
            return@withContext Result.failure(IllegalArgumentException("Target Academic Year cannot be the same as Source Academic Year ($cleanFromYear). For mid-session class changes, use class change."))
        }
        if (cleanTargetClassId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Target Class must be selected."))
        }

        val targetYearObj = database.academicYearDao().getAcademicYear(currentSchoolId, cleanToYear)
            ?: return@withContext Result.failure(IllegalArgumentException("Target Academic Year '$cleanToYear' does not exist."))

        val targetClass = database.classDao().getClassById(cleanTargetClassId)
            ?: return@withContext Result.failure(IllegalArgumentException("Target Class '$cleanTargetClassId' does not exist."))

        val student = database.studentDao().getStudentById(cleanStudentId)
            ?: return@withContext Result.failure(IllegalArgumentException("Student not found for ID $cleanStudentId."))

        // Validation against duplicate student-year assignments
        val existingEnrollment = database.studentEnrollmentDao().getEnrollment(cleanStudentId, cleanToYear)
        if (existingEnrollment != null) {
            val existingClassName = database.classDao().getClassById(existingEnrollment.classId)?.name ?: existingEnrollment.classId
            return@withContext Result.failure(IllegalArgumentException("${student.name} is already enrolled in academic year $cleanToYear ($existingClassName). Duplicate promotion prevented."))
        }

        val finalRoll = targetRollNumber.trim().ifBlank { student.rollNumber.trim() }

        // Check roll number collision in target class and target year
        val targetClassEnrollments = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(
            currentSchoolId, cleanTargetClassId, cleanToYear
        )
        if (targetClassEnrollments.any { it.rollNumber.trim().equals(finalRoll, ignoreCase = true) && it.studentId != cleanStudentId }) {
            return@withContext Result.failure(IllegalArgumentException("Roll number $finalRoll is already assigned to another student in ${targetClass.name} for $cleanToYear."))
        }

        // Mark previous enrollment as PROMOTED
        val prevEnrollment = database.studentEnrollmentDao().getEnrollment(cleanStudentId, cleanFromYear)
        if (prevEnrollment != null) {
            database.studentEnrollmentDao().updateEnrollmentStatus(cleanStudentId, cleanFromYear, "PROMOTED")
        }

        // Create new enrollment
        val newEnrollment = StudentEnrollment(
            studentId = cleanStudentId,
            schoolId = currentSchoolId,
            academicYear = cleanToYear,
            classId = cleanTargetClassId,
            rollNumber = finalRoll,
            status = "ACTIVE",
            promotedFromYear = cleanFromYear,
            promotedFromClassId = prevEnrollment?.classId ?: student.classId,
            promotionDate = System.currentTimeMillis(),
            remarks = remarks ?: "Promoted from $cleanFromYear to $cleanToYear (${targetClass.name})"
        )
        database.studentEnrollmentDao().insertEnrollment(newEnrollment)

        // If toYear is current academic year, update student's active classId and rollNumber
        val currentYear = getCurrentAcademicYearCodeDirect()
        if (cleanToYear == currentYear) {
            database.studentDao().updateStudent(
                student.copy(
                    classId = cleanTargetClassId,
                    rollNumber = finalRoll
                )
            )
        }

        // Create student fee for new academic year
        val school = database.schoolDao().getSchoolById(currentSchoolId)
        val curr = school?.currency ?: "₹"
        val newFee = StudentFee(
            studentId = student.id,
            schoolId = currentSchoolId,
            studentName = student.name,
            rollNumber = finalRoll,
            classId = cleanTargetClassId,
            totalFee = maxOf(0.0, newYearFee),
            totalPaid = 0.0,
            remainingFee = maxOf(0.0, newYearFee),
            status = if (newYearFee > 0.0) "UNPAID" else "PAID",
            currency = curr,
            academicYear = cleanToYear
        )
        database.feeDao().insertStudentFee(newFee)

        // Record activity log
        val targetClassName = targetClass.name
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
            timestamp = System.currentTimeMillis(),
            category = "PROMOTION",
            personName = student.name,
            personRole = "STUDENT",
            personId = student.id,
            classId = cleanTargetClassId,
            className = targetClassName,
            action = "Student Promoted to $targetClassName ($cleanToYear)",
            details = "Promoted from $cleanFromYear to $cleanToYear. Roll No: $finalRoll. ${remarks ?: ""}".trim(),
            performedBy = "Principal"
        )
        database.activityRecordDao().insertActivity(activity)

        syncSchoolDataToCloud(currentSchoolId)
        Result.success(newEnrollment)
    }

    suspend fun promoteBatchStudents(
        studentIds: List<String>,
        fromYear: String,
        toYear: String,
        targetClassId: String,
        newYearFee: Double = 0.0
    ): Result<PromotionBatchResult> = withContext(Dispatchers.IO) {
        val cleanFromYear = fromYear.trim()
        val cleanToYear = toYear.trim()
        val cleanTargetClassId = targetClassId.trim()

        if (studentIds.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No students selected for promotion."))
        }
        if (cleanFromYear.isBlank() || cleanToYear.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Source and Target Academic Years must not be blank."))
        }
        if (cleanFromYear.equals(cleanToYear, ignoreCase = true)) {
            return@withContext Result.failure(IllegalArgumentException("Target Academic Year cannot be the same as Source Academic Year ($cleanFromYear)."))
        }
        if (cleanTargetClassId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Target Class must be selected."))
        }

        val targetYearObj = database.academicYearDao().getAcademicYear(currentSchoolId, cleanToYear)
            ?: return@withContext Result.failure(IllegalArgumentException("Target Academic Year '$cleanToYear' does not exist."))

        val targetClass = database.classDao().getClassById(cleanTargetClassId)
            ?: return@withContext Result.failure(IllegalArgumentException("Target Class '$cleanTargetClassId' does not exist."))

        val school = database.schoolDao().getSchoolById(currentSchoolId)
        val curr = school?.currency ?: "₹"
        val currentActiveYear = getCurrentAcademicYearCodeDirect()

        val targetClassEnrollments = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(
            currentSchoolId, cleanTargetClassId, cleanToYear
        )
        val usedRollNumbers = targetClassEnrollments.map { it.rollNumber.trim() }.filter { it.isNotBlank() }.toMutableSet()

        var successCount = 0
        var failureCount = 0
        val errorMessages = mutableListOf<String>()

        val sourceEnrollments = database.studentEnrollmentDao().getEnrollmentsByYearDirect(currentSchoolId, cleanFromYear)
            .associateBy { it.studentId }

        for (studentId in studentIds) {
            val sId = studentId.trim()
            val student = database.studentDao().getStudentById(sId)
            if (student == null) {
                failureCount++
                errorMessages.add("Student with ID $sId not found.")
                continue
            }

            val existing = database.studentEnrollmentDao().getEnrollment(sId, cleanToYear)
            if (existing != null) {
                failureCount++
                errorMessages.add("${student.name} is already enrolled in $cleanToYear.")
                continue
            }

            val preferredRoll = sourceEnrollments[sId]?.rollNumber?.trim()?.ifBlank { student.rollNumber.trim() } ?: ""
            var assignedRoll = preferredRoll
            if (assignedRoll.isBlank() || usedRollNumbers.contains(assignedRoll)) {
                var candidate = 1
                while (usedRollNumbers.contains(candidate.toString())) {
                    candidate++
                }
                assignedRoll = candidate.toString()
            }
            usedRollNumbers.add(assignedRoll)

            if (sourceEnrollments.containsKey(sId)) {
                database.studentEnrollmentDao().updateEnrollmentStatus(sId, cleanFromYear, "PROMOTED")
            }

            val enrollment = StudentEnrollment(
                studentId = sId,
                schoolId = currentSchoolId,
                academicYear = cleanToYear,
                classId = cleanTargetClassId,
                rollNumber = assignedRoll,
                status = "ACTIVE",
                promotedFromYear = cleanFromYear,
                promotedFromClassId = sourceEnrollments[sId]?.classId ?: student.classId,
                promotionDate = System.currentTimeMillis(),
                remarks = "Batch promoted from $cleanFromYear to $cleanToYear (${targetClass.name})"
            )
            database.studentEnrollmentDao().insertEnrollment(enrollment)

            if (cleanToYear == currentActiveYear) {
                database.studentDao().updateStudent(
                    student.copy(
                        classId = cleanTargetClassId,
                        rollNumber = assignedRoll
                    )
                )
            }

            val newFee = StudentFee(
                studentId = student.id,
                schoolId = currentSchoolId,
                studentName = student.name,
                rollNumber = assignedRoll,
                classId = cleanTargetClassId,
                totalFee = maxOf(0.0, newYearFee),
                totalPaid = 0.0,
                remainingFee = maxOf(0.0, newYearFee),
                status = if (newYearFee > 0.0) "UNPAID" else "PAID",
                currency = curr,
                academicYear = cleanToYear
            )
            database.feeDao().insertStudentFee(newFee)

            successCount++
        }

        if (successCount > 0) {
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
                timestamp = System.currentTimeMillis(),
                category = "PROMOTION",
                personName = "Principal",
                personRole = "PRINCIPAL",
                personId = "PRIN001",
                classId = cleanTargetClassId,
                className = targetClass.name,
                action = "Batch Promoted $successCount Students to ${targetClass.name} ($cleanToYear)",
                details = "Promoted $successCount students from $cleanFromYear to $cleanToYear. Failures: $failureCount.",
                performedBy = "Principal"
            )
            database.activityRecordDao().insertActivity(activity)
            syncSchoolDataToCloud(currentSchoolId)
        }

        Result.success(
            PromotionBatchResult(
                total = studentIds.size,
                successCount = successCount,
                failureCount = failureCount,
                errorMessages = errorMessages
            )
        )
    }

    suspend fun retainStudent(
        studentId: String,
        fromYear: String,
        toYear: String,
        targetClassId: String,
        targetRollNumber: String,
        newYearFee: Double = 0.0,
        remarks: String? = null
    ): Result<StudentEnrollment> = withContext(Dispatchers.IO) {
        val cleanStudentId = studentId.trim()
        val cleanFromYear = fromYear.trim()
        val cleanToYear = toYear.trim()
        val cleanTargetClassId = targetClassId.trim()

        if (cleanStudentId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Student identifier cannot be blank."))
        }
        if (cleanFromYear.isBlank() || cleanToYear.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Source and Target Academic Years must not be blank."))
        }
        if (cleanFromYear.equals(cleanToYear, ignoreCase = true)) {
            return@withContext Result.failure(IllegalArgumentException("Target Academic Year cannot be the same as Source Academic Year ($cleanFromYear)."))
        }
        if (cleanTargetClassId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Target Class must be selected."))
        }

        val targetYearObj = database.academicYearDao().getAcademicYear(currentSchoolId, cleanToYear)
            ?: return@withContext Result.failure(IllegalArgumentException("Target Academic Year '$cleanToYear' does not exist."))

        val targetClass = database.classDao().getClassById(cleanTargetClassId)
            ?: return@withContext Result.failure(IllegalArgumentException("Target Class '$cleanTargetClassId' does not exist."))

        val student = database.studentDao().getStudentById(cleanStudentId)
            ?: return@withContext Result.failure(IllegalArgumentException("Student not found for ID $cleanStudentId."))

        val existingEnrollment = database.studentEnrollmentDao().getEnrollment(cleanStudentId, cleanToYear)
        if (existingEnrollment != null) {
            val existingClassName = database.classDao().getClassById(existingEnrollment.classId)?.name ?: existingEnrollment.classId
            return@withContext Result.failure(IllegalArgumentException("${student.name} is already enrolled in academic year $cleanToYear ($existingClassName)."))
        }

        val finalRoll = targetRollNumber.trim().ifBlank { student.rollNumber.trim() }

        val targetClassEnrollments = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(
            currentSchoolId, cleanTargetClassId, cleanToYear
        )
        if (targetClassEnrollments.any { it.rollNumber.trim().equals(finalRoll, ignoreCase = true) && it.studentId != cleanStudentId }) {
            return@withContext Result.failure(IllegalArgumentException("Roll number $finalRoll is already assigned to another student in ${targetClass.name} for $cleanToYear."))
        }

        database.studentEnrollmentDao().updateEnrollmentStatus(cleanStudentId, cleanFromYear, "RETAINED")

        val newEnrollment = StudentEnrollment(
            studentId = cleanStudentId,
            schoolId = currentSchoolId,
            academicYear = cleanToYear,
            classId = cleanTargetClassId,
            rollNumber = finalRoll,
            status = "ACTIVE",
            promotedFromYear = cleanFromYear,
            promotedFromClassId = cleanTargetClassId,
            promotionDate = System.currentTimeMillis(),
            remarks = remarks ?: "Retained in ${targetClass.name} for $cleanToYear"
        )
        database.studentEnrollmentDao().insertEnrollment(newEnrollment)

        val currentYear = getCurrentAcademicYearCodeDirect()
        if (cleanToYear == currentYear) {
            database.studentDao().updateStudent(
                student.copy(
                    classId = cleanTargetClassId,
                    rollNumber = finalRoll
                )
            )
        }

        val school = database.schoolDao().getSchoolById(currentSchoolId)
        val curr = school?.currency ?: "₹"
        val newFee = StudentFee(
            studentId = student.id,
            schoolId = currentSchoolId,
            studentName = student.name,
            rollNumber = finalRoll,
            classId = cleanTargetClassId,
            totalFee = maxOf(0.0, newYearFee),
            totalPaid = 0.0,
            remainingFee = maxOf(0.0, newYearFee),
            status = if (newYearFee > 0.0) "UNPAID" else "PAID",
            currency = curr,
            academicYear = cleanToYear
        )
        database.feeDao().insertStudentFee(newFee)

        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
            timestamp = System.currentTimeMillis(),
            category = "PROMOTION",
            personName = student.name,
            personRole = "STUDENT",
            personId = student.id,
            classId = cleanTargetClassId,
            className = targetClass.name,
            action = "Student Retained in ${targetClass.name} ($cleanToYear)",
            details = "Retained for $cleanToYear. Roll No: $finalRoll. ${remarks ?: ""}".trim(),
            performedBy = "Principal"
        )
        database.activityRecordDao().insertActivity(activity)

        syncSchoolDataToCloud(currentSchoolId)
        Result.success(newEnrollment)
    }

    // --- Users & Multi-Device Cloud Authentication ---
    fun getAllTeachers(): Flow<List<UserAccount>> = database.userDao().getAllTeachers(currentSchoolId)
    fun getPendingTeachers(): Flow<List<UserAccount>> = database.userDao().getPendingTeachers(currentSchoolId)
    fun getApprovedTeachers(): Flow<List<UserAccount>> = database.userDao().getApprovedTeachers(currentSchoolId)

    fun getAllParents(): Flow<List<UserAccount>> = database.userDao().getAllParents(currentSchoolId)
    fun getPendingParents(): Flow<List<UserAccount>> = database.userDao().getPendingParents(currentSchoolId)
    fun getApprovedParents(): Flow<List<UserAccount>> = database.userDao().getApprovedParents(currentSchoolId)

    fun getUserByIdFlow(id: String): Flow<UserAccount?> = database.userDao().getUserByIdFlow(id)

    suspend fun getUserById(id: String): UserAccount? = withContext(Dispatchers.IO) {
        val cleanId = id.trim()
        if (cleanId.isBlank()) return@withContext null
        try {
            cloudService.findCloudUser(cleanId)?.also {
                database.userDao().insertUser(it)
            } ?: database.userDao().getUserById(cleanId)
        } catch (e: Exception) {
            database.userDao().getUserById(cleanId)
        }
    }

    suspend fun registerUser(user: UserAccount, rawPassword: String, rawSecurityAnswer: String): Result<UserAccount> = withContext(Dispatchers.IO) {
        if (cloudService.isOffline()) {
            return@withContext Result.failure(
                OfflineException("Cannot create account while offline. An active internet connection is required to create a multi-device account.")
            )
        }

        val salt = PasswordSecurity.generateSalt()
        val passwordHash = PasswordSecurity.hashPassword(rawPassword, salt)
        val answerHash = PasswordSecurity.hashSecurityAnswer(rawSecurityAnswer)

        val securedUser = user.copy(
            passwordHash = passwordHash,
            passwordSalt = salt,
            securityAnswer = answerHash
        )

        // 1. Cloud registration (ensures account is accessible on all devices)
        val cloudRes = cloudService.registerCloudUser(securedUser)
        if (cloudRes.isFailure) {
            return@withContext cloudRes
        }

        // 2. Local DB persistence
        database.userDao().insertUser(securedUser)

        // 3. Sync school bundle to cloud
        syncSchoolDataToCloud(securedUser.schoolId)

        Result.success(securedUser)
    }

    suspend fun login(id: String, password: String, expectedRole: String, inputSchoolId: String? = null): Result<UserAccount> = withContext(Dispatchers.IO) {
        val cleanId = id.trim()

        // 1. First check Cloud user registry for multi-device sync
        var user: UserAccount? = null
        try {
            user = cloudService.findCloudUser(cleanId)
            if (user != null) {
                database.userDao().insertUser(user)
            } else {
                user = database.userDao().getUserById(cleanId)
            }
        } catch (e: OfflineException) {
            user = database.userDao().getUserById(cleanId)
            if (user == null) {
                return@withContext Result.failure(
                    OfflineException("Online authentication is unavailable because this device is offline. Please check your internet connection to log in to your multi-device account.")
                )
            }
        } catch (e: Exception) {
            user = database.userDao().getUserById(cleanId)
        }

        if (user == null) {
            return@withContext Result.failure(
                Exception("Account ID '$cleanId' not found. Please verify your ID or create an account.")
            )
        }

        // 2. Strict School ID validation (if provided)
        if (!inputSchoolId.isNullOrBlank() && !user.schoolId.equals(inputSchoolId.trim(), ignoreCase = true)) {
            return@withContext Result.failure(
                Exception("Invalid School ID. This account belongs to school '${user.schoolId}'.")
            )
        }

        // 3. Cryptographic password verification
        val isPasswordCorrect = PasswordSecurity.verifyPassword(password, user.passwordSalt, user.passwordHash)
        if (!isPasswordCorrect) {
            return@withContext Result.failure(Exception("Incorrect password. Please check and try again."))
        }

        // 4. Role validation
        if (user.role != expectedRole) {
            return@withContext Result.failure(
                Exception("Unauthorized role. This account is registered as ${user.role}, not $expectedRole.")
            )
        }

        // 5. Account approval check for teachers and parents
        if (user.role == UserRole.TEACHER.name || user.role == UserRole.PARENT.name) {
            when (user.status) {
                AccountStatus.PENDING.name -> {
                    val roleLabel = if (user.role == UserRole.TEACHER.name) "Teacher" else "Parent"
                    return@withContext Result.failure(
                        Exception("Your $roleLabel account is pending Principal approval. Please wait for the Principal to approve your registration.")
                    )
                }
                AccountStatus.REJECTED.name -> {
                    val roleLabel = if (user.role == UserRole.TEACHER.name) "Teacher" else "Parent"
                    return@withContext Result.failure(
                        Exception("Your $roleLabel account registration was declined by the Principal.")
                    )
                }
            }
        }

        // Retrieve School Name
        val school = database.schoolDao().getSchoolById(user.schoolId)
            ?: cloudService.getCloudSchoolById(user.schoolId)
        val schoolName = school?.name ?: "School (${user.schoolId})"

        // Save session
        sessionManager.saveSession(
            userId = user.id,
            role = user.role,
            name = user.name,
            schoolId = user.schoolId,
            schoolName = schoolName,
            assignedClassId = user.assignedClassId,
            linkedStudentIds = user.linkedStudentIds,
            sessionVersion = user.sessionVersion
        )

        // Sync school data from cloud so this device has all latest data
        syncSchoolDataFromCloud(user.schoolId)

        Result.success(user)
    }

    suspend fun validateSession(): Boolean = withContext(Dispatchers.IO) {
        val currentSession = sessionManager.sessionState.value ?: return@withContext false
        val user = try {
            cloudService.findCloudUser(currentSession.userId) ?: database.userDao().getUserById(currentSession.userId)
        } catch (e: Exception) {
            database.userDao().getUserById(currentSession.userId)
        } ?: return@withContext false

        if (user.sessionVersion != currentSession.sessionVersion) {
            // Password changed on another device: session invalidated
            logout()
            return@withContext false
        }
        true
    }

    fun logout() {
        sessionManager.clearSession()
    }

    suspend fun updateTeacherStatus(teacherId: String, status: String) = withContext(Dispatchers.IO) {
        database.userDao().updateTeacherStatus(teacherId, status)
        cloudService.updateCloudTeacherStatus(teacherId, status)
    }

    suspend fun updateParentStatus(parentId: String, status: String) = withContext(Dispatchers.IO) {
        database.userDao().updateUserStatus(parentId, status)
        cloudService.updateCloudUserStatus(parentId, status)
    }

    suspend fun approveParentAndLinkStudents(parentId: String) = withContext(Dispatchers.IO) {
        database.userDao().updateUserStatus(parentId, AccountStatus.APPROVED.name)
        cloudService.updateCloudUserStatus(parentId, AccountStatus.APPROVED.name)

        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        if (parent != null) {
            val studentIds = parent.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            for (stuId in studentIds) {
                database.studentDao().updateStudentParentUserId(stuId, parentId)
                cloudService.linkParentStudentInCloud(parentId, stuId)
            }
        }
    }

    suspend fun rejectParent(parentId: String) = withContext(Dispatchers.IO) {
        database.userDao().updateUserStatus(parentId, AccountStatus.REJECTED.name)
        cloudService.updateCloudUserStatus(parentId, AccountStatus.REJECTED.name)

        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        if (parent != null) {
            val studentIds = parent.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            for (stuId in studentIds) {
                val student = database.studentDao().getStudentById(stuId)
                if (student?.parentUserId == parentId) {
                    database.studentDao().updateStudentParentUserId(stuId, null)
                    cloudService.unlinkParentStudentInCloud(parentId, stuId)
                }
            }
        }
    }

    suspend fun linkParentToStudent(parentId: String, studentId: String) = withContext(Dispatchers.IO) {
        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        val currentIds = parent?.linkedStudentIds?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
        currentIds.add(studentId.trim())
        val updatedIds = currentIds.joinToString(",")

        database.userDao().updateParentLinkedStudents(parentId, updatedIds)
        database.studentDao().updateStudentParentUserId(studentId, parentId)
        cloudService.linkParentStudentInCloud(parentId, studentId)
    }

    suspend fun unlinkParentFromStudent(parentId: String, studentId: String) = withContext(Dispatchers.IO) {
        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        val currentIds = parent?.linkedStudentIds?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
        currentIds.remove(studentId.trim())
        val updatedIds = currentIds.joinToString(",")

        database.userDao().updateParentLinkedStudents(parentId, updatedIds)
        database.studentDao().updateStudentParentUserId(studentId, null)
        cloudService.unlinkParentStudentInCloud(parentId, studentId)
    }

    suspend fun updateTeacherClass(teacherId: String, classId: String?) = withContext(Dispatchers.IO) {
        database.userDao().updateAssignedClass(teacherId, classId)
        val user = database.userDao().getUserById(teacherId)
        if (user != null) {
            cloudService.updateCloudUser(user.copy(assignedClassId = classId))
        }
        if (classId != null) {
            database.classDao().updateClassTeacher(classId, teacherId)
        }
    }

    suspend fun updateTeacher(teacher: UserAccount) = withContext(Dispatchers.IO) {
        database.userDao().updateUser(teacher)
        cloudService.updateCloudUser(teacher)
        if (teacher.assignedClassId != null) {
            database.classDao().updateClassTeacher(teacher.assignedClassId, teacher.id)
        }
    }

    suspend fun changePassword(
        userId: String,
        currentPassword: String,
        newPassword: String,
        confirmNewPassword: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        if (newPassword != confirmNewPassword) {
            return@withContext Result.failure(Exception("New password and confirm new password do not match."))
        }
        if (newPassword.length < 6) {
            return@withContext Result.failure(Exception("New password must be at least 6 characters."))
        }

        val user = cloudService.findCloudUser(cleanId) ?: database.userDao().getUserById(cleanId)
            ?: return@withContext Result.failure(Exception("User ID '$cleanId' not found."))

        val isCurrentPasswordCorrect = PasswordSecurity.verifyPassword(currentPassword, user.passwordSalt, user.passwordHash)
        if (!isCurrentPasswordCorrect) {
            return@withContext Result.failure(Exception("Current password is incorrect."))
        }

        if (currentPassword == newPassword) {
            return@withContext Result.failure(Exception("New password must be different from current password."))
        }

        val newSalt = PasswordSecurity.generateSalt()
        val newHash = PasswordSecurity.hashPassword(newPassword, newSalt)
        val newSessionVersion = user.sessionVersion + 1

        database.userDao().updatePasswordAndSessionVersion(user.id, newHash, newSalt, newSessionVersion)
        cloudService.updateCloudUserPassword(user.id, newHash, newSalt, newSessionVersion)

        // Keep this device logged in with the updated session version
        val currentSession = sessionManager.sessionState.value
        if (currentSession != null && currentSession.userId == user.id) {
            sessionManager.updateSessionVersion(newSessionVersion)
        }

        Result.success(Unit)
    }

    suspend fun resetPasswordWithSecurity(
        userId: String,
        securityAnswer: String,
        newPassword: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        val user = database.userDao().getUserById(cleanId) ?: cloudService.findCloudUser(cleanId)
            ?: return@withContext Result.failure(Exception("User ID '$cleanId' not found in system."))

        val isAnswerCorrect = PasswordSecurity.verifySecurityAnswer(securityAnswer, user.securityAnswer)
        if (!isAnswerCorrect) {
            return@withContext Result.failure(Exception("Security answer is incorrect."))
        }

        if (newPassword.length < 6) {
            return@withContext Result.failure(Exception("New password must be at least 6 characters."))
        }

        val newSalt = PasswordSecurity.generateSalt()
        val newHash = PasswordSecurity.hashPassword(newPassword, newSalt)
        val newSessionVersion = user.sessionVersion + 1

        database.userDao().updatePasswordAndSessionVersion(user.id, newHash, newSalt, newSessionVersion)
        cloudService.updateCloudUserPassword(user.id, newHash, newSalt, newSessionVersion)

        val currentSession = sessionManager.sessionState.value
        if (currentSession != null && currentSession.userId == user.id) {
            sessionManager.updateSessionVersion(newSessionVersion)
        }

        Result.success(Unit)
    }

    suspend fun directUpdatePassword(userId: String, newPassword: String) = withContext(Dispatchers.IO) {
        val newSalt = PasswordSecurity.generateSalt()
        val newHash = PasswordSecurity.hashPassword(newPassword, newSalt)
        val user = database.userDao().getUserById(userId) ?: cloudService.findCloudUser(userId)
        val newSessionVersion = (user?.sessionVersion ?: 1L) + 1
        database.userDao().updatePasswordAndSessionVersion(userId, newHash, newSalt, newSessionVersion)
        cloudService.updateCloudUserPassword(userId, newHash, newSalt, newSessionVersion)
        val currentSession = sessionManager.sessionState.value
        if (currentSession != null && currentSession.userId == userId) {
            sessionManager.updateSessionVersion(newSessionVersion)
        }
    }

    suspend fun deleteTeacher(teacherId: String) = withContext(Dispatchers.IO) {
        database.userDao().deleteUser(teacherId)
    }

    suspend fun deleteParent(parentId: String) = withContext(Dispatchers.IO) {
        val parent = database.userDao().getUserById(parentId) ?: cloudService.findCloudUser(parentId)
        if (parent != null) {
            val studentIds = parent.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            for (stuId in studentIds) {
                val student = database.studentDao().getStudentById(stuId)
                if (student?.parentUserId == parentId) {
                    database.studentDao().updateStudentParentUserId(stuId, null)
                    cloudService.unlinkParentStudentInCloud(parentId, stuId)
                }
            }
        }
        database.userDao().deleteUser(parentId)
    }

    suspend fun getPendingParentForStudent(studentId: String, schoolId: String): UserAccount? = withContext(Dispatchers.IO) {
        val pendingParents = database.userDao().getPendingParentsDirect(schoolId)
        pendingParents.find { parent ->
            val ids = parent.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            ids.contains(studentId)
        }
    }

    // --- Classes (School Isolated) ---
    fun getAllClasses(): Flow<List<SchoolClass>> = database.classDao().getAllClasses(currentSchoolId)
    fun getClassByIdFlow(id: String): Flow<SchoolClass?> = database.classDao().getClassByIdFlow(id)
    suspend fun getClassById(id: String): SchoolClass? = withContext(Dispatchers.IO) {
        database.classDao().getClassById(id)
    }

    suspend fun insertClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        val classWithSchool = schoolClass.copy(schoolId = currentSchoolId)
        database.classDao().insertClass(classWithSchool)
        classWithSchool.classTeacherId?.let { teacherId ->
            database.userDao().updateAssignedClass(teacherId, classWithSchool.id)
        }
    }

    suspend fun updateClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        val classWithSchool = schoolClass.copy(schoolId = currentSchoolId)
        database.classDao().updateClass(classWithSchool)
        classWithSchool.classTeacherId?.let { teacherId ->
            database.userDao().updateAssignedClass(teacherId, classWithSchool.id)
        }
    }

    suspend fun deleteClass(classId: String) = withContext(Dispatchers.IO) {
        database.classDao().deleteClass(classId)
    }

    // --- Students (School Isolated) ---
    fun getAllStudents(): Flow<List<Student>> = database.studentDao().getAllStudents(currentSchoolId)
    fun getStudentsByClass(classId: String): Flow<List<Student>> = database.studentDao().getStudentsByClass(currentSchoolId, classId)
    suspend fun getStudentsByClassDirect(classId: String): List<Student> = withContext(Dispatchers.IO) {
        database.studentDao().getStudentsByClassDirect(currentSchoolId, classId)
    }

    fun getStudentByIdFlow(id: String): Flow<Student?> = database.studentDao().getStudentByIdFlow(id)
    suspend fun getStudentById(id: String): Student? = withContext(Dispatchers.IO) {
        database.studentDao().getStudentById(id)
    }

    suspend fun getStudentByIdAndSchool(id: String, schoolId: String): Student? = withContext(Dispatchers.IO) {
        database.studentDao().getStudentByIdAndSchool(id, schoolId)
    }

    fun getStudentsByIdsFlow(ids: List<String>): Flow<List<Student>> {
        if (ids.isEmpty()) return flowOf(emptyList())
        return database.studentDao().getStudentsByIdsFlow(ids)
    }

    suspend fun getStudentsByIds(ids: List<String>): List<Student> = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) emptyList()
        else database.studentDao().getStudentsByIds(ids)
    }

    suspend fun getNextAvailableStudentId(): String = withContext(Dispatchers.IO) {
        val all = database.studentDao().getStudentsBySchoolDirect(currentSchoolId)
        var maxNum = 2003
        for (s in all) {
            val digits = s.id.substringAfter("STU_").filter { it.isDigit() }
            val num = digits.toIntOrNull()
            if (num != null && num > maxNum) {
                maxNum = num
            }
        }
        var nextNum = maxNum + 1
        var candidate = "STU_$nextNum"
        while (database.studentDao().getStudentById(candidate) != null) {
            nextNum++
            candidate = "STU_$nextNum"
        }
        candidate
    }

    suspend fun getNextAvailableRollNumber(classId: String, academicYear: String? = null): String = withContext(Dispatchers.IO) {
        val targetYear = academicYear?.trim()?.ifBlank { null } ?: getCurrentAcademicYearCodeDirect()
        val enrollments = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(currentSchoolId, classId, targetYear)
        val studentsInClass = database.studentDao().getStudentsByClassDirect(currentSchoolId, classId)
        val takenRolls = (enrollments.map { it.rollNumber } + studentsInClass.map { it.rollNumber })
            .filter { it.isNotBlank() }
            .toSet()

        var maxNumeric = 0
        for (r in takenRolls) {
            val num = r.filter { it.isDigit() }.toIntOrNull()
            if (num != null && num > maxNumeric) {
                maxNumeric = num
            }
        }
        val nextNum = if (maxNumeric > 0) maxNumeric + 1 else 1
        nextNum.toString()
    }

    suspend fun insertStudent(
        student: Student,
        academicYear: String? = null
    ): Result<Student> = withContext(Dispatchers.IO) {
        try {
            val studentWithSchool = student.copy(schoolId = currentSchoolId)
            val targetYear = academicYear?.trim()?.ifBlank { null } ?: getCurrentAcademicYearCodeDirect()

            // 0. Prevent overwriting existing student data with a different student
            val existingStudent = database.studentDao().getStudentById(studentWithSchool.id)
            if (existingStudent != null && !existingStudent.name.trim().equals(studentWithSchool.name.trim(), ignoreCase = true)) {
                return@withContext Result.failure(
                    IllegalArgumentException("Student ID '${studentWithSchool.id}' is already assigned to '${existingStudent.name}'. Please choose a unique Student ID.")
                )
            }

            // 1. Prevent duplicate enrollment in the same academic year
            val existingEnrollment = database.studentEnrollmentDao().getEnrollment(studentWithSchool.id, targetYear)
            if (existingEnrollment != null) {
                return@withContext Result.failure(
                    IllegalArgumentException("Student '${studentWithSchool.name}' (ID: ${studentWithSchool.id}) is already enrolled in academic year $targetYear.")
                )
            }

            // 2. Prevent duplicate roll number in the same class and same academic year
            val existingClassEnrollments = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(
                currentSchoolId, studentWithSchool.classId, targetYear
            )
            if (existingClassEnrollments.any {
                it.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) && 
                it.studentId != studentWithSchool.id &&
                it.status != "LEFT" && it.status != "GRADUATED" && it.status != "TRANSFERRED"
            }) {
                val conflictingId = existingClassEnrollments.first { 
                    it.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) && it.studentId != studentWithSchool.id 
                }.studentId
                val conflictingStudent = database.studentDao().getStudentById(conflictingId)
                val nameInfo = if (conflictingStudent != null) "already assigned to '${conflictingStudent.name}'" else "already assigned"
                val cls = database.classDao().getClassById(studentWithSchool.classId)
                val clsName = cls?.name ?: studentWithSchool.classId
                return@withContext Result.failure(
                    IllegalArgumentException("Roll number '${studentWithSchool.rollNumber}' is $nameInfo in $clsName ($targetYear).")
                )
            }

            val existingStudentsInClass = database.studentDao().getStudentsByClassDirect(currentSchoolId, studentWithSchool.classId)
            val activeConflictInMaster = existingStudentsInClass.firstOrNull { other ->
                other.id != studentWithSchool.id &&
                other.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) &&
                run {
                    val enroll = database.studentEnrollmentDao().getEnrollment(other.id, targetYear)
                    enroll == null || (enroll.classId == studentWithSchool.classId && enroll.status !in listOf("LEFT", "GRADUATED", "TRANSFERRED"))
                }
            }
            if (activeConflictInMaster != null) {
                val cls = database.classDao().getClassById(studentWithSchool.classId)
                val clsName = cls?.name ?: studentWithSchool.classId
                return@withContext Result.failure(
                    IllegalArgumentException("Roll number '${studentWithSchool.rollNumber}' is already assigned to '${activeConflictInMaster.name}' in $clsName.")
                )
            }

            // 3. Save master student record permanently
            database.studentDao().insertStudent(studentWithSchool)

            // 4. Save student enrollment for target academic year
            database.studentEnrollmentDao().insertEnrollment(
                StudentEnrollment(
                    studentId = studentWithSchool.id,
                    schoolId = currentSchoolId,
                    academicYear = targetYear,
                    classId = studentWithSchool.classId,
                    rollNumber = studentWithSchool.rollNumber,
                    status = "ACTIVE"
                )
            )

            // 5. Ensure default fee profile for this student in target academic year
            val existingFee = database.feeDao().getFeeForStudentAndYearDirect(studentWithSchool.id, targetYear)
            if (existingFee == null) {
                val school = database.schoolDao().getSchoolById(currentSchoolId)
                val curr = school?.currency ?: "₹"
                val defaultFee = StudentFee(
                    studentId = studentWithSchool.id,
                    schoolId = currentSchoolId,
                    studentName = studentWithSchool.name,
                    rollNumber = studentWithSchool.rollNumber,
                    classId = studentWithSchool.classId,
                    totalFee = 0.0,
                    totalPaid = 0.0,
                    remainingFee = 0.0,
                    status = "UNPAID",
                    currency = curr,
                    academicYear = targetYear
                )
                database.feeDao().insertStudentFee(defaultFee)
            }

            // 6. Log enrollment activity
            val cls = database.classDao().getClassById(studentWithSchool.classId)
            val clsName = cls?.name ?: studentWithSchool.classId
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
                timestamp = System.currentTimeMillis(),
                category = "ENROLLMENT",
                personName = studentWithSchool.name,
                personRole = "STUDENT",
                personId = studentWithSchool.id,
                classId = studentWithSchool.classId,
                className = clsName,
                action = "New Student Enrolled in $clsName ($targetYear)",
                details = "Student ID: ${studentWithSchool.id}, Roll: ${studentWithSchool.rollNumber}, Parent: ${studentWithSchool.parentName}",
                performedBy = "Principal"
            )
            database.activityRecordDao().insertActivity(activity)

            syncSchoolDataToCloud(currentSchoolId)
            Result.success(studentWithSchool)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getStudentsByYear(academicYear: String): Flow<List<Student>> =
        database.studentDao().getStudentsByYear(currentSchoolId, academicYear)

    suspend fun getStudentsByYearDirect(academicYear: String): List<Student> = withContext(Dispatchers.IO) {
        database.studentDao().getStudentsByYearDirect(currentSchoolId, academicYear)
    }

    fun getStudentsByClassAndYear(classId: String, academicYear: String): Flow<List<Student>> =
        database.studentDao().getStudentsByClassAndYear(currentSchoolId, classId, academicYear)

    suspend fun updateStudent(
        student: Student,
        academicYear: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val studentWithSchool = student.copy(schoolId = currentSchoolId)
            val targetYear = academicYear?.trim()?.ifBlank { null } ?: getCurrentAcademicYearCodeDirect()

            // Check roll number collision if changed in same class & academic year
            val existingClassEnrollments = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(
                currentSchoolId, studentWithSchool.classId, targetYear
            )
            if (existingClassEnrollments.any {
                it.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) && 
                it.studentId != studentWithSchool.id &&
                it.status != "LEFT" && it.status != "GRADUATED" && it.status != "TRANSFERRED"
            }) {
                val conflictingId = existingClassEnrollments.first { 
                    it.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) && it.studentId != studentWithSchool.id 
                }.studentId
                val conflictingStudent = database.studentDao().getStudentById(conflictingId)
                val nameInfo = if (conflictingStudent != null) "already assigned to '${conflictingStudent.name}'" else "already assigned"
                val cls = database.classDao().getClassById(studentWithSchool.classId)
                val clsName = cls?.name ?: studentWithSchool.classId
                return@withContext Result.failure(
                    IllegalArgumentException("Roll number '${studentWithSchool.rollNumber}' is $nameInfo in $clsName ($targetYear).")
                )
            }

            val existingStudentsInClass = database.studentDao().getStudentsByClassDirect(currentSchoolId, studentWithSchool.classId)
            if (existingStudentsInClass.any {
                it.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) &&
                it.id != studentWithSchool.id
            }) {
                val conflicting = existingStudentsInClass.first { 
                    it.rollNumber.trim().equals(studentWithSchool.rollNumber.trim(), ignoreCase = true) && it.id != studentWithSchool.id 
                }
                val cls = database.classDao().getClassById(studentWithSchool.classId)
                val clsName = cls?.name ?: studentWithSchool.classId
                return@withContext Result.failure(
                    IllegalArgumentException("Roll number '${studentWithSchool.rollNumber}' is already assigned to '${conflicting.name}' in $clsName.")
                )
            }

            // 1. Update master student record
            database.studentDao().updateStudent(studentWithSchool)

            // 2. Update current academic year enrollment
            val currentEnrollment = database.studentEnrollmentDao().getEnrollment(studentWithSchool.id, targetYear)
            if (currentEnrollment != null) {
                database.studentEnrollmentDao().insertEnrollment(
                    currentEnrollment.copy(
                        schoolId = currentSchoolId,
                        classId = studentWithSchool.classId,
                        rollNumber = studentWithSchool.rollNumber
                    )
                )
            } else {
                database.studentEnrollmentDao().insertEnrollment(
                    StudentEnrollment(
                        studentId = studentWithSchool.id,
                        schoolId = currentSchoolId,
                        academicYear = targetYear,
                        classId = studentWithSchool.classId,
                        rollNumber = studentWithSchool.rollNumber,
                        status = "ACTIVE"
                    )
                )
            }

            // 3. Keep fee record for target academic year in sync
            val fee = database.feeDao().getFeeForStudentAndYearDirect(studentWithSchool.id, targetYear)
            if (fee != null) {
                database.feeDao().updateStudentFee(
                    fee.copy(
                        studentName = studentWithSchool.name,
                        rollNumber = studentWithSchool.rollNumber,
                        classId = studentWithSchool.classId
                    )
                )
            }

            syncSchoolDataToCloud(currentSchoolId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun changeStudentClass(
        studentId: String,
        targetClassId: String,
        newRollNumber: String,
        academicYear: String? = null,
        reason: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val student = database.studentDao().getStudentById(studentId)
                ?: return@withContext Result.failure(IllegalArgumentException("Student not found"))

            val targetYear = academicYear?.trim()?.ifBlank { null } ?: getCurrentAcademicYearCodeDirect()
            val roll = newRollNumber.trim().ifBlank { student.rollNumber }

            val oldEnrollment = database.studentEnrollmentDao().getEnrollment(studentId, targetYear)
            val oldClassId = oldEnrollment?.classId ?: student.classId
            val oldRoll = oldEnrollment?.rollNumber ?: student.rollNumber

            // Prevent no-op change if user selected exact same class and roll number
            if (targetClassId == oldClassId && roll.equals(oldRoll, ignoreCase = true)) {
                return@withContext Result.failure(
                    IllegalArgumentException("Student is already in this class with roll number '$roll'. Please select a different class/section or enter a new roll number.")
                )
            }

            // Verify target class exists
            val targetClass = database.classDao().getClassById(targetClassId)
                ?: return@withContext Result.failure(IllegalArgumentException("Selected target class does not exist."))
            val targetClassName = targetClass.name

            // Check roll number collision in target class for this academic year
            val existingInTarget = database.studentEnrollmentDao().getEnrollmentsByClassAndYearDirect(
                currentSchoolId, targetClassId, targetYear
            )
            if (existingInTarget.any { 
                it.rollNumber.trim().equals(roll, ignoreCase = true) && 
                it.studentId != studentId &&
                it.status != "LEFT" && it.status != "GRADUATED" && it.status != "TRANSFERRED"
            }) {
                val conflictingId = existingInTarget.first { 
                    it.rollNumber.trim().equals(roll, ignoreCase = true) && it.studentId != studentId 
                }.studentId
                val conflictingStudent = database.studentDao().getStudentById(conflictingId)
                val nameInfo = if (conflictingStudent != null) "already assigned to '${conflictingStudent.name}'" else "already taken"
                return@withContext Result.failure(
                    IllegalArgumentException("Roll number '$roll' is $nameInfo in $targetClassName for academic year $targetYear.")
                )
            }

            val existingStudentsInTargetClass = database.studentDao().getStudentsByClassDirect(currentSchoolId, targetClassId)
            val activeConflictInMaster = existingStudentsInTargetClass.firstOrNull { other ->
                other.id != studentId &&
                other.rollNumber.trim().equals(roll, ignoreCase = true) &&
                run {
                    val enroll = database.studentEnrollmentDao().getEnrollment(other.id, targetYear)
                    enroll == null || (enroll.classId == targetClassId && enroll.status !in listOf("LEFT", "GRADUATED", "TRANSFERRED"))
                }
            }
            if (activeConflictInMaster != null) {
                return@withContext Result.failure(
                    IllegalArgumentException("Roll number '$roll' is already assigned to '${activeConflictInMaster.name}' in $targetClassName.")
                )
            }

            // 1. Update enrollment for this academic year (preserving old academic year records!)
            val updatedEnrollment = (oldEnrollment ?: StudentEnrollment(
                studentId = studentId,
                schoolId = currentSchoolId,
                academicYear = targetYear,
                classId = targetClassId,
                rollNumber = roll,
                status = "ACTIVE"
            )).copy(
                schoolId = currentSchoolId,
                classId = targetClassId,
                rollNumber = roll,
                status = "ACTIVE",
                remarks = reason?.ifBlank { null } ?: "Transferred from $oldClassId to $targetClassId in $targetYear"
            )
            database.studentEnrollmentDao().insertEnrollment(updatedEnrollment)

            // 2. Always update student master record with new class and roll number so all screens immediately show the new class
            database.studentDao().updateStudent(
                student.copy(
                    classId = targetClassId,
                    rollNumber = roll
                )
            )

            // 3. Update current academic year fee record class and roll
            val fee = database.feeDao().getFeeForStudentAndYearDirect(studentId, targetYear)
            if (fee != null) {
                database.feeDao().updateStudentFee(
                    fee.copy(
                        classId = targetClassId,
                        rollNumber = roll
                    )
                )
            }

            // 4. Log activity record
            val oldClassName = database.classDao().getClassById(oldClassId)?.name ?: oldClassId
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
                timestamp = System.currentTimeMillis(),
                category = "CLASS_CHANGE",
                personName = student.name,
                personRole = "STUDENT",
                personId = student.id,
                classId = targetClassId,
                className = targetClassName,
                action = "Student Class Changed to $targetClassName",
                details = "Transferred from $oldClassName to $targetClassName in academic year $targetYear. Roll No: $roll. ${reason ?: ""}".trim(),
                performedBy = "Principal"
            )
            database.activityRecordDao().insertActivity(activity)

            syncSchoolDataToCloud(currentSchoolId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateStudentEnrollmentStatus(
        studentId: String,
        academicYear: String,
        newStatus: String,
        remarks: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val enrollment = database.studentEnrollmentDao().getEnrollment(studentId, academicYear)
                ?: return@withContext Result.failure(IllegalArgumentException("Enrollment record not found for student in $academicYear"))

            database.studentEnrollmentDao().insertEnrollment(
                enrollment.copy(
                    status = newStatus,
                    remarks = remarks ?: enrollment.remarks
                )
            )

            val student = database.studentDao().getStudentById(studentId)
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()),
                timestamp = System.currentTimeMillis(),
                category = "STUDENT_STATUS",
                personName = student?.name ?: studentId,
                personRole = "STUDENT",
                personId = studentId,
                classId = enrollment.classId,
                className = enrollment.classId,
                action = "Student status updated to $newStatus ($academicYear)",
                details = remarks ?: "Status changed to $newStatus in academic year $academicYear",
                performedBy = "Principal"
            )
            database.activityRecordDao().insertActivity(activity)

            syncSchoolDataToCloud(currentSchoolId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteStudent(studentId: String) = withContext(Dispatchers.IO) {
        val student = database.studentDao().getStudentById(studentId)
        if (student?.parentUserId != null) {
            unlinkParentFromStudent(student.parentUserId, studentId)
        }
        database.studentDao().deleteStudent(studentId)
        syncSchoolDataToCloud(currentSchoolId)
    }

    // --- Attendance (School Isolated & Academic Year Aware) ---
    fun getAttendanceByClassAndDate(classId: String, date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceByClassAndDate(currentSchoolId, classId, date)

    fun getAttendanceByClassDateAndYear(classId: String, date: String, academicYear: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceByClassDateAndYear(currentSchoolId, classId, date, academicYear)

    suspend fun getAttendanceByClassAndDateDirect(classId: String, date: String): List<AttendanceRecord> =
        withContext(Dispatchers.IO) {
            database.attendanceDao().getAttendanceByClassAndDateDirect(currentSchoolId, classId, date)
        }

    fun getAllAttendanceByDate(date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAllAttendanceByDate(currentSchoolId, date)

    fun getAllAttendanceByYear(academicYear: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAllAttendanceByYear(currentSchoolId, academicYear)

    fun getAbsentStudentsByDate(date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAbsentStudentsByDate(currentSchoolId, date)

    fun getAttendanceForStudent(studentId: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceForStudent(studentId)

    fun getAttendanceForStudentAndYear(studentId: String, academicYear: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceForStudentAndYear(studentId, academicYear)

    suspend fun saveAttendance(records: List<AttendanceRecord>, academicYear: String? = null) = withContext(Dispatchers.IO) {
        val year = academicYear ?: getCurrentAcademicYearCodeDirect()
        val isolated = records.map {
            it.copy(
                schoolId = currentSchoolId,
                academicYear = if (it.academicYear.isBlank() || it.academicYear == "2026-27") year else it.academicYear
            )
        }
        database.attendanceDao().insertAttendance(isolated)
    }

    suspend fun saveSingleAttendance(record: AttendanceRecord, academicYear: String? = null) = withContext(Dispatchers.IO) {
        val year = academicYear ?: getCurrentAcademicYearCodeDirect()
        val isolated = record.copy(
            schoolId = currentSchoolId,
            academicYear = if (record.academicYear.isBlank() || record.academicYear == "2026-27") year else record.academicYear
        )
        database.attendanceDao().insertSingleAttendance(isolated)
    }

    // --- Attendance Submissions (School Isolated) ---
    fun getAllAttendanceSubmissions(): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getAllSubmissions(currentSchoolId)

    fun getAttendanceSubmissionsByDate(date: String): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getSubmissionsByDate(currentSchoolId, date)

    fun getAttendanceSubmissionsByClass(classId: String): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getSubmissionsByClass(currentSchoolId, classId)

    fun getAttendanceSubmissionByClassAndDateFlow(classId: String, date: String): Flow<AttendanceSubmissionRecord?> =
        database.attendanceSubmissionDao().getSubmissionByClassAndDateFlow(currentSchoolId, classId, date)

    suspend fun getAttendanceSubmissionByClassAndDate(classId: String, date: String): AttendanceSubmissionRecord? =
        withContext(Dispatchers.IO) {
            database.attendanceSubmissionDao().getSubmissionByClassAndDate(currentSchoolId, classId, date)
        }

    suspend fun submitAttendanceReport(
        submission: AttendanceSubmissionRecord,
        records: List<AttendanceRecord>
    ) = withContext(Dispatchers.IO) {
        val isolatedRecords = records.map { it.copy(schoolId = currentSchoolId) }
        val isolatedSubmission = submission.copy(schoolId = currentSchoolId)
        database.attendanceDao().insertAttendance(isolatedRecords)
        database.attendanceSubmissionDao().insertSubmission(isolatedSubmission)

        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = submission.date,
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = "ATTENDANCE",
            personName = submission.classTeacherName,
            personRole = "TEACHER",
            personId = submission.classTeacherId,
            classId = submission.classId,
            className = submission.className,
            action = "Daily Attendance Submitted (${submission.className})",
            amount = null,
            marks = null,
            details = "Total Students: ${submission.totalStudents} • Present: ${submission.presentStudents} • Absent: ${submission.absentStudents}. Absentees: ${submission.absentStudentNames.ifBlank { "None" }}. Notes: ${submission.absentNotes.ifBlank { "N/A" }}",
            performedBy = submission.classTeacherName
        )
        database.activityRecordDao().insertActivity(activity)
    }

    // --- Homework (School Isolated & Academic Year Aware) ---
    fun getHomeworkByClass(classId: String): Flow<List<Homework>> =
        database.homeworkDao().getHomeworkByClass(currentSchoolId, classId)

    fun getHomeworkByClassAndYear(classId: String, academicYear: String): Flow<List<Homework>> =
        database.homeworkDao().getHomeworkByClassAndYear(currentSchoolId, classId, academicYear)

    fun getAllHomework(): Flow<List<Homework>> =
        database.homeworkDao().getAllHomework(currentSchoolId)

    fun getAllHomeworkByYear(academicYear: String): Flow<List<Homework>> =
        database.homeworkDao().getAllHomeworkByYear(currentSchoolId, academicYear)

    suspend fun insertHomework(homework: Homework, academicYear: String? = null) = withContext(Dispatchers.IO) {
        val year = academicYear ?: getCurrentAcademicYearCodeDirect()
        val isolated = homework.copy(
            schoolId = currentSchoolId,
            academicYear = if (homework.academicYear.isBlank() || homework.academicYear == "2026-27") year else homework.academicYear
        )
        database.homeworkDao().insertHomework(isolated)
    }

    suspend fun deleteHomework(id: String) = withContext(Dispatchers.IO) {
        database.homeworkDao().deleteHomework(id)
    }

    // --- Tests & Result History (School Isolated & Calculated Ranks) ---
    fun getAllTests(): Flow<List<SchoolTest>> =
        database.testDao().getAllTests(currentSchoolId)

    fun getAllTestsByYear(academicYear: String): Flow<List<SchoolTest>> =
        database.testDao().getAllTestsByYear(currentSchoolId, academicYear)

    fun getTestsByClass(classId: String): Flow<List<SchoolTest>> =
        database.testDao().getTestsByClass(currentSchoolId, classId)

    fun getTestsByClassAndYear(classId: String, academicYear: String): Flow<List<SchoolTest>> =
        database.testDao().getTestsByClassAndYear(currentSchoolId, classId, academicYear)

    fun getTestByIdFlow(id: String): Flow<SchoolTest?> =
        database.testDao().getTestByIdFlow(id)

    suspend fun createTestWithMarks(
        testId: String,
        classId: String,
        className: String,
        testName: String,
        subject: String,
        date: String,
        maxMarks: Double,
        teacherId: String,
        teacherName: String,
        marksDrafts: List<Pair<Student, Pair<Double, String?>>>,
        academicYear: String? = null
    ): Result<SchoolTest> = withContext(Dispatchers.IO) {
        try {
            val safeMaxMarks = if (maxMarks <= 0.0) 100.0 else maxMarks
            val totalStudents = marksDrafts.size
            val targetYear = academicYear ?: getCurrentAcademicYearCodeDirect()

            // Sort descending by marks obtained to calculate competition rank
            val sortedList = marksDrafts.sortedByDescending { it.second.first }
            val highestScore = sortedList.firstOrNull()?.second?.first ?: 0.0
            val averageScore = if (totalStudents > 0) {
                sortedList.map { it.second.first }.average()
            } else 0.0

            val marksToInsert = sortedList.mapIndexed { index, (student, scoreAndRemark) ->
                val obtained = scoreAndRemark.first.coerceIn(0.0, safeMaxMarks)
                val remarks = scoreAndRemark.second
                val percentage = (obtained / safeMaxMarks) * 100.0

                // Rank calculation (handles ties)
                val rank = if (index > 0 && obtained == sortedList[index - 1].second.first) {
                    sortedList.indexOfFirst { it.second.first == obtained } + 1
                } else {
                    index + 1
                }

                val grade = when {
                    percentage >= 90.0 -> "A+"
                    percentage >= 80.0 -> "A"
                    percentage >= 70.0 -> "B+"
                    percentage >= 60.0 -> "B"
                    percentage >= 50.0 -> "C"
                    percentage >= 40.0 -> "D"
                    else -> "F"
                }

                StudentMark(
                    id = UUID.randomUUID().toString(),
                    testId = testId,
                    schoolId = currentSchoolId,
                    studentId = student.id,
                    studentName = student.name,
                    rollNumber = student.rollNumber,
                    classId = classId,
                    examName = testName.trim(),
                    subject = subject.trim(),
                    maxMarks = safeMaxMarks,
                    marksObtained = obtained,
                    percentage = percentage,
                    rank = rank,
                    grade = grade,
                    remarks = remarks?.trim()?.ifBlank { null },
                    date = date.trim(),
                    academicYear = targetYear
                )
            }

            val schoolTest = SchoolTest(
                id = testId,
                schoolId = currentSchoolId,
                classId = classId,
                className = className,
                testName = testName.trim(),
                subject = subject.trim(),
                date = date.trim(),
                maxMarks = safeMaxMarks,
                createdByTeacherId = teacherId,
                createdByTeacherName = teacherName,
                totalStudents = totalStudents,
                averageScore = averageScore,
                highestScore = highestScore,
                academicYear = targetYear
            )

            // Save test record and marks
            database.testDao().insertTest(schoolTest)
            database.markDao().deleteMarksByTest(testId)
            database.markDao().insertMarks(marksToInsert)

            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = date.trim(),
                time = timeStr,
                timestamp = System.currentTimeMillis(),
                category = "MARKS_TESTS",
                personName = teacherName,
                personRole = "TEACHER",
                personId = teacherId,
                classId = classId,
                className = className,
                action = "Test & Results Recorded: $testName ($subject)",
                amount = null,
                marks = "Avg: ${String.format(Locale.getDefault(), "%.1f", averageScore)}% • Top: ${String.format(Locale.getDefault(), "%.1f", highestScore)}/$safeMaxMarks",
                details = "Class: $className • Subject: $subject • $totalStudents students evaluated. Top Rank #1: ${sortedList.firstOrNull()?.first?.name ?: "N/A"}. Year: $targetYear",
                performedBy = teacherName
            )
            database.activityRecordDao().insertActivity(activity)

            Result.success(schoolTest)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTest(testId: String) = withContext(Dispatchers.IO) {
        database.markDao().deleteMarksByTest(testId)
        database.testDao().deleteTest(testId)
    }

    // --- Marks (School Isolated & Academic Year Aware) ---
    fun getMarksByClass(classId: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByClass(currentSchoolId, classId)

    fun getMarksByClassAndYear(classId: String, academicYear: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByClassAndYear(currentSchoolId, classId, academicYear)

    fun getMarksByTest(testId: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByTest(testId)

    fun getMarksByClassAndExam(classId: String, examName: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByClassAndExam(currentSchoolId, classId, examName)

    fun getMarksByStudent(studentId: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByStudent(studentId)

    fun getMarksByStudentAndYear(studentId: String, academicYear: String): Flow<List<StudentMark>> =
        database.markDao().getMarksByStudentAndYear(studentId, academicYear)

    fun getAllMarks(): Flow<List<StudentMark>> =
        database.markDao().getAllMarks(currentSchoolId)

    fun getAllMarksByYear(academicYear: String): Flow<List<StudentMark>> =
        database.markDao().getAllMarksByYear(currentSchoolId, academicYear)

    suspend fun insertMark(mark: StudentMark, academicYear: String? = null) = withContext(Dispatchers.IO) {
        val year = academicYear ?: getCurrentAcademicYearCodeDirect()
        val isolated = mark.copy(
            schoolId = currentSchoolId,
            academicYear = if (mark.academicYear.isBlank() || mark.academicYear == "2026-27") year else mark.academicYear
        )
        database.markDao().insertMark(isolated)
    }

    suspend fun insertMarks(marks: List<StudentMark>, academicYear: String? = null) = withContext(Dispatchers.IO) {
        val year = academicYear ?: getCurrentAcademicYearCodeDirect()
        val isolated = marks.map {
            it.copy(
                schoolId = currentSchoolId,
                academicYear = if (it.academicYear.isBlank() || it.academicYear == "2026-27") year else it.academicYear
            )
        }
        database.markDao().insertMarks(isolated)
    }

    suspend fun deleteMark(id: String) = withContext(Dispatchers.IO) {
        database.markDao().deleteMark(id)
    }

    // --- Fees Management (School Isolated & Academic Year Aware) ---
    fun getAllStudentFees(): Flow<List<StudentFee>> =
        database.feeDao().getAllStudentFees(currentSchoolId)

    fun getAllStudentFeesByYear(academicYear: String): Flow<List<StudentFee>> =
        database.feeDao().getAllStudentFeesByYear(currentSchoolId, academicYear)

    fun getFeesByClass(classId: String): Flow<List<StudentFee>> =
        database.feeDao().getFeesByClass(currentSchoolId, classId)

    fun getFeesByClassAndYear(classId: String, academicYear: String): Flow<List<StudentFee>> =
        database.feeDao().getFeesByClassAndYear(currentSchoolId, classId, academicYear)

    fun getFeeForStudent(studentId: String): Flow<StudentFee?> =
        database.feeDao().getFeeForStudent(studentId)

    fun getFeeForStudentAndYear(studentId: String, academicYear: String): Flow<StudentFee?> =
        database.feeDao().getFeeForStudentAndYear(studentId, academicYear)

    suspend fun setStudentTotalFee(
        student: Student,
        totalFee: Double,
        academicYear: String? = null
    ) = withContext(Dispatchers.IO) {
        val targetYear = academicYear ?: getCurrentAcademicYearCodeDirect()
        val payments = database.feePaymentDao().getPaymentsByStudentDirect(student.id)
            .filter { it.academicYear == targetYear }
        val totalPaid = payments.sumOf { it.amount }
        val safeTotalFee = maxOf(0.0, totalFee)
        val remaining = maxOf(0.0, safeTotalFee - totalPaid)
        val status = when {
            remaining <= 0.0 && totalPaid > 0.0 -> "PAID"
            totalPaid > 0.0 -> "PARTIAL"
            else -> "UNPAID"
        }
        val lastDate = payments.maxByOrNull { it.timestamp }?.date

        val studentFee = StudentFee(
            studentId = student.id,
            schoolId = currentSchoolId,
            studentName = student.name,
            rollNumber = student.rollNumber,
            classId = student.classId,
            totalFee = safeTotalFee,
            totalPaid = totalPaid,
            remainingFee = remaining,
            status = status,
            lastPaymentDate = lastDate,
            updatedAt = System.currentTimeMillis(),
            academicYear = targetYear
        )
        database.feeDao().insertStudentFee(studentFee)
    }

    suspend fun recordFeePayment(
        student: Student,
        amount: Double,
        date: String,
        paymentMode: String,
        note: String,
        recordedBy: String,
        academicYear: String? = null
    ): Result<FeePayment> = withContext(Dispatchers.IO) {
        try {
            if (amount <= 0.0) {
                return@withContext Result.failure(IllegalArgumentException("Payment amount must be greater than 0"))
            }

            val targetYear = academicYear ?: getCurrentAcademicYearCodeDirect()
            val school = database.schoolDao().getSchoolById(currentSchoolId)
            val curr = school?.currency ?: "₹"
            val receiptNo = "REC-${(100000..999999).random()}"
            val payment = FeePayment(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                studentId = student.id,
                studentName = student.name,
                rollNumber = student.rollNumber,
                classId = student.classId,
                amount = amount,
                currency = curr,
                date = date.trim(),
                paymentMode = paymentMode.trim().ifBlank { "Cash" },
                note = note.trim(),
                receiptNumber = receiptNo,
                recordedBy = recordedBy.trim().ifBlank { "School Administration" },
                timestamp = System.currentTimeMillis(),
                academicYear = targetYear
            )

            database.feePaymentDao().insertPayment(payment)

            // Recalculate fee balance for this student in this academic year
            val allPayments = database.feePaymentDao().getPaymentsByStudentDirect(student.id)
                .filter { it.academicYear == targetYear }
            val totalPaid = allPayments.sumOf { it.amount }
            val existingFee = database.feeDao().getFeeForStudentAndYearDirect(student.id, targetYear)
                ?: database.feeDao().getFeeForStudentDirect(student.id)
            val currentTotal = existingFee?.totalFee ?: 4500.0
            val remaining = maxOf(0.0, currentTotal - totalPaid)
            val status = when {
                remaining <= 0.0 -> "PAID"
                totalPaid > 0.0 -> "PARTIAL"
                else -> "UNPAID"
            }

            val updatedFee = StudentFee(
                studentId = student.id,
                schoolId = currentSchoolId,
                studentName = student.name,
                rollNumber = student.rollNumber,
                classId = student.classId,
                totalFee = currentTotal,
                totalPaid = totalPaid,
                remainingFee = remaining,
                currency = curr,
                status = status,
                lastPaymentDate = date.trim(),
                updatedAt = System.currentTimeMillis(),
                academicYear = targetYear
            )
            database.feeDao().insertStudentFee(updatedFee)

            // Log activity in school history
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = date.trim(),
                time = timeStr,
                timestamp = System.currentTimeMillis(),
                category = "FEE_PAYMENT",
                personName = student.name,
                personRole = "STUDENT",
                personId = student.id,
                classId = student.classId,
                className = "",
                action = "Fee Payment Collected ($receiptNo)",
                amount = amount,
                marks = null,
                details = "Received $curr${String.format(Locale.getDefault(), "%.2f", amount)} via $paymentMode. Receipt: $receiptNo. Remaining: $curr${String.format(Locale.getDefault(), "%.2f", remaining)}. Status: $status. Note: $note",
                performedBy = payment.recordedBy
            )
            database.activityRecordDao().insertActivity(activity)

            Result.success(payment)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getPaymentsByStudent(studentId: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getPaymentsByStudent(studentId)

    fun getPaymentsByStudentAndYear(studentId: String, academicYear: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getPaymentsByStudentAndYear(studentId, academicYear)

    fun getPaymentsByClass(classId: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getPaymentsByClass(currentSchoolId, classId)

    fun getPaymentsByClassAndYear(classId: String, academicYear: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getPaymentsByClassAndYear(currentSchoolId, classId, academicYear)

    fun getAllPayments(): Flow<List<FeePayment>> =
        database.feePaymentDao().getAllPayments(currentSchoolId)

    fun getAllPaymentsByYear(academicYear: String): Flow<List<FeePayment>> =
        database.feePaymentDao().getAllPaymentsByYear(currentSchoolId, academicYear)

    suspend fun deleteFeePayment(paymentId: String, studentId: String) = withContext(Dispatchers.IO) {
        database.feePaymentDao().deletePayment(paymentId)
        val allPayments = database.feePaymentDao().getPaymentsByStudentDirect(studentId)
        val totalPaid = allPayments.sumOf { it.amount }
        val existingFee = database.feeDao().getFeeForStudentDirect(studentId)
        if (existingFee != null) {
            val remaining = maxOf(0.0, existingFee.totalFee - totalPaid)
            val status = when {
                remaining <= 0.0 && totalPaid > 0.0 -> "PAID"
                totalPaid > 0.0 -> "PARTIAL"
                else -> "UNPAID"
            }
            database.feeDao().updateStudentFee(
                existingFee.copy(
                    totalPaid = totalPaid,
                    remainingFee = remaining,
                    status = status,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    // --- Teacher Salaries (School Isolated & Role Protected) ---
    fun getAllSalaries(): Flow<List<TeacherSalary>> =
        database.teacherSalaryDao().getAllSalaries(currentSchoolId)

    fun getSalariesForTeacher(teacherId: String): Flow<List<TeacherSalary>> =
        database.teacherSalaryDao().getSalariesForTeacher(currentSchoolId, teacherId)

    fun getSalariesByMonth(month: String): Flow<List<TeacherSalary>> =
        database.teacherSalaryDao().getSalariesByMonth(currentSchoolId, month)

    suspend fun recordTeacherSalary(
        teacherId: String,
        teacherName: String,
        month: String,
        monthlySalary: Double,
        amountPaid: Double,
        paymentDate: String,
        remainingAmount: Double,
        paymentMode: String,
        transactionRef: String,
        remarks: String,
        recordedBy: String
    ): Result<TeacherSalary> = withContext(Dispatchers.IO) {
        try {
            if (monthlySalary < 0.0 || amountPaid < 0.0) {
                return@withContext Result.failure(IllegalArgumentException("Salary amounts cannot be negative"))
            }
            val safeRemaining = if (remainingAmount >= 0.0) remainingAmount else maxOf(0.0, monthlySalary - amountPaid)
            val status = when {
                safeRemaining <= 0.0 && amountPaid > 0.0 -> "PAID"
                amountPaid > 0.0 -> "PARTIAL"
                else -> "PENDING"
            }

            val school = database.schoolDao().getSchoolById(currentSchoolId)
            val curr = school?.currency ?: "₹"

            val salary = TeacherSalary(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                teacherId = teacherId,
                teacherName = teacherName,
                month = month.trim(),
                monthlySalary = monthlySalary,
                amountPaid = amountPaid,
                paymentDate = paymentDate.trim(),
                remainingAmount = safeRemaining,
                currency = curr,
                paymentMode = paymentMode.trim().ifBlank { "Bank Transfer" },
                transactionRef = transactionRef.trim(),
                remarks = remarks.trim(),
                status = status,
                recordedBy = recordedBy.trim().ifBlank { "Principal" },
                timestamp = System.currentTimeMillis()
            )

            database.teacherSalaryDao().insertSalary(salary)

            // Log activity in school history
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            val activity = ActivityRecord(
                id = UUID.randomUUID().toString(),
                schoolId = currentSchoolId,
                date = paymentDate.trim(),
                time = timeStr,
                timestamp = System.currentTimeMillis(),
                category = "SALARY_PAYMENT",
                personName = teacherName,
                personRole = "TEACHER",
                personId = teacherId,
                classId = "",
                className = "",
                action = "Teacher Salary Disbursed ($month)",
                amount = amountPaid,
                marks = null,
                details = "Monthly Salary: $curr${String.format(Locale.getDefault(), "%.2f", monthlySalary)} • Amount Paid: $curr${String.format(Locale.getDefault(), "%.2f", amountPaid)} • Remaining: $curr${String.format(Locale.getDefault(), "%.2f", safeRemaining)} • Mode: $paymentMode • Ref: $transactionRef • Remarks: $remarks",
                performedBy = salary.recordedBy
            )
            database.activityRecordDao().insertActivity(activity)

            Result.success(salary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTeacherSalary(id: String) = withContext(Dispatchers.IO) {
        database.teacherSalaryDao().deleteSalary(id)
    }

    // --- School Activity & Operations History ---
    fun getAllActivities(): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getAllActivities(currentSchoolId)

    fun getActivitiesByCategory(category: String): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getActivitiesByCategory(currentSchoolId, category)

    fun getActivitiesByClass(classId: String): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getActivitiesByClass(currentSchoolId, classId)

    fun getActivitiesByPerson(personId: String): Flow<List<ActivityRecord>> =
        database.activityRecordDao().getActivitiesByPerson(currentSchoolId, personId)

    suspend fun logActivity(activity: ActivityRecord) = withContext(Dispatchers.IO) {
        database.activityRecordDao().insertActivity(activity.copy(schoolId = currentSchoolId))
    }

    suspend fun deleteActivity(id: String) = withContext(Dispatchers.IO) {
        database.activityRecordDao().deleteActivity(id)
    }

    // --- Announcements (School Isolated & Secure Audience Targeting) ---
    fun getAnnouncementsForClass(classId: String): Flow<List<Announcement>> =
        database.announcementDao().getAllAnnouncements(currentSchoolId).map { list ->
            list.filter { it.isEligibleForParent(classId) }
        }

    fun getAnnouncementsForParent(studentClassId: String?): Flow<List<Announcement>> =
        database.announcementDao().getAllAnnouncements(currentSchoolId).map { list ->
            list.filter { it.isEligibleForParent(studentClassId) }
        }

    fun getAnnouncementsForParentClasses(parentClassIds: Set<String>): Flow<List<Announcement>> =
        database.announcementDao().getAllAnnouncements(currentSchoolId).map { list ->
            list.filter { ann ->
                if (ann.targetAudience.equals(AnnouncementTarget.ALL_TEACHERS, ignoreCase = true)) {
                    false
                } else if (ann.targetAudience.equals(AnnouncementTarget.ALL_SCHOOL, ignoreCase = true) ||
                    ann.targetAudience.equals("ALL_SCHOOL", ignoreCase = true) ||
                    ann.targetAudience.equals(AnnouncementTarget.ALL_PARENTS, ignoreCase = true) ||
                    ann.targetAudience.equals(AnnouncementTarget.ALL_CLASSES, ignoreCase = true)
                ) {
                    true
                } else {
                    val targeted = ann.getTargetedClassIds()
                    parentClassIds.any { targeted.contains(it) }
                }
            }
        }

    fun getAnnouncementsForTeacher(teacherAssignedClassId: String?): Flow<List<Announcement>> =
        database.announcementDao().getAllAnnouncements(currentSchoolId).map { list ->
            list.filter { it.isEligibleForTeacher(teacherAssignedClassId) }
        }

    fun getAllAnnouncements(): Flow<List<Announcement>> =
        database.announcementDao().getAllAnnouncements(currentSchoolId)

    suspend fun insertAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        val isolatedAnnouncement = announcement.copy(schoolId = currentSchoolId)
        database.announcementDao().insertAnnouncement(isolatedAnnouncement)

        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val audienceLabel = isolatedAnnouncement.getAudienceDisplayLabel()
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = isolatedAnnouncement.date.ifBlank { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) },
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = "ANNOUNCEMENT",
            personName = isolatedAnnouncement.authorName,
            personRole = "PRINCIPAL",
            personId = "",
            classId = isolatedAnnouncement.targetAudience,
            className = audienceLabel,
            action = "Notice Broadcasted: ${isolatedAnnouncement.title}",
            amount = null,
            marks = null,
            details = "Priority: ${isolatedAnnouncement.priority} • Target: $audienceLabel • Content: ${isolatedAnnouncement.content}",
            performedBy = isolatedAnnouncement.authorName
        )
        database.activityRecordDao().insertActivity(activity)
        syncSchoolDataToCloud(currentSchoolId)
    }

    suspend fun deleteAnnouncement(id: String) = withContext(Dispatchers.IO) {
        database.announcementDao().deleteAnnouncement(id)
        syncSchoolDataToCloud(currentSchoolId)
    }

    // --- Leaves (School Isolated) ---
    fun getAllLeaveRequests(): Flow<List<LeaveRequest>> =
        database.leaveDao().getAllLeaveRequests(currentSchoolId)

    fun getLeaveRequestsByTeacher(teacherId: String): Flow<List<LeaveRequest>> =
        database.leaveDao().getLeaveRequestsByTeacher(teacherId)

    fun getPendingLeaveRequests(): Flow<List<LeaveRequest>> =
        database.leaveDao().getPendingLeaveRequests(currentSchoolId)

    suspend fun insertLeaveRequest(request: LeaveRequest) = withContext(Dispatchers.IO) {
        database.leaveDao().insertLeaveRequest(request.copy(schoolId = currentSchoolId))
    }

    suspend fun updateLeaveStatus(id: String, status: String, comment: String?) = withContext(Dispatchers.IO) {
        database.leaveDao().updateLeaveStatus(id, status, comment)

        val req = database.leaveDao().getLeaveRequestById(id)
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = currentSchoolId,
            date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = "LEAVE_REQUEST",
            personName = req?.teacherName ?: "Teacher",
            personRole = "TEACHER",
            personId = req?.teacherId ?: "",
            classId = "",
            className = "",
            action = "Leave Request $status",
            amount = null,
            marks = null,
            details = "Leave Type: ${req?.leaveType ?: "Leave"} • Duration: ${req?.daysCount ?: 1} day(s) (${req?.startDate} to ${req?.endDate}). Reason: ${req?.reason}. Remark: ${comment ?: "No remarks"}",
            performedBy = "Principal"
        )
        database.activityRecordDao().insertActivity(activity)
    }

    suspend fun deleteLeaveRequest(id: String) = withContext(Dispatchers.IO) {
        database.leaveDao().deleteLeaveRequest(id)
    }

    // --- Chat Messages (School & Student Isolated, Cloud Synchronized) ---
    fun getMessagesForStudent(studentId: String): Flow<List<ChatMessage>> =
        database.chatMessageDao().getMessagesForStudent(currentSchoolId, studentId)

    fun getMessagesForUser(userId: String): Flow<List<ChatMessage>> =
        database.chatMessageDao().getMessagesForUser(currentSchoolId, userId)

    fun getAllMessagesForSchool(): Flow<List<ChatMessage>> =
        database.chatMessageDao().getAllMessagesForSchool(currentSchoolId)

    suspend fun sendMessage(message: ChatMessage): Result<ChatMessage> = withContext(Dispatchers.IO) {
        val isolatedMessage = message.copy(schoolId = currentSchoolId)

        // 1. Sync to cloud database
        val cloudRes = cloudService.sendCloudMessage(isolatedMessage)

        // 2. Persist to local database
        database.chatMessageDao().insertMessage(isolatedMessage)
        Result.success(isolatedMessage)
    }

    suspend fun syncMessagesFromCloud(studentId: String) = withContext(Dispatchers.IO) {
        val cloudMsgs = cloudService.getCloudMessages(currentSchoolId, studentId)
        if (cloudMsgs.isNotEmpty()) {
            database.chatMessageDao().insertMessages(cloudMsgs)
        }
    }

    suspend fun syncSchoolDataToCloud(schoolId: String = currentSchoolId) = withContext(Dispatchers.IO) {
        try {
            val school = database.schoolDao().getSchoolById(schoolId) ?: cloudService.getCloudSchoolById(schoolId)
            val users = database.userDao().getAllUsersDirect(schoolId)
            val classes = database.classDao().getClassesBySchoolDirect(schoolId)
            val students = database.studentDao().getStudentsBySchoolDirect(schoolId)
            val announcements = database.announcementDao().getAnnouncementsBySchoolDirect(schoolId)
            val homework = database.homeworkDao().getHomeworkBySchoolDirect(schoolId)
            val tests = database.testDao().getTestsBySchoolDirect(schoolId)
            val marks = database.markDao().getMarksBySchoolDirect(schoolId)
            val attendance = database.attendanceDao().getAllAttendanceDirect(schoolId)
            val attendanceSubmissions = database.attendanceSubmissionDao().getAllSubmissionsDirect(schoolId)
            val fees = database.feeDao().getAllStudentFeesDirect(schoolId)
            val feePayments = database.feePaymentDao().getAllPaymentsDirect(schoolId)
            val salaries = database.teacherSalaryDao().getAllSalariesDirect(schoolId)
            val leaveRequests = database.leaveDao().getAllLeaveRequestsDirect(schoolId)
            val activityRecords = database.activityRecordDao().getAllActivitiesDirect(schoolId)
            val messages = database.chatMessageDao().getAllMessagesDirect(schoolId)
            val academicYears = database.academicYearDao().getAllAcademicYearsDirect(schoolId)
            val enrollments = database.studentEnrollmentDao().getAllEnrollmentsDirect(schoolId)

            val bundle = SchoolDataBundle(
                schoolId = schoolId,
                lastUpdated = System.currentTimeMillis(),
                school = school,
                users = users,
                classes = classes,
                students = students,
                announcements = announcements,
                homework = homework,
                tests = tests,
                marks = marks,
                attendance = attendance,
                attendanceSubmissions = attendanceSubmissions,
                fees = fees,
                feePayments = feePayments,
                salaries = salaries,
                leaveRequests = leaveRequests,
                activityRecords = activityRecords,
                messages = messages,
                academicYears = academicYears,
                enrollments = enrollments
            )
            cloudService.syncSchoolDataToCloud(schoolId, bundle)
        } catch (e: Exception) {
            // Non-blocking catch
        }
    }

    suspend fun syncSchoolDataFromCloud(schoolId: String) = withContext(Dispatchers.IO) {
        try {
            val bundle = cloudService.fetchSchoolDataFromCloud(schoolId) ?: return@withContext
            bundle.school?.let { database.schoolDao().insertSchool(it) }
            if (bundle.users.isNotEmpty()) database.userDao().insertUsers(bundle.users)
            if (bundle.classes.isNotEmpty()) database.classDao().insertClasses(bundle.classes)
            if (bundle.students.isNotEmpty()) database.studentDao().insertStudents(bundle.students)
            if (bundle.announcements.isNotEmpty()) database.announcementDao().insertAnnouncements(bundle.announcements)
            if (bundle.homework.isNotEmpty()) database.homeworkDao().insertHomeworkList(bundle.homework)
            if (bundle.tests.isNotEmpty()) database.testDao().insertTests(bundle.tests)
            if (bundle.marks.isNotEmpty()) database.markDao().insertMarks(bundle.marks)
            if (bundle.attendance.isNotEmpty()) database.attendanceDao().insertAttendance(bundle.attendance)
            if (bundle.attendanceSubmissions.isNotEmpty()) database.attendanceSubmissionDao().insertSubmissions(bundle.attendanceSubmissions)
            if (bundle.fees.isNotEmpty()) database.feeDao().insertStudentFees(bundle.fees)
            if (bundle.feePayments.isNotEmpty()) database.feePaymentDao().insertPayments(bundle.feePayments)
            if (bundle.salaries.isNotEmpty()) database.teacherSalaryDao().insertSalaries(bundle.salaries)
            if (bundle.leaveRequests.isNotEmpty()) database.leaveDao().insertLeaveRequests(bundle.leaveRequests)
            if (bundle.activityRecords.isNotEmpty()) database.activityRecordDao().insertActivities(bundle.activityRecords)
            if (bundle.messages.isNotEmpty()) database.chatMessageDao().insertMessages(bundle.messages)
            if (bundle.academicYears.isNotEmpty()) database.academicYearDao().insertAcademicYears(bundle.academicYears)
            if (bundle.enrollments.isNotEmpty()) database.studentEnrollmentDao().insertEnrollments(bundle.enrollments)
        } catch (e: Exception) {
            // Non-blocking catch
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: SchoolRepository? = null

        fun getInstance(context: Context): SchoolRepository {
            return INSTANCE ?: synchronized(this) {
                val db = AppDatabase.getDatabase(context)
                val session = SessionManager.getInstance(context)
                val cloud = CloudDatabaseService.getInstance(context)
                INSTANCE ?: SchoolRepository(db, session, cloud).also { INSTANCE = it }
            }
        }
    }
}
