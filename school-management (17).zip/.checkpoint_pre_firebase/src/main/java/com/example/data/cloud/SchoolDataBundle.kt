package com.example.data.cloud

import com.example.data.model.*
import org.json.JSONArray
import org.json.JSONObject

data class SchoolDataBundle(
    val schoolId: String,
    val lastUpdated: Long = System.currentTimeMillis(),
    val school: School? = null,
    val users: List<UserAccount> = emptyList(),
    val classes: List<SchoolClass> = emptyList(),
    val students: List<Student> = emptyList(),
    val announcements: List<Announcement> = emptyList(),
    val homework: List<Homework> = emptyList(),
    val tests: List<SchoolTest> = emptyList(),
    val marks: List<StudentMark> = emptyList(),
    val attendance: List<AttendanceRecord> = emptyList(),
    val attendanceSubmissions: List<AttendanceSubmissionRecord> = emptyList(),
    val fees: List<StudentFee> = emptyList(),
    val feePayments: List<FeePayment> = emptyList(),
    val salaries: List<TeacherSalary> = emptyList(),
    val leaveRequests: List<LeaveRequest> = emptyList(),
    val activityRecords: List<ActivityRecord> = emptyList(),
    val messages: List<ChatMessage> = emptyList(),
    val academicYears: List<AcademicYear> = emptyList(),
    val enrollments: List<StudentEnrollment> = emptyList()
) {
    fun toJson(): JSONObject {
        val root = JSONObject()
        root.put("schoolId", schoolId)
        root.put("lastUpdated", lastUpdated)

        school?.let { s ->
            val sObj = JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("code", s.code)
                put("address", s.address)
                put("principalId", s.principalId)
                put("contactEmail", s.contactEmail)
                put("contactPhone", s.contactPhone)
                put("currency", s.currency)
                put("currencyCode", s.currencyCode)
                put("createdAt", s.createdAt)
            }
            root.put("school", sObj)
        }

        // Users
        val uArr = JSONArray()
        users.forEach { u ->
            val o = JSONObject().apply {
                put("id", u.id)
                put("schoolId", u.schoolId)
                put("name", u.name)
                put("email", u.email)
                put("phone", u.phone)
                put("role", u.role)
                put("passwordHash", u.passwordHash)
                put("passwordSalt", u.passwordSalt)
                put("securityQuestion", u.securityQuestion)
                put("securityAnswer", u.securityAnswer)
                put("status", u.status)
                if (u.assignedClassId != null) put("assignedClassId", u.assignedClassId)
                put("linkedStudentIds", u.linkedStudentIds)
                if (u.subject != null) put("subject", u.subject)
                if (u.joiningDate != null) put("joiningDate", u.joiningDate)
                if (u.monthlySalary != null) put("monthlySalary", u.monthlySalary)
                put("createdAt", u.createdAt)
            }
            uArr.put(o)
        }
        root.put("users", uArr)

        // Classes
        val cArr = JSONArray()
        classes.forEach { c ->
            val o = JSONObject().apply {
                put("id", c.id)
                put("schoolId", c.schoolId)
                put("name", c.name)
                put("grade", c.grade)
                put("section", c.section)
                if (c.classTeacherId != null) put("classTeacherId", c.classTeacherId)
                put("roomNumber", c.roomNumber)
            }
            cArr.put(o)
        }
        root.put("classes", cArr)

        // Students
        val stArr = JSONArray()
        students.forEach { st ->
            val o = JSONObject().apply {
                put("id", st.id)
                put("schoolId", st.schoolId)
                put("rollNumber", st.rollNumber)
                put("name", st.name)
                put("classId", st.classId)
                put("gender", st.gender)
                put("parentName", st.parentName)
                put("parentPhone", st.parentPhone)
                if (st.parentUserId != null) put("parentUserId", st.parentUserId)
                put("emergencyContact", st.emergencyContact)
                put("address", st.address)
            }
            stArr.put(o)
        }
        root.put("students", stArr)

        // Announcements
        val aArr = JSONArray()
        announcements.forEach { a ->
            val o = JSONObject().apply {
                put("id", a.id)
                put("schoolId", a.schoolId)
                put("title", a.title)
                put("content", a.content)
                put("targetAudience", a.targetAudience)
                put("priority", a.priority)
                put("authorName", a.authorName)
                put("date", a.date)
                put("timestamp", a.timestamp)
            }
            aArr.put(o)
        }
        root.put("announcements", aArr)

        // Homework
        val hwArr = JSONArray()
        homework.forEach { hw ->
            val o = JSONObject().apply {
                put("id", hw.id)
                put("schoolId", hw.schoolId)
                put("classId", hw.classId)
                put("teacherId", hw.teacherId)
                put("teacherName", hw.teacherName)
                put("subject", hw.subject)
                put("title", hw.title)
                put("description", hw.description)
                put("assignedDate", hw.assignedDate)
                put("dueDate", hw.dueDate)
                put("status", hw.status)
            }
            hwArr.put(o)
        }
        root.put("homework", hwArr)

        // Tests
        val tArr = JSONArray()
        tests.forEach { t ->
            val o = JSONObject().apply {
                put("id", t.id)
                put("schoolId", t.schoolId)
                put("classId", t.classId)
                put("className", t.className)
                put("testName", t.testName)
                put("subject", t.subject)
                put("date", t.date)
                put("maxMarks", t.maxMarks)
                put("createdByTeacherId", t.createdByTeacherId)
                put("createdByTeacherName", t.createdByTeacherName)
                put("totalStudents", t.totalStudents)
                put("averageScore", t.averageScore)
                put("highestScore", t.highestScore)
                put("timestamp", t.timestamp)
            }
            tArr.put(o)
        }
        root.put("tests", tArr)

        // Marks
        val mArr = JSONArray()
        marks.forEach { m ->
            val o = JSONObject().apply {
                put("id", m.id)
                put("testId", m.testId)
                put("schoolId", m.schoolId)
                put("studentId", m.studentId)
                put("studentName", m.studentName)
                put("rollNumber", m.rollNumber)
                put("classId", m.classId)
                put("examName", m.examName)
                put("subject", m.subject)
                put("maxMarks", m.maxMarks)
                put("marksObtained", m.marksObtained)
                put("percentage", m.percentage)
                put("rank", m.rank)
                put("grade", m.grade)
                if (m.remarks != null) put("remarks", m.remarks)
                put("date", m.date)
                put("timestamp", m.timestamp)
            }
            mArr.put(o)
        }
        root.put("marks", mArr)

        // Attendance
        val attArr = JSONArray()
        attendance.forEach { at ->
            val o = JSONObject().apply {
                put("id", at.id)
                put("schoolId", at.schoolId)
                put("date", at.date)
                put("studentId", at.studentId)
                put("studentName", at.studentName)
                put("rollNumber", at.rollNumber)
                put("classId", at.classId)
                put("status", at.status)
                put("markedByTeacherId", at.markedByTeacherId)
                if (at.remarks != null) put("remarks", at.remarks)
                put("isSubmitted", at.isSubmitted)
                put("timestamp", at.timestamp)
            }
            attArr.put(o)
        }
        root.put("attendance", attArr)

        // Attendance Submissions
        val subArr = JSONArray()
        attendanceSubmissions.forEach { sub ->
            val o = JSONObject().apply {
                put("id", sub.id)
                put("schoolId", sub.schoolId)
                put("date", sub.date)
                put("classId", sub.classId)
                put("className", sub.className)
                put("classTeacherId", sub.classTeacherId)
                put("classTeacherName", sub.classTeacherName)
                put("totalStudents", sub.totalStudents)
                put("presentStudents", sub.presentStudents)
                put("absentStudents", sub.absentStudents)
                put("absentStudentNames", sub.absentStudentNames)
                put("absentNotes", sub.absentNotes)
                put("submittedStatus", sub.submittedStatus)
                put("submittedAt", sub.submittedAt)
            }
            subArr.put(o)
        }
        root.put("attendanceSubmissions", subArr)

        // Fees
        val feeArr = JSONArray()
        fees.forEach { f ->
            val o = JSONObject().apply {
                put("studentId", f.studentId)
                put("schoolId", f.schoolId)
                put("studentName", f.studentName)
                put("rollNumber", f.rollNumber)
                put("classId", f.classId)
                put("totalFee", f.totalFee)
                put("totalPaid", f.totalPaid)
                put("remainingFee", f.remainingFee)
                put("status", f.status)
                if (f.lastPaymentDate != null) put("lastPaymentDate", f.lastPaymentDate)
                put("currency", f.currency)
                put("updatedAt", f.updatedAt)
            }
            feeArr.put(o)
        }
        root.put("fees", feeArr)

        // Fee Payments
        val payArr = JSONArray()
        feePayments.forEach { p ->
            val o = JSONObject().apply {
                put("id", p.id)
                put("schoolId", p.schoolId)
                put("studentId", p.studentId)
                put("studentName", p.studentName)
                put("rollNumber", p.rollNumber)
                put("classId", p.classId)
                put("amount", p.amount)
                put("date", p.date)
                put("paymentMode", p.paymentMode)
                put("note", p.note)
                put("receiptNumber", p.receiptNumber)
                put("recordedBy", p.recordedBy)
                put("currency", p.currency)
                put("timestamp", p.timestamp)
            }
            payArr.put(o)
        }
        root.put("feePayments", payArr)

        // Salaries
        val salArr = JSONArray()
        salaries.forEach { sal ->
            val o = JSONObject().apply {
                put("id", sal.id)
                put("schoolId", sal.schoolId)
                put("teacherId", sal.teacherId)
                put("teacherName", sal.teacherName)
                put("month", sal.month)
                put("monthlySalary", sal.monthlySalary)
                put("amountPaid", sal.amountPaid)
                put("paymentDate", sal.paymentDate)
                put("remainingAmount", sal.remainingAmount)
                put("currency", sal.currency)
                put("paymentMode", sal.paymentMode)
                put("transactionRef", sal.transactionRef)
                put("remarks", sal.remarks)
                put("status", sal.status)
                put("recordedBy", sal.recordedBy)
                put("timestamp", sal.timestamp)
            }
            salArr.put(o)
        }
        root.put("salaries", salArr)

        // Leave Requests
        val lrArr = JSONArray()
        leaveRequests.forEach { lr ->
            val o = JSONObject().apply {
                put("id", lr.id)
                put("schoolId", lr.schoolId)
                put("teacherId", lr.teacherId)
                put("teacherName", lr.teacherName)
                put("leaveType", lr.leaveType)
                put("startDate", lr.startDate)
                put("endDate", lr.endDate)
                put("daysCount", lr.daysCount)
                put("reason", lr.reason)
                put("status", lr.status)
                if (lr.principalComment != null) put("principalComment", lr.principalComment)
                put("appliedAt", lr.appliedAt)
            }
            lrArr.put(o)
        }
        root.put("leaveRequests", lrArr)

        // Activity Records
        val actArr = JSONArray()
        activityRecords.forEach { ar ->
            val o = JSONObject().apply {
                put("id", ar.id)
                put("schoolId", ar.schoolId)
                put("date", ar.date)
                put("time", ar.time)
                put("timestamp", ar.timestamp)
                put("category", ar.category)
                put("personName", ar.personName)
                put("personRole", ar.personRole)
                put("personId", ar.personId)
                put("classId", ar.classId)
                put("className", ar.className)
                put("action", ar.action)
                if (ar.amount != null) put("amount", ar.amount)
                if (ar.marks != null) put("marks", ar.marks)
                put("details", ar.details)
                put("performedBy", ar.performedBy)
            }
            actArr.put(o)
        }
        root.put("activityRecords", actArr)

        // Messages
        val msgArr = JSONArray()
        messages.forEach { m ->
            val o = JSONObject().apply {
                put("id", m.id)
                put("schoolId", m.schoolId)
                put("studentId", m.studentId)
                put("studentName", m.studentName)
                put("senderId", m.senderId)
                put("senderName", m.senderName)
                put("senderRole", m.senderRole)
                put("receiverId", m.receiverId)
                put("receiverName", m.receiverName)
                put("receiverRole", m.receiverRole)
                put("message", m.message)
                put("timestamp", m.timestamp)
                put("status", m.status)
            }
            msgArr.put(o)
        }
        root.put("messages", msgArr)

        // Academic Years
        val ayArr = JSONArray()
        academicYears.forEach { ay ->
            val o = JSONObject().apply {
                put("schoolId", ay.schoolId)
                put("yearCode", ay.yearCode)
                put("displayName", ay.displayName)
                put("isCurrent", ay.isCurrent)
                put("startDate", ay.startDate)
                put("endDate", ay.endDate)
                put("status", ay.status)
                put("createdAt", ay.createdAt)
            }
            ayArr.put(o)
        }
        root.put("academicYears", ayArr)

        // Student Enrollments
        val enrArr = JSONArray()
        enrollments.forEach { e ->
            val o = JSONObject().apply {
                put("studentId", e.studentId)
                put("schoolId", e.schoolId)
                put("academicYear", e.academicYear)
                put("classId", e.classId)
                put("rollNumber", e.rollNumber)
                put("status", e.status)
                if (e.promotedFromYear != null) put("promotedFromYear", e.promotedFromYear)
                if (e.promotedFromClassId != null) put("promotedFromClassId", e.promotedFromClassId)
                if (e.promotionDate != null) put("promotionDate", e.promotionDate)
                if (e.remarks != null) put("remarks", e.remarks)
                put("createdAt", e.createdAt)
            }
            enrArr.put(o)
        }
        root.put("enrollments", enrArr)

        return root
    }

    companion object {
        fun fromJson(json: JSONObject): SchoolDataBundle {
            val sId = json.optString("schoolId", "")
            val lastUp = json.optLong("lastUpdated", System.currentTimeMillis())

            val school = if (json.has("school") && !json.isNull("school")) {
                val s = json.getJSONObject("school")
                School(
                    id = s.getString("id"),
                    name = s.getString("name"),
                    code = s.optString("code", ""),
                    address = s.optString("address", ""),
                    principalId = s.optString("principalId", "PRIN001"),
                    contactEmail = s.optString("contactEmail", ""),
                    contactPhone = s.optString("contactPhone", ""),
                    currency = s.optString("currency", "₹"),
                    currencyCode = s.optString("currencyCode", "INR"),
                    createdAt = s.optLong("createdAt", System.currentTimeMillis())
                )
            } else null

            val usersList = mutableListOf<UserAccount>()
            val uArr = json.optJSONArray("users") ?: JSONArray()
            for (i in 0 until uArr.length()) {
                val o = uArr.getJSONObject(i)
                usersList.add(
                    UserAccount(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        name = o.getString("name"),
                        email = o.optString("email", ""),
                        phone = o.optString("phone", ""),
                        role = o.getString("role"),
                        passwordHash = o.getString("passwordHash"),
                        passwordSalt = o.optString("passwordSalt", ""),
                        securityQuestion = o.optString("securityQuestion", "First school?"),
                        securityAnswer = o.optString("securityAnswer", ""),
                        status = o.optString("status", AccountStatus.APPROVED.name),
                        assignedClassId = if (o.has("assignedClassId") && !o.isNull("assignedClassId")) o.getString("assignedClassId") else null,
                        linkedStudentIds = o.optString("linkedStudentIds", ""),
                        subject = if (o.has("subject") && !o.isNull("subject")) o.getString("subject") else null,
                        joiningDate = if (o.has("joiningDate") && !o.isNull("joiningDate")) o.getString("joiningDate") else null,
                        monthlySalary = if (o.has("monthlySalary") && !o.isNull("monthlySalary")) o.optDouble("monthlySalary") else null,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            val classesList = mutableListOf<SchoolClass>()
            val cArr = json.optJSONArray("classes") ?: JSONArray()
            for (i in 0 until cArr.length()) {
                val o = cArr.getJSONObject(i)
                classesList.add(
                    SchoolClass(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        name = o.getString("name"),
                        grade = o.getString("grade"),
                        section = o.getString("section"),
                        classTeacherId = if (o.has("classTeacherId") && !o.isNull("classTeacherId")) o.getString("classTeacherId") else null,
                        roomNumber = o.optString("roomNumber", "Room 101")
                    )
                )
            }

            val studentsList = mutableListOf<Student>()
            val stArr = json.optJSONArray("students") ?: JSONArray()
            for (i in 0 until stArr.length()) {
                val o = stArr.getJSONObject(i)
                studentsList.add(
                    Student(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        rollNumber = o.getString("rollNumber"),
                        name = o.getString("name"),
                        classId = o.getString("classId"),
                        gender = o.optString("gender", "Male"),
                        parentName = o.optString("parentName", ""),
                        parentPhone = o.optString("parentPhone", ""),
                        parentUserId = if (o.has("parentUserId") && !o.isNull("parentUserId")) o.getString("parentUserId") else null,
                        emergencyContact = o.optString("emergencyContact", ""),
                        address = o.optString("address", "")
                    )
                )
            }

            val announcementsList = mutableListOf<Announcement>()
            val aArr = json.optJSONArray("announcements") ?: JSONArray()
            for (i in 0 until aArr.length()) {
                val o = aArr.getJSONObject(i)
                announcementsList.add(
                    Announcement(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        title = o.getString("title"),
                        content = o.getString("content"),
                        targetAudience = o.optString("targetAudience", AnnouncementTarget.ALL_SCHOOL),
                        priority = o.optString("priority", AnnouncementPriority.NORMAL.name),
                        authorName = o.optString("authorName", "Principal"),
                        date = o.optString("date", ""),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            val homeworkList = mutableListOf<Homework>()
            val hwArr = json.optJSONArray("homework") ?: JSONArray()
            for (i in 0 until hwArr.length()) {
                val o = hwArr.getJSONObject(i)
                homeworkList.add(
                    Homework(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        classId = o.getString("classId"),
                        teacherId = o.getString("teacherId"),
                        teacherName = o.getString("teacherName"),
                        subject = o.getString("subject"),
                        title = o.getString("title"),
                        description = o.getString("description"),
                        assignedDate = o.getString("assignedDate"),
                        dueDate = o.getString("dueDate"),
                        status = o.optString("status", "ACTIVE")
                    )
                )
            }

            val testsList = mutableListOf<SchoolTest>()
            val tArr = json.optJSONArray("tests") ?: JSONArray()
            for (i in 0 until tArr.length()) {
                val o = tArr.getJSONObject(i)
                testsList.add(
                    SchoolTest(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        classId = o.getString("classId"),
                        className = o.optString("className", ""),
                        testName = o.getString("testName"),
                        subject = o.getString("subject"),
                        date = o.getString("date"),
                        maxMarks = o.optDouble("maxMarks", 100.0),
                        createdByTeacherId = o.optString("createdByTeacherId", ""),
                        createdByTeacherName = o.optString("createdByTeacherName", ""),
                        totalStudents = o.optInt("totalStudents", 0),
                        averageScore = o.optDouble("averageScore", 0.0),
                        highestScore = o.optDouble("highestScore", 0.0),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            val marksList = mutableListOf<StudentMark>()
            val mArr = json.optJSONArray("marks") ?: JSONArray()
            for (i in 0 until mArr.length()) {
                val o = mArr.getJSONObject(i)
                marksList.add(
                    StudentMark(
                        id = o.getString("id"),
                        testId = o.optString("testId", ""),
                        schoolId = o.optString("schoolId", sId),
                        studentId = o.getString("studentId"),
                        studentName = o.getString("studentName"),
                        rollNumber = o.getString("rollNumber"),
                        classId = o.getString("classId"),
                        examName = o.getString("examName"),
                        subject = o.getString("subject"),
                        maxMarks = o.optDouble("maxMarks", 100.0),
                        marksObtained = o.optDouble("marksObtained", 0.0),
                        percentage = o.optDouble("percentage", 0.0),
                        rank = o.optInt("rank", 1),
                        grade = o.optString("grade", "A"),
                        remarks = if (o.has("remarks") && !o.isNull("remarks")) o.getString("remarks") else null,
                        date = o.optString("date", ""),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            val attendanceList = mutableListOf<AttendanceRecord>()
            val attArr = json.optJSONArray("attendance") ?: JSONArray()
            for (i in 0 until attArr.length()) {
                val o = attArr.getJSONObject(i)
                attendanceList.add(
                    AttendanceRecord(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        date = o.getString("date"),
                        studentId = o.getString("studentId"),
                        studentName = o.getString("studentName"),
                        rollNumber = o.getString("rollNumber"),
                        classId = o.getString("classId"),
                        status = o.getString("status"),
                        markedByTeacherId = o.optString("markedByTeacherId", ""),
                        remarks = if (o.has("remarks") && !o.isNull("remarks")) o.getString("remarks") else null,
                        isSubmitted = o.optBoolean("isSubmitted", true),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            val subList = mutableListOf<AttendanceSubmissionRecord>()
            val subArr = json.optJSONArray("attendanceSubmissions") ?: JSONArray()
            for (i in 0 until subArr.length()) {
                val o = subArr.getJSONObject(i)
                subList.add(
                    AttendanceSubmissionRecord(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        date = o.getString("date"),
                        classId = o.getString("classId"),
                        className = o.getString("className"),
                        classTeacherId = o.getString("classTeacherId"),
                        classTeacherName = o.getString("classTeacherName"),
                        totalStudents = o.optInt("totalStudents", 0),
                        presentStudents = o.optInt("presentStudents", 0),
                        absentStudents = o.optInt("absentStudents", 0),
                        absentStudentNames = o.optString("absentStudentNames", "None"),
                        absentNotes = o.optString("absentNotes", "No notes"),
                        submittedStatus = o.optString("submittedStatus", "SUBMITTED"),
                        submittedAt = o.optLong("submittedAt", System.currentTimeMillis())
                    )
                )
            }

            val feesList = mutableListOf<StudentFee>()
            val feeArr = json.optJSONArray("fees") ?: JSONArray()
            for (i in 0 until feeArr.length()) {
                val o = feeArr.getJSONObject(i)
                feesList.add(
                    StudentFee(
                        studentId = o.getString("studentId"),
                        schoolId = o.optString("schoolId", sId),
                        studentName = o.getString("studentName"),
                        rollNumber = o.getString("rollNumber"),
                        classId = o.getString("classId"),
                        totalFee = o.optDouble("totalFee", 0.0),
                        totalPaid = o.optDouble("totalPaid", 0.0),
                        remainingFee = o.optDouble("remainingFee", 0.0),
                        status = o.optString("status", "UNPAID"),
                        lastPaymentDate = if (o.has("lastPaymentDate") && !o.isNull("lastPaymentDate")) o.getString("lastPaymentDate") else null,
                        currency = o.optString("currency", "₹"),
                        updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }

            val paymentsList = mutableListOf<FeePayment>()
            val payArr = json.optJSONArray("feePayments") ?: JSONArray()
            for (i in 0 until payArr.length()) {
                val o = payArr.getJSONObject(i)
                paymentsList.add(
                    FeePayment(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        studentId = o.getString("studentId"),
                        studentName = o.getString("studentName"),
                        rollNumber = o.getString("rollNumber"),
                        classId = o.getString("classId"),
                        amount = o.optDouble("amount", 0.0),
                        date = o.getString("date"),
                        paymentMode = o.optString("paymentMode", "Cash"),
                        note = o.optString("note", ""),
                        receiptNumber = o.optString("receiptNumber", ""),
                        recordedBy = o.optString("recordedBy", "Principal"),
                        currency = o.optString("currency", "₹"),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            val salariesList = mutableListOf<TeacherSalary>()
            val salArr = json.optJSONArray("salaries") ?: JSONArray()
            for (i in 0 until salArr.length()) {
                val o = salArr.getJSONObject(i)
                salariesList.add(
                    TeacherSalary(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        teacherId = o.getString("teacherId"),
                        teacherName = o.getString("teacherName"),
                        month = o.getString("month"),
                        monthlySalary = o.optDouble("monthlySalary", 0.0),
                        amountPaid = o.optDouble("amountPaid", 0.0),
                        paymentDate = o.getString("paymentDate"),
                        remainingAmount = o.optDouble("remainingAmount", 0.0),
                        currency = o.optString("currency", "₹"),
                        paymentMode = o.optString("paymentMode", "Bank Transfer"),
                        transactionRef = o.optString("transactionRef", ""),
                        remarks = o.optString("remarks", ""),
                        status = o.optString("status", "PAID"),
                        recordedBy = o.optString("recordedBy", "Principal"),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }

            val leaveRequestsList = mutableListOf<LeaveRequest>()
            val lrArr = json.optJSONArray("leaveRequests") ?: JSONArray()
            for (i in 0 until lrArr.length()) {
                val o = lrArr.getJSONObject(i)
                leaveRequestsList.add(
                    LeaveRequest(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        teacherId = o.getString("teacherId"),
                        teacherName = o.getString("teacherName"),
                        leaveType = o.getString("leaveType"),
                        startDate = o.getString("startDate"),
                        endDate = o.getString("endDate"),
                        daysCount = o.optInt("daysCount", 1),
                        reason = o.getString("reason"),
                        status = o.optString("status", LeaveStatus.PENDING.name),
                        principalComment = if (o.has("principalComment") && !o.isNull("principalComment")) o.getString("principalComment") else null,
                        appliedAt = o.optLong("appliedAt", System.currentTimeMillis())
                    )
                )
            }

            val activityList = mutableListOf<ActivityRecord>()
            val actArr = json.optJSONArray("activityRecords") ?: JSONArray()
            for (i in 0 until actArr.length()) {
                val o = actArr.getJSONObject(i)
                activityList.add(
                    ActivityRecord(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        date = o.getString("date"),
                        time = o.getString("time"),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                        category = o.getString("category"),
                        personName = o.getString("personName"),
                        personRole = o.optString("personRole", "STUDENT"),
                        personId = o.optString("personId", ""),
                        classId = o.optString("classId", ""),
                        className = o.optString("className", ""),
                        action = o.getString("action"),
                        amount = if (o.has("amount") && !o.isNull("amount")) o.optDouble("amount") else null,
                        marks = if (o.has("marks") && !o.isNull("marks")) o.getString("marks") else null,
                        details = o.optString("details", ""),
                        performedBy = o.optString("performedBy", "Principal")
                    )
                )
            }

            val messagesList = mutableListOf<ChatMessage>()
            val msgArr = json.optJSONArray("messages") ?: JSONArray()
            for (i in 0 until msgArr.length()) {
                val o = msgArr.getJSONObject(i)
                messagesList.add(
                    ChatMessage(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", sId),
                        studentId = o.getString("studentId"),
                        studentName = o.optString("studentName", ""),
                        senderId = o.getString("senderId"),
                        senderName = o.optString("senderName", ""),
                        senderRole = o.optString("senderRole", "TEACHER"),
                        receiverId = o.getString("receiverId"),
                        receiverName = o.optString("receiverName", ""),
                        receiverRole = o.optString("receiverRole", "PARENT"),
                        message = o.getString("message"),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                        status = o.optString("status", "SENT")
                    )
                )
            }

            val academicYearsList = mutableListOf<AcademicYear>()
            val ayArr = json.optJSONArray("academicYears") ?: JSONArray()
            for (i in 0 until ayArr.length()) {
                val o = ayArr.getJSONObject(i)
                academicYearsList.add(
                    AcademicYear(
                        schoolId = o.optString("schoolId", sId),
                        yearCode = o.getString("yearCode"),
                        displayName = o.optString("displayName", "Academic Year " + o.getString("yearCode")),
                        isCurrent = o.optBoolean("isCurrent", false),
                        startDate = o.optString("startDate", ""),
                        endDate = o.optString("endDate", ""),
                        status = o.optString("status", "ACTIVE"),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            val enrollmentsList = mutableListOf<StudentEnrollment>()
            val enrArr = json.optJSONArray("enrollments") ?: JSONArray()
            for (i in 0 until enrArr.length()) {
                val o = enrArr.getJSONObject(i)
                enrollmentsList.add(
                    StudentEnrollment(
                        studentId = o.getString("studentId"),
                        schoolId = o.optString("schoolId", sId),
                        academicYear = o.getString("academicYear"),
                        classId = o.getString("classId"),
                        rollNumber = o.getString("rollNumber"),
                        status = o.optString("status", "ACTIVE"),
                        promotedFromYear = if (o.has("promotedFromYear") && !o.isNull("promotedFromYear")) o.getString("promotedFromYear") else null,
                        promotedFromClassId = if (o.has("promotedFromClassId") && !o.isNull("promotedFromClassId")) o.getString("promotedFromClassId") else null,
                        promotionDate = if (o.has("promotionDate") && !o.isNull("promotionDate")) o.optLong("promotionDate") else null,
                        remarks = if (o.has("remarks") && !o.isNull("remarks")) o.getString("remarks") else null,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }

            return SchoolDataBundle(
                schoolId = sId,
                lastUpdated = lastUp,
                school = school,
                users = usersList,
                classes = classesList,
                students = studentsList,
                announcements = announcementsList,
                homework = homeworkList,
                tests = testsList,
                marks = marksList,
                attendance = attendanceList,
                attendanceSubmissions = subList,
                fees = feesList,
                feePayments = paymentsList,
                salaries = salariesList,
                leaveRequests = leaveRequestsList,
                activityRecords = activityList,
                messages = messagesList,
                academicYears = academicYearsList,
                enrollments = enrollmentsList
            )
        }
    }
}
