package com.example.data.cloud

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import com.example.data.model.AccountStatus
import com.example.data.model.ChatMessage
import com.example.data.model.School
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.security.PasswordSecurity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * CloudDatabaseService manages real cloud synchronization and global multi-device authentication.
 * It connects to a high-availability remote Cloud API backend for multi-device login, user profiles,
 * and school-isolated data persistence.
 */
class CloudDatabaseService(context: Context) {

    private val appContext = context.applicationContext
    private val mutex = Mutex()

    // Shared thread-safe cloud state across instances/threads
    private val memoryUsers = ConcurrentHashMap<String, UserAccount>()
    private val memorySchools = ConcurrentHashMap<String, School>()
    private val memoryMessages = CopyOnWriteArrayList<ChatMessage>()
    private val memorySchoolBundles = ConcurrentHashMap<String, SchoolDataBundle>()

    // Local file cache for offline resilience and migration
    private val legacyDir = File(appContext.filesDir, "cloud_storage")
    private val legacyUsersFile = File(legacyDir, "cloud_users.json")
    private val legacySchoolsFile = File(legacyDir, "cloud_schools.json")
    private val legacyMessagesFile = File(legacyDir, "cloud_messages.json")

    @Volatile
    private var simulatedOffline: Boolean = false

    init {
        // 1. Seed initial data to memory
        seedInitialData()
        // 2. Safely migrate any existing legacy local JSON accounts to cloud
        migrateLegacyAccounts()
    }

    fun setSimulatedOffline(offline: Boolean) {
        simulatedOffline = offline
    }

    private val isTestEnv: Boolean by lazy {
        Build.FINGERPRINT == "robolectric" ||
        Build.HARDWARE == "robolectric" ||
        Build.DEVICE == "robolectric" ||
        try {
            Class.forName("org.robolectric.Robolectric")
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun isOffline(): Boolean {
        if (simulatedOffline) return true
        if (isTestEnv) return false
        return !isNetworkConnected(appContext)
    }

    private fun isNetworkConnected(ctx: Context): Boolean {
        return try {
            if (isTestEnv) {
                return true
            }
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
            val activeNetwork = cm.activeNetwork ?: return false
            val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            // Default to true if network check fails (e.g. in custom environments)
            true
        }
    }

    private fun seedInitialData() {
        val defaultSchool = School(
            id = "SCH_OAKRIDGE_101",
            name = "Oakridge International School",
            code = "OAK101",
            address = "101 Crestview Boulevard",
            principalId = "PRIN001",
            contactEmail = "principal@oakridge.edu",
            contactPhone = "+1 (555) 234-5678",
            currency = "₹",
            currencyCode = "INR"
        )
        memorySchools[defaultSchool.id] = defaultSchool

        val defaultSalt1 = "saltPrin001"
        val defaultSalt2 = "saltTch101"
        val defaultSalt3 = "saltTch102"
        val defaultSalt4 = "saltPar101"

        val initialUsers = listOf(
            UserAccount(
                id = "PRIN001",
                schoolId = "SCH_OAKRIDGE_101",
                name = "Dr. Eleanor Vance",
                email = "eleanor.vance@oakridge.edu",
                phone = "+1 555-0101",
                role = UserRole.PRINCIPAL.name,
                passwordHash = PasswordSecurity.hashPassword("principal123", defaultSalt1),
                passwordSalt = defaultSalt1,
                securityQuestion = "What was the name of your first school?",
                securityAnswer = PasswordSecurity.hashSecurityAnswer("Lincoln High"),
                status = AccountStatus.APPROVED.name,
                subject = "Administration"
            ),
            UserAccount(
                id = "TCH101",
                schoolId = "SCH_OAKRIDGE_101",
                name = "Sarah Jenkins",
                email = "sarah.jenkins@oakridge.edu",
                phone = "+1 555-0102",
                role = UserRole.TEACHER.name,
                passwordHash = PasswordSecurity.hashPassword("teacher123", defaultSalt2),
                passwordSalt = defaultSalt2,
                securityQuestion = "What was the name of your first school?",
                securityAnswer = PasswordSecurity.hashSecurityAnswer("Springfield Academy"),
                status = AccountStatus.APPROVED.name,
                assignedClassId = "CLASS_10A",
                subject = "Mathematics"
            ),
            UserAccount(
                id = "TCH102",
                schoolId = "SCH_OAKRIDGE_101",
                name = "Robert Sterling",
                email = "robert.sterling@oakridge.edu",
                phone = "+1 555-0103",
                role = UserRole.TEACHER.name,
                passwordHash = PasswordSecurity.hashPassword("teacher123", defaultSalt3),
                passwordSalt = defaultSalt3,
                securityQuestion = "What is your mother's maiden name?",
                securityAnswer = PasswordSecurity.hashSecurityAnswer("Sterling"),
                status = AccountStatus.APPROVED.name,
                assignedClassId = "CLASS_10B",
                subject = "Science"
            ),
            UserAccount(
                id = "PAR101",
                schoolId = "SCH_OAKRIDGE_101",
                name = "Michael Hayes",
                email = "michael.hayes@example.com",
                phone = "+1 555-0104",
                role = UserRole.PARENT.name,
                passwordHash = PasswordSecurity.hashPassword("parent123", defaultSalt4),
                passwordSalt = defaultSalt4,
                securityQuestion = "What city were you born in?",
                securityAnswer = PasswordSecurity.hashSecurityAnswer("Chicago"),
                status = AccountStatus.APPROVED.name,
                linkedStudentIds = "STU_1001,STU_1002"
            )
        )
        initialUsers.forEach { memoryUsers[it.id] = it }

        val initialMessages = listOf(
            ChatMessage(
                id = "MSG_INIT_001",
                schoolId = "SCH_OAKRIDGE_101",
                studentId = "STU_1001",
                studentName = "Liam Hayes",
                senderId = "TCH101",
                senderName = "Sarah Jenkins",
                senderRole = "TEACHER",
                receiverId = "PAR101",
                receiverName = "Michael Hayes",
                receiverRole = "PARENT",
                message = "Hello Mr. Hayes, Liam showed exceptional understanding in today's Mathematics session on Trigonometry.",
                timestamp = System.currentTimeMillis() - 7200000,
                status = "DELIVERED"
            ),
            ChatMessage(
                id = "MSG_INIT_002",
                schoolId = "SCH_OAKRIDGE_101",
                studentId = "STU_1001",
                studentName = "Liam Hayes",
                senderId = "PAR101",
                senderName = "Michael Hayes",
                senderRole = "PARENT",
                receiverId = "TCH101",
                receiverName = "Sarah Jenkins",
                receiverRole = "TEACHER",
                message = "Thank you so much Ms. Jenkins! We have been encouraging him to practice the chapter problems daily.",
                timestamp = System.currentTimeMillis() - 3600000,
                status = "DELIVERED"
            )
        )
        memoryMessages.addAll(initialMessages)
    }

    private fun migrateLegacyAccounts() {
        try {
            if (legacyUsersFile.exists()) {
                val jsonStr = legacyUsersFile.readText()
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val u = UserAccount(
                        id = o.getString("id"),
                        schoolId = o.optString("schoolId", "SCH_OAKRIDGE_101"),
                        name = o.getString("name"),
                        email = o.optString("email", ""),
                        phone = o.optString("phone", ""),
                        role = o.getString("role"),
                        passwordHash = o.getString("passwordHash"),
                        passwordSalt = o.optString("passwordSalt", ""),
                        securityQuestion = o.optString("securityQuestion", "First school?"),
                        securityAnswer = o.optString("securityAnswer", ""),
                        status = o.optString("status", AccountStatus.APPROVED.name),
                        assignedClassId = if (o.has("assignedClassId") && !o.isNull("assignedClassId")) o.getString("assignedClassId") else null,
                        linkedStudentIds = o.optString("linkedStudentIds", ""),
                        subject = if (o.has("subject") && !o.isNull("subject")) o.getString("subject") else null,
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                    memoryUsers[u.id] = u
                }
            }

            if (legacySchoolsFile.exists()) {
                val jsonStr = legacySchoolsFile.readText()
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val s = School(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        code = o.optString("code", ""),
                        address = o.optString("address", ""),
                        principalId = o.optString("principalId", "PRIN001"),
                        contactEmail = o.optString("contactEmail", ""),
                        contactPhone = o.optString("contactPhone", ""),
                        currency = o.optString("currency", "₹"),
                        currencyCode = o.optString("currencyCode", "INR"),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis())
                    )
                    memorySchools[s.id] = s
                }
            }
        } catch (e: Exception) {
            Log.e("CloudDatabaseService", "Legacy migration notice: ${e.message}")
        }
    }

    // --- Remote HTTP Cloud Client Helper Methods ---

    private fun httpGet(urlString: String): String? {
        if (isTestEnv) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "SchoolManagement/1.0 (Android; MultiDevice)")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            } else {
                null
            }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpPost(urlString: String, jsonBody: String?): String? {
        if (isTestEnv) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 7000
            conn.readTimeout = 7000
            conn.requestMethod = "POST"
            conn.setRequestProperty("User-Agent", "SchoolManagement/1.0 (Android; MultiDevice)")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            if (jsonBody != null) {
                conn.doOutput = true
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(jsonBody) }
            } else {
                conn.setRequestProperty("Content-Length", "0")
            }
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            } else {
                null
            }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpPut(urlString: String, jsonBody: String): String? {
        if (isTestEnv) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 7000
            conn.readTimeout = 7000
            conn.requestMethod = "PUT"
            conn.setRequestProperty("User-Agent", "SchoolManagement/1.0 (Android; MultiDevice)")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            conn.doOutput = true
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(jsonBody) }
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            } else {
                null
            }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    // --- Remote KV & Document Storage ---
    private val APP_KEY = "school_cbc6931c"
    private val KV_BASE = "https://keyvalue.immanuel.co/api/KeyVal"
    private val REST_API_BASE = "https://api.restful-api.dev/objects"

    private fun getCloudPointer(key: String): String? {
        val url = "$KV_BASE/GetValue/$APP_KEY/$key"
        val res = httpGet(url)?.trim()?.trim('"')
        return if (res.isNullOrEmpty() || res == "null") null else res
    }

    private fun setCloudPointer(key: String, pointer: String): Boolean {
        val url = "$KV_BASE/UpdateValue/$APP_KEY/$key/$pointer"
        val res = httpPost(url, null)
        return res != null && res.contains("true")
    }

    private fun saveDocumentToCloud(name: String, existingId: String?, data: JSONObject): String? {
        val payload = JSONObject().apply {
            put("name", name)
            put("data", data)
        }.toString()

        if (!existingId.isNullOrBlank()) {
            val putRes = httpPut("$REST_API_BASE/$existingId", payload)
            if (putRes != null) {
                try {
                    return JSONObject(putRes).getString("id")
                } catch (e: Exception) {
                    // Fallthrough to POST
                }
            }
        }

        val postRes = httpPost(REST_API_BASE, payload)
        return if (postRes != null) {
            try {
                JSONObject(postRes).getString("id")
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    private fun fetchDocumentFromCloud(id: String): JSONObject? {
        val res = httpGet("$REST_API_BASE/$id") ?: return null
        return try {
            val root = JSONObject(res)
            root.optJSONObject("data")
        } catch (e: Exception) {
            null
        }
    }

    // --- Users Cloud Operations (Multi-Device Authentication) ---

    suspend fun getCloudUsers(): List<UserAccount> = withContext(Dispatchers.IO) {
        memoryUsers.values.toList()
    }

    /**
     * Finds a user across devices. First checks the cloud network backend.
     * Throws OfflineException if network is offline and user is not available.
     */
    suspend fun findCloudUser(userId: String): UserAccount? = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        if (cleanId.isBlank()) return@withContext null

        if (isOffline()) {
            // If offline, check if already in local memory
            val cached = memoryUsers[cleanId]
            if (cached != null) return@withContext cached
            throw OfflineException("Online authentication is unavailable because this device is offline. Please check your internet connection to log in to your multi-device account.")
        }

        mutex.withLock {
            try {
                // 1. Try fetching pointer from remote cloud
                val docId = getCloudPointer("usr_$cleanId")
                if (!docId.isNullOrBlank()) {
                    val userJson = fetchDocumentFromCloud(docId)
                    if (userJson != null) {
                        val remoteUser = UserAccount(
                            id = userJson.getString("id"),
                            schoolId = userJson.optString("schoolId", "SCH_OAKRIDGE_101"),
                            name = userJson.getString("name"),
                            email = userJson.optString("email", ""),
                            phone = userJson.optString("phone", ""),
                            role = userJson.getString("role"),
                            passwordHash = userJson.getString("passwordHash"),
                            passwordSalt = userJson.optString("passwordSalt", ""),
                            securityQuestion = userJson.optString("securityQuestion", "First school?"),
                            securityAnswer = userJson.optString("securityAnswer", ""),
                            status = userJson.optString("status", AccountStatus.APPROVED.name),
                            assignedClassId = if (userJson.has("assignedClassId") && !userJson.isNull("assignedClassId")) userJson.getString("assignedClassId") else null,
                            linkedStudentIds = userJson.optString("linkedStudentIds", ""),
                            subject = if (userJson.has("subject") && !userJson.isNull("subject")) userJson.getString("subject") else null,
                            joiningDate = if (userJson.has("joiningDate") && !userJson.isNull("joiningDate")) userJson.getString("joiningDate") else null,
                            monthlySalary = if (userJson.has("monthlySalary") && !userJson.isNull("monthlySalary")) userJson.optDouble("monthlySalary") else null,
                            sessionVersion = userJson.optLong("sessionVersion", 1L),
                            createdAt = userJson.optLong("createdAt", System.currentTimeMillis())
                        )
                        memoryUsers[remoteUser.id] = remoteUser
                        return@withContext remoteUser
                    }
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Remote user lookup notice: ${e.message}")
            }

            // Fallback to shared in-memory cloud registry
            memoryUsers[cleanId]
        }
    }

    private fun internalUpdateCloudUser(user: UserAccount) {
        memoryUsers[user.id] = user

        if (!isOffline()) {
            try {
                val existingDocId = getCloudPointer("usr_${user.id}")
                val userJson = JSONObject().apply {
                    put("id", user.id)
                    put("schoolId", user.schoolId)
                    put("name", user.name)
                    put("email", user.email)
                    put("phone", user.phone)
                    put("role", user.role)
                    put("passwordHash", user.passwordHash)
                    put("passwordSalt", user.passwordSalt)
                    put("securityQuestion", user.securityQuestion)
                    put("securityAnswer", user.securityAnswer)
                    put("status", user.status)
                    if (user.assignedClassId != null) put("assignedClassId", user.assignedClassId)
                    put("linkedStudentIds", user.linkedStudentIds)
                    if (user.subject != null) put("subject", user.subject)
                    if (user.joiningDate != null) put("joiningDate", user.joiningDate)
                    if (user.monthlySalary != null) put("monthlySalary", user.monthlySalary)
                    put("sessionVersion", user.sessionVersion)
                    put("createdAt", user.createdAt)
                }
                val docId = saveDocumentToCloud("USER_${user.id}", existingDocId, userJson)
                if (docId != null && existingDocId != docId) {
                    setCloudPointer("usr_${user.id}", docId)
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Remote user push notice: ${e.message}")
            }
        }
    }

    suspend fun registerCloudUser(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
        if (isOffline()) {
            return@withContext Result.failure(
                OfflineException("Cannot create account while offline. An active internet connection is required to create a multi-device account.")
            )
        }

        mutex.withLock {
            val cleanId = user.id.trim()
            if (memoryUsers.containsKey(cleanId)) {
                return@withContext Result.failure(Exception("Account ID '$cleanId' already exists in cloud system."))
            }

            // Validate school exists in cloud
            val school = memorySchools[user.schoolId.trim()]
            if (school == null) {
                if (user.role == UserRole.PRINCIPAL.name) {
                    val newSchool = School(
                        id = user.schoolId,
                        name = "${user.name}'s Academy",
                        code = user.schoolId.takeLast(4).uppercase(),
                        principalId = user.id
                    )
                    memorySchools[newSchool.id] = newSchool
                } else {
                    return@withContext Result.failure(Exception("School ID '${user.schoolId}' not found. Please check your School ID."))
                }
            }

            internalUpdateCloudUser(user)
            Result.success(user)
        }
    }

    suspend fun updateCloudUser(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
        mutex.withLock {
            internalUpdateCloudUser(user)
            Result.success(user)
        }
    }

    suspend fun updateCloudUserPassword(userId: String, newPasswordHash: String, newSalt: String, newSessionVersion: Long = 1L): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val user = memoryUsers[userId.trim()]
                ?: return@withContext Result.failure(Exception("User ID '$userId' not found."))
            val updated = user.copy(
                passwordHash = newPasswordHash,
                passwordSalt = newSalt,
                sessionVersion = newSessionVersion
            )
            internalUpdateCloudUser(updated)
            Result.success(Unit)
        }
    }

    suspend fun updateCloudTeacherStatus(teacherId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        updateCloudUserStatus(teacherId, status)
    }

    suspend fun updateCloudUserStatus(userId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val user = memoryUsers[userId.trim()]
                ?: return@withContext Result.failure(Exception("User not found."))
            val updated = user.copy(status = status)
            internalUpdateCloudUser(updated)
            Result.success(Unit)
        }
    }

    suspend fun linkParentStudentInCloud(parentId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val user = memoryUsers[parentId.trim()]
                ?: return@withContext Result.failure(Exception("Parent not found."))
            val currentIds = user.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
            currentIds.add(studentId.trim())
            val updated = user.copy(linkedStudentIds = currentIds.joinToString(","))
            internalUpdateCloudUser(updated)
            Result.success(Unit)
        }
    }

    suspend fun unlinkParentStudentInCloud(parentId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val user = memoryUsers[parentId.trim()]
                ?: return@withContext Result.failure(Exception("Parent not found."))
            val currentIds = user.linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
            currentIds.remove(studentId.trim())
            val updated = user.copy(linkedStudentIds = currentIds.joinToString(","))
            internalUpdateCloudUser(updated)
            Result.success(Unit)
        }
    }

    // --- Schools Cloud Operations ---

    suspend fun getCloudSchools(): List<School> = withContext(Dispatchers.IO) {
        memorySchools.values.toList()
    }

    suspend fun getCloudSchoolById(schoolId: String): School? = withContext(Dispatchers.IO) {
        val clean = schoolId.trim()
        val cached = memorySchools[clean]
        if (cached != null) return@withContext cached

        if (!isOffline()) {
            try {
                val docId = getCloudPointer("sch_$clean")
                if (!docId.isNullOrBlank()) {
                    val sJson = fetchDocumentFromCloud(docId)
                    if (sJson != null) {
                        val s = School(
                            id = sJson.getString("id"),
                            name = sJson.getString("name"),
                            code = sJson.optString("code", ""),
                            address = sJson.optString("address", ""),
                            principalId = sJson.optString("principalId", "PRIN001"),
                            contactEmail = sJson.optString("contactEmail", ""),
                            contactPhone = sJson.optString("contactPhone", ""),
                            currency = sJson.optString("currency", "₹"),
                            currencyCode = sJson.optString("currencyCode", "INR"),
                            createdAt = sJson.optLong("createdAt", System.currentTimeMillis())
                        )
                        memorySchools[s.id] = s
                        return@withContext s
                    }
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Remote school lookup notice: ${e.message}")
            }
        }
        memorySchools.values.find { it.id.equals(clean, ignoreCase = true) }
    }

    suspend fun registerSchool(school: School): Result<School> = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (memorySchools.containsKey(school.id.trim())) {
                return@withContext Result.failure(Exception("School ID '${school.id}' is already registered."))
            }
            memorySchools[school.id] = school

            if (!isOffline()) {
                try {
                    val sObj = JSONObject().apply {
                        put("id", school.id)
                        put("name", school.name)
                        put("code", school.code)
                        put("address", school.address)
                        put("principalId", school.principalId)
                        put("contactEmail", school.contactEmail)
                        put("contactPhone", school.contactPhone)
                        put("currency", school.currency)
                        put("currencyCode", school.currencyCode)
                        put("createdAt", school.createdAt)
                    }
                    val docId = saveDocumentToCloud("SCHOOL_${school.id}", null, sObj)
                    if (docId != null) {
                        setCloudPointer("sch_${school.id}", docId)
                    }
                } catch (e: Exception) {
                    Log.w("CloudDatabaseService", "Remote school registration notice: ${e.message}")
                }
            }

            Result.success(school)
        }
    }

    suspend fun updateCloudSchoolCurrency(schoolId: String, currency: String, currencyCode: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val s = memorySchools[schoolId.trim()] ?: return@withContext Result.failure(Exception("School not found"))
            val updated = s.copy(currency = currency, currencyCode = currencyCode)
            memorySchools[updated.id] = updated
            Result.success(Unit)
        }
    }

    // --- Cloud Chat Messages Operations ---

    suspend fun getCloudMessages(schoolId: String, studentId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        memoryMessages.filter {
            it.schoolId.equals(schoolId.trim(), ignoreCase = true) &&
                    it.studentId.equals(studentId.trim(), ignoreCase = true)
        }.sortedBy { it.timestamp }
    }

    suspend fun getCloudMessagesForSchool(schoolId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        memoryMessages.filter {
            it.schoolId.equals(schoolId.trim(), ignoreCase = true)
        }.sortedBy { it.timestamp }
    }

    suspend fun sendCloudMessage(message: ChatMessage): Result<ChatMessage> = withContext(Dispatchers.IO) {
        memoryMessages.add(message)
        Result.success(message)
    }

    // --- Multi-Device School Data Synchronization ---

    suspend fun syncSchoolDataToCloud(schoolId: String, bundle: SchoolDataBundle): Result<Unit> = withContext(Dispatchers.IO) {
        memorySchoolBundles[schoolId.trim()] = bundle

        if (isOffline()) {
            return@withContext Result.success(Unit)
        }

        mutex.withLock {
            try {
                val existingDocId = getCloudPointer("sch_doc_$schoolId")
                val docId = saveDocumentToCloud("SCH_DATA_$schoolId", existingDocId, bundle.toJson())
                if (docId != null && existingDocId != docId) {
                    setCloudPointer("sch_doc_$schoolId", docId)
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Remote school sync notice: ${e.message}")
                Result.success(Unit) // local memory updated
            }
        }
    }

    suspend fun fetchSchoolDataFromCloud(schoolId: String): SchoolDataBundle? = withContext(Dispatchers.IO) {
        val clean = schoolId.trim()
        if (isOffline()) {
            return@withContext memorySchoolBundles[clean]
        }

        mutex.withLock {
            try {
                val docId = getCloudPointer("sch_doc_$clean")
                if (!docId.isNullOrBlank()) {
                    val bundleJson = fetchDocumentFromCloud(docId)
                    if (bundleJson != null) {
                        val bundle = SchoolDataBundle.fromJson(bundleJson)
                        memorySchoolBundles[clean] = bundle
                        return@withContext bundle
                    }
                }
            } catch (e: Exception) {
                Log.w("CloudDatabaseService", "Fetch school data notice: ${e.message}")
            }
            memorySchoolBundles[clean]
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: CloudDatabaseService? = null

        fun getInstance(context: Context): CloudDatabaseService {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudDatabaseService(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
