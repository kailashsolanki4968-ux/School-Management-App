package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.cloud.CloudDatabaseService
import com.example.data.db.AppDatabase
import com.example.data.model.AccountStatus
import com.example.data.model.ActivityRecord
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AnnouncementTarget
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.Student
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.session.SessionManager
import com.example.data.repository.SchoolRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SchoolCoreFlowsTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var cloudService: CloudDatabaseService
    private lateinit var sessionManager: SessionManager
    private lateinit var repository: SchoolRepository

    @Before
    fun setUp() = kotlinx.coroutines.runBlocking {
        context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        AppDatabase.ensureSeedData(db)

        cloudService = CloudDatabaseService(context)
        sessionManager = SessionManager(context)
        repository = SchoolRepository(db, sessionManager, cloudService)
    }

    @After
    fun tearDown() {
        db.close()
        val cloudDir = File(context.filesDir, "cloud_school_db")
        if (cloudDir.exists()) {
            cloudDir.deleteRecursively()
        }
    }

    @Test
    fun testPrincipalLoginAndSeedData() = runTest {
        val loginResult = repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        assertTrue("Principal login should succeed", loginResult.isSuccess)

        val session = repository.sessionState.value
        assertNotNull("Session should exist", session)
        assertEquals(UserRole.PRINCIPAL.name, session?.role)
        assertEquals("SCH_OAKRIDGE_101", session?.schoolId)

        val teachers = repository.getAllTeachers().first()
        assertTrue("Seed teachers should be populated", teachers.isNotEmpty())

        val classes = repository.getAllClasses().first()
        assertTrue("Seed classes should be populated", classes.isNotEmpty())
    }

    @Test
    fun testStudentCreationAndPermanentStudentID() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_9901"
        val newStudent = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "15",
            name = "Aarav Sharma",
            classId = "CLASS_10A",
            gender = "Male",
            parentName = "Rajesh Sharma",
            parentPhone = "+91 9876543210",
            emergencyContact = "+91 9876543210",
            address = "42 Green Valley, New Delhi"
        )
        repository.insertStudent(newStudent)

        val retrievedStudent = repository.getStudentById(studentId)
        assertNotNull("Student should be retrievable by generated student ID", retrievedStudent)
        assertEquals("Aarav Sharma", retrievedStudent?.name)
        assertEquals("15", retrievedStudent?.rollNumber)
    }

    @Test
    fun testParentRegistrationAndPrincipalApprovalFlow() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_9902"
        val student = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "16",
            name = "Diya Patel",
            classId = "CLASS_10A",
            gender = "Female",
            parentName = "Sunita Patel",
            parentPhone = "+91 9123456780"
        )
        repository.insertStudent(student)

        val parentId = "PAR_TEST_9902"
        val parentUser = UserAccount(
            id = parentId,
            schoolId = "SCH_OAKRIDGE_101",
            name = "Sunita Patel",
            email = "sunita@example.com",
            phone = "+91 9123456780",
            role = UserRole.PARENT.name,
            passwordHash = "",
            securityQuestion = "What is your pet name?",
            securityAnswer = "",
            status = AccountStatus.PENDING.name,
            linkedStudentIds = studentId
        )

        val registerResult = repository.registerUser(parentUser, "password123", "Fluffy")
        assertTrue("Parent registration should succeed", registerResult.isSuccess)

        val pendingParents = repository.getPendingParents().first()
        assertTrue("Pending parents list should include the new registration", pendingParents.any { it.id == parentId })

        repository.approveParentAndLinkStudents(parentId)

        val approvedUser = repository.getUserById(parentId)
        assertNotNull(approvedUser)
        assertEquals(AccountStatus.APPROVED.name, approvedUser?.status)
        assertEquals(studentId, approvedUser?.linkedStudentIds)
    }

    @Test
    fun testAttendanceAndMarksWorkflow() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getStudentsByClass("CLASS_10A").first()
        assertTrue("Students should exist in class 10A", students.isNotEmpty())
        val firstStudent = students.first()

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val attendanceRecord = AttendanceRecord(
            id = UUID.randomUUID().toString(),
            schoolId = "SCH_OAKRIDGE_101",
            date = today,
            studentId = firstStudent.id,
            studentName = firstStudent.name,
            rollNumber = firstStudent.rollNumber,
            classId = firstStudent.classId,
            status = AttendanceStatus.PRESENT.name,
            markedByTeacherId = "TCH101"
        )
        repository.saveAttendance(listOf(attendanceRecord))

        val fetchedAtt = repository.getAttendanceByClassAndDateDirect(firstStudent.classId, today)
        assertTrue("Attendance should be recorded", fetchedAtt.any { it.studentId == firstStudent.id && it.status == AttendanceStatus.PRESENT.name })

        val marksDrafts = listOf(
            Pair(firstStudent, Pair(46.5, "Outstanding performance"))
        )
        val testRes = repository.createTestWithMarks(
            testId = UUID.randomUUID().toString(),
            classId = firstStudent.classId,
            className = "Grade 10 - Section A",
            testName = "Optics Unit Test",
            subject = "Physics",
            date = today,
            maxMarks = 50.0,
            teacherId = "TCH101",
            teacherName = "Dr. Teacher",
            marksDrafts = marksDrafts
        )
        assertTrue("Test and marks creation should succeed", testRes.isSuccess)

        val studentMarks = repository.getMarksByStudent(firstStudent.id).first()
        assertTrue("Student marks should be recorded", studentMarks.any { it.subject == "Physics" && it.marksObtained == 46.5 })
    }

    @Test
    fun testFeeManagementAndCurrencyCustomization() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_FEE_01"
        val student = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "99",
            name = "Rohan Verma",
            classId = "CLASS_10A",
            gender = "Male",
            parentName = "Sanjay Verma",
            parentPhone = "+91 9988776655"
        )
        repository.insertStudent(student)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        repository.setStudentTotalFee(student, 25000.0)
        val fee = repository.getFeeForStudent(student.id).first()
        assertNotNull("Student fee record should exist", fee)
        assertEquals(25000.0, fee?.totalFee ?: 0.0, 0.01)
        assertEquals(0.0, fee?.totalPaid ?: 0.0, 0.01)

        val payResult = repository.recordFeePayment(
            student = student,
            amount = 10000.0,
            date = today,
            paymentMode = "Online UPI",
            note = "Term 1 installment",
            recordedBy = "Principal Office"
        )
        assertTrue("Fee payment should succeed", payResult.isSuccess)

        val updatedFee = repository.getFeeForStudent(student.id).first()
        assertEquals(10000.0, updatedFee?.totalPaid ?: 0.0, 0.01)
        assertEquals(15000.0, updatedFee?.remainingFee ?: 0.0, 0.01)

        repository.updateSchoolCurrency("$", "USD")
        val school = repository.getSchoolById("SCH_OAKRIDGE_101")
        assertEquals("$", school?.currency)
        assertEquals("USD", school?.currencyCode)
    }

    @Test
    fun testTeacherSalaryAndHistoryLogs() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val salResult = repository.recordTeacherSalary(
            teacherId = "TCH101",
            teacherName = "Mr. David Miller",
            month = "September 2026",
            monthlySalary = 4500.0,
            amountPaid = 4500.0,
            paymentDate = today,
            remainingAmount = 0.0,
            paymentMode = "Bank Transfer",
            transactionRef = "TXN-88219",
            remarks = "Paid in full",
            recordedBy = "Principal"
        )
        assertTrue("Teacher salary record should succeed", salResult.isSuccess)

        val salaries = repository.getSalariesForTeacher("TCH101").first()
        assertTrue("Salary records should exist", salaries.any { it.month == "September 2026" && it.amountPaid == 4500.0 })

        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = "SCH_OAKRIDGE_101",
            date = today,
            time = "10:30 AM",
            timestamp = System.currentTimeMillis(),
            category = "FINANCE",
            personName = "Principal",
            personRole = "PRINCIPAL",
            action = "Updated School Currency to USD",
            performedBy = "PRIN001"
        )
        repository.logActivity(activity)

        val activities = repository.getAllActivities().first()
        assertTrue("Audit history should contain logged activity", activities.any { it.action == "Updated School Currency to USD" })
    }

    @Test
    fun testAnnouncementTargetingRoles_AllParents_AllTeachers_AllSchool() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        // 1. Notice for All School
        val noticeAllSchool = Announcement(
            id = "ANN_ALL_SCHOOL",
            schoolId = "SCH_OAKRIDGE_101",
            title = "Welcome Back to School",
            content = "School begins next Monday for everyone.",
            targetAudience = AnnouncementTarget.ALL_SCHOOL,
            priority = AnnouncementPriority.NORMAL.name,
            authorName = "Principal",
            date = today
        )
        repository.insertAnnouncement(noticeAllSchool)

        // 2. Notice for All Parents
        val noticeAllParents = Announcement(
            id = "ANN_ALL_PARENTS",
            schoolId = "SCH_OAKRIDGE_101",
            title = "Parent-Teacher Meeting Schedule",
            content = "PTM will be held on Friday afternoon.",
            targetAudience = AnnouncementTarget.ALL_PARENTS,
            priority = AnnouncementPriority.URGENT.name,
            authorName = "Principal",
            date = today
        )
        repository.insertAnnouncement(noticeAllParents)

        // 3. Notice for All Teachers
        val noticeAllTeachers = Announcement(
            id = "ANN_ALL_TEACHERS",
            schoolId = "SCH_OAKRIDGE_101",
            title = "Faculty Staff Briefing",
            content = "Emergency faculty meeting in Conference Room A at 8 AM.",
            targetAudience = AnnouncementTarget.ALL_TEACHERS,
            priority = AnnouncementPriority.URGENT.name,
            authorName = "Principal",
            date = today
        )
        repository.insertAnnouncement(noticeAllTeachers)

        // 4. Notice for All Classes
        val noticeAllClasses = Announcement(
            id = "ANN_ALL_CLASSES",
            schoolId = "SCH_OAKRIDGE_101",
            title = "Uniform Inspection Notice",
            content = "Mandatory winter uniform compliance for all classes.",
            targetAudience = AnnouncementTarget.ALL_CLASSES,
            priority = AnnouncementPriority.NORMAL.name,
            authorName = "Principal",
            date = today
        )
        repository.insertAnnouncement(noticeAllClasses)

        // Verify Principal sees all announcements
        val allAnnouncements = repository.getAllAnnouncements().first()
        assertTrue(allAnnouncements.any { it.id == "ANN_ALL_SCHOOL" })
        assertTrue(allAnnouncements.any { it.id == "ANN_ALL_PARENTS" })
        assertTrue(allAnnouncements.any { it.id == "ANN_ALL_TEACHERS" })
        assertTrue(allAnnouncements.any { it.id == "ANN_ALL_CLASSES" })

        // Verify Parent receives ALL_SCHOOL, ALL_PARENTS, ALL_CLASSES, but NEVER ALL_TEACHERS
        val parentAnnouncements = repository.getAnnouncementsForParent("CLS_10A").first()
        assertTrue("Parent should receive All School notice", parentAnnouncements.any { it.id == "ANN_ALL_SCHOOL" })
        assertTrue("Parent should receive All Parents notice", parentAnnouncements.any { it.id == "ANN_ALL_PARENTS" })
        assertTrue("Parent should receive All Classes notice", parentAnnouncements.any { it.id == "ANN_ALL_CLASSES" })
        assertFalse("Parent MUST NOT receive All Teachers notice", parentAnnouncements.any { it.id == "ANN_ALL_TEACHERS" })

        // Verify Teacher receives ALL_SCHOOL, ALL_TEACHERS, ALL_CLASSES, but NEVER ALL_PARENTS
        val teacherAnnouncements = repository.getAnnouncementsForTeacher("CLS_10A").first()
        assertTrue("Teacher should receive All School notice", teacherAnnouncements.any { it.id == "ANN_ALL_SCHOOL" })
        assertTrue("Teacher should receive All Teachers notice", teacherAnnouncements.any { it.id == "ANN_ALL_TEACHERS" })
        assertTrue("Teacher should receive All Classes notice", teacherAnnouncements.any { it.id == "ANN_ALL_CLASSES" })
        assertFalse("Teacher MUST NOT receive All Parents notice", teacherAnnouncements.any { it.id == "ANN_ALL_PARENTS" })
    }

    @Test
    fun testAnnouncementTargeting_CustomSelectedClasses_MultiClass() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        // Principal creates announcement targeting custom selected classes: CLS_10A and CLS_11A
        val selectedClasses = listOf("CLS_10A", "CLS_11A")
        val customNotice = Announcement(
            id = "ANN_SENIOR_EXAM",
            schoolId = "SCH_OAKRIDGE_101",
            title = "Senior Wing Mock Exam Routine",
            content = "Mock exams for Grades 10 and 11 will commence next Tuesday.",
            targetAudience = AnnouncementTarget.formatCustomClasses(selectedClasses),
            priority = AnnouncementPriority.EVENT.name,
            authorName = "Principal",
            date = today
        )
        repository.insertAnnouncement(customNotice)

        // Verify eligibility for Parents
        val parent10A = repository.getAnnouncementsForParent("CLS_10A").first()
        val parent11A = repository.getAnnouncementsForParent("CLS_11A").first()
        val parent09A = repository.getAnnouncementsForParent("CLS_09A").first()

        assertTrue("Parent in Class 10A must receive the custom announcement", parent10A.any { it.id == "ANN_SENIOR_EXAM" })
        assertTrue("Parent in Class 11A must receive the custom announcement", parent11A.any { it.id == "ANN_SENIOR_EXAM" })
        assertFalse("Parent in Class 9A must NOT receive the announcement (unselected class)", parent09A.any { it.id == "ANN_SENIOR_EXAM" })

        // Verify eligibility for Teachers assigned to selected classes vs unselected
        val teacher10A = repository.getAnnouncementsForTeacher("CLS_10A").first()
        val teacher11A = repository.getAnnouncementsForTeacher("CLS_11A").first()
        val teacher09A = repository.getAnnouncementsForTeacher("CLS_09A").first()
        val teacherUnassigned = repository.getAnnouncementsForTeacher(null).first()

        assertTrue("Teacher assigned to Class 10A must receive the custom announcement", teacher10A.any { it.id == "ANN_SENIOR_EXAM" })
        assertTrue("Teacher assigned to Class 11A must receive the custom announcement", teacher11A.any { it.id == "ANN_SENIOR_EXAM" })
        assertFalse("Teacher assigned to Class 9A must NOT receive the announcement", teacher09A.any { it.id == "ANN_SENIOR_EXAM" })
        assertFalse("Unassigned teacher must NOT receive class-specific announcement", teacherUnassigned.any { it.id == "ANN_SENIOR_EXAM" })
    }

    @Test
    fun testMultiDeviceLoginAndCloudSync() = runTest {
        // Register an account on Phone A
        val newTeacher = UserAccount(
            id = "TCH_DEVICE_TEST",
            name = "Device Test Teacher",
            role = UserRole.TEACHER.name,
            schoolId = "SCH_OAKRIDGE_101",
            status = AccountStatus.APPROVED.name,
            email = "devicetest@oakridge.edu",
            phone = "+19998887777",
            securityQuestion = "What city?",
            subject = "Physics"
        )
        val regResult = repository.registerUser(newTeacher, "devicePass123", "NewYork")
        assertTrue("Teacher registration on Device A should succeed", regResult.isSuccess)

        // Simulate Phone B: clear local session
        repository.logout()

        // Login on Phone B with same credentials
        val loginResult = repository.login("TCH_DEVICE_TEST", "devicePass123", UserRole.TEACHER.name, "SCH_OAKRIDGE_101")
        assertTrue("Login on Device B with valid credentials should succeed", loginResult.isSuccess)
        val loggedInUser = loginResult.getOrNull()
        assertNotNull(loggedInUser)
        assertEquals("TCH_DEVICE_TEST", loggedInUser?.id)
        assertEquals("SCH_OAKRIDGE_101", loggedInUser?.schoolId)
        assertEquals(UserRole.TEACHER.name, loggedInUser?.role)
        assertEquals("Physics", loggedInUser?.subject)
    }

    @Test
    fun testChangePasswordAndSessionInvalidationAcrossDevices() = runTest {
        // Log in
        val loginResult = repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        assertTrue("Initial login should succeed", loginResult.isSuccess)

        // Store session version of Device B
        val deviceBSession = repository.sessionState.value
        assertNotNull("Session should be active", deviceBSession)
        val initialSessionVersion = deviceBSession!!.sessionVersion

        // Change password on Device A
        val changeResult = repository.changePassword("PRIN001", "principal123", "brandNewPassword456", "brandNewPassword456")
        assertTrue("Password change with valid current password must succeed", changeResult.isSuccess)

        // The old password must immediately stop working
        repository.logout()
        val oldPassLogin = repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        assertTrue("Old password must fail after password change", oldPassLogin.isFailure)

        // The new password must immediately work
        val newPassLogin = repository.login("PRIN001", "brandNewPassword456", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        assertTrue("New password must succeed after password change", newPassLogin.isSuccess)
        val newSession = repository.sessionState.value
        assertNotNull(newSession)
        assertTrue("New session version must be greater than initial", newSession!!.sessionVersion > initialSessionVersion)
    }

    @Test
    fun testAttendancePercentageMathematicalCorrectness() = runTest {
        // Attendance calculations: totalMarked = 10, present = 8, late = 2 -> 100%
        val totalMarked = 10
        val present = 8
        val late = 2
        val attended = (present + late).coerceAtMost(totalMarked)
        val pct = ((attended.toDouble() / totalMarked.toDouble()) * 100.0).coerceIn(0.0, 100.0)
        assertEquals(100.0, pct, 0.001)

        // When present = 7, late = 1, absent = 2
        val present2 = 7
        val late2 = 1
        val attended2 = (present2 + late2).coerceAtMost(totalMarked)
        val pct2 = ((attended2.toDouble() / totalMarked.toDouble()) * 100.0).coerceIn(0.0, 100.0)
        assertEquals(80.0, pct2, 0.001)

        // Even with anomalous count, pct never exceeds 100.0
        val anomalousAttended = 15.coerceAtMost(totalMarked)
        val anomalousPct = ((anomalousAttended.toDouble() / totalMarked.toDouble()) * 100.0).coerceIn(0.0, 100.0)
        assertTrue("Percentage must never exceed 100%", anomalousPct <= 100.0)
    }

    @Test
    fun testAcademicYearCreationAndSwitching() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        // 1. Initial academic years should include seeded 2026-27, 2027-28, 2028-29
        val years = repository.getAllAcademicYears().first()
        assertTrue("Should have initial academic years", years.size >= 3)
        val currentYear = repository.getCurrentAcademicYearFlow().first()
        assertEquals("2026-27", currentYear?.yearCode)

        // 2. Create a new Academic Year
        val createResult = repository.createAcademicYear("2029-30", "Academic Year 2029-30", "2029-04-01", "2030-03-31")
        assertTrue("Creating valid academic year must succeed", createResult.isSuccess)

        // 3. Prevent duplicate academic year
        val dupResult = repository.createAcademicYear("2029-30", "Duplicate Year")
        assertTrue("Creating duplicate academic year must fail", dupResult.isFailure)

        // 4. Switch current active academic year
        val switchResult = repository.setCurrentAcademicYear("2027-28")
        assertTrue("Switching current academic year must succeed", switchResult.isSuccess)
        val updatedCurrentYear = repository.getCurrentAcademicYearFlow().first()
        assertEquals("2027-28", updatedCurrentYear?.yearCode)
    }

    @Test
    fun testStudentPromotionPreservesHistoricalDataAndCreatesNewEnrollment() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getAllStudents().first()
        assertTrue("Should have seeded students", students.isNotEmpty())
        val student = students.first()

        val sourceYear = "2026-27"
        val targetYear = "2027-28"
        val targetClassId = "CLASS_10B"
        val newRoll = "99"

        // Perform promotion
        val promoResult = repository.promoteStudent(
            studentId = student.id,
            fromYear = sourceYear,
            toYear = targetYear,
            targetClassId = targetClassId,
            targetRollNumber = newRoll,
            newYearFee = 55000.0,
            remarks = "Promoted with honors"
        )
        assertTrue("Promotion must succeed", promoResult.isSuccess)

        // Verify enrollments for student
        val enrollments = repository.getEnrollmentsForStudentDirect(student.id)
        assertEquals(2, enrollments.size)

        val historicalEnrollment = enrollments.find { it.academicYear == sourceYear }
        assertNotNull("Historical enrollment must exist", historicalEnrollment)
        assertEquals("PROMOTED", historicalEnrollment?.status)

        val newEnrollment = enrollments.find { it.academicYear == targetYear }
        assertNotNull("New enrollment must exist", newEnrollment)
        assertEquals("ACTIVE", newEnrollment?.status)
        assertEquals(targetClassId, newEnrollment?.classId)
        assertEquals(newRoll, newEnrollment?.rollNumber)
        assertEquals(sourceYear, newEnrollment?.promotedFromYear)

        // Verify fee record generated for new year
        val feeTargetYear = repository.getFeeForStudentAndYear(student.id, targetYear).first()
        assertNotNull("Fee record for target year must exist", feeTargetYear)
        assertEquals(55000.0, feeTargetYear?.totalFee ?: 0.0, 0.01)

        // Verify previous year fee record is preserved untouched
        val feeSourceYear = repository.getFeeForStudentAndYear(student.id, sourceYear).first()
        assertNotNull("Fee record for source year must be preserved", feeSourceYear)
    }

    @Test
    fun testPreventDuplicateEnrollmentInSameYear() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getAllStudents().first()
        val student = students.first()

        // Student is already enrolled in 2026-27 from seeding
        val dupPromoResult = repository.promoteStudent(
            studentId = student.id,
            fromYear = "2025-26",
            toYear = "2026-27",
            targetClassId = "CLASS_10A",
            targetRollNumber = "10"
        )
        assertTrue("Duplicate enrollment in same academic year must fail", dupPromoResult.isFailure)
    }

    @Test
    fun testStudentRetentionFlow() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getAllStudents().first()
        val student = students[1] // Pick second student

        val retainResult = repository.retainStudent(
            studentId = student.id,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = student.classId,
            targetRollNumber = student.rollNumber,
            newYearFee = 45000.0,
            remarks = "Retained for improvement"
        )
        assertTrue("Retention must succeed", retainResult.isSuccess)

        val enrollments = repository.getEnrollmentsForStudentDirect(student.id)
        val pastEnrollment = enrollments.find { it.academicYear == "2026-27" }
        assertEquals("RETAINED", pastEnrollment?.status)

        val nextEnrollment = enrollments.find { it.academicYear == "2027-28" }
        assertEquals("ACTIVE", nextEnrollment?.status)
    }

    @Test
    fun testInsertStudentSavesPermanentlyAndCreatesEnrollment() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_PERM_001"
        val newStudent = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "55",
            name = "Rohan Verma",
            classId = "CLASS_10A",
            gender = "Male",
            parentName = "Sanjay Verma",
            parentPhone = "+91 9888877777",
            emergencyContact = "+91 9888877777",
            address = "Sector 14, Gurgaon"
        )

        val result = repository.insertStudent(newStudent)
        assertTrue("Insert student must succeed", result.isSuccess)

        // Verify permanent student record exists in student master table
        val masterStudent = repository.getStudentById(studentId)
        assertNotNull("Master student record must be saved permanently", masterStudent)
        assertEquals("Rohan Verma", masterStudent?.name)
        assertEquals("CLASS_10A", masterStudent?.classId)
        assertEquals("55", masterStudent?.rollNumber)

        // Verify enrollment in active academic year
        val enrollments = repository.getEnrollmentsForStudentDirect(studentId)
        assertEquals(1, enrollments.size)
        assertEquals("2026-27", enrollments[0].academicYear)
        assertEquals("CLASS_10A", enrollments[0].classId)
        assertEquals("55", enrollments[0].rollNumber)
        assertEquals("ACTIVE", enrollments[0].status)
    }

    @Test
    fun testEditExistingStudentDetailsAndPreservePermanentId() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getAllStudents().first()
        val original = students.first()
        val originalId = original.id

        // Edit details: updated name, phone, address, and roll number
        val updated = original.copy(
            name = "${original.name} Updated",
            rollNumber = "88",
            parentPhone = "+91 9999900000",
            address = "New Address, Suite 100"
        )

        val updateResult = repository.updateStudent(updated)
        assertTrue("Updating student details must succeed", updateResult.isSuccess)

        val savedStudent = repository.getStudentById(originalId)
        assertNotNull(savedStudent)
        assertEquals(originalId, savedStudent?.id)
        assertEquals("${original.name} Updated", savedStudent?.name)
        assertEquals("88", savedStudent?.rollNumber)
        assertEquals("+91 9999900000", savedStudent?.parentPhone)
        assertEquals("New Address, Suite 100", savedStudent?.address)

        // Verify that the enrollment for the current year reflects the new roll number
        val enrollment = repository.getEnrollmentForStudentAndYear(originalId, "2026-27")
        assertNotNull(enrollment)
        assertEquals("88", enrollment?.rollNumber)
    }

    @Test
    fun testStudentClassChangePreservesHistoryAndRecordsTransition() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getAllStudents().first()
        val student = students.first()
        val originalClassId = student.classId
        val newClassId = "CLASS_10B"
        val newRoll = "77"

        // Perform class change within same academic year
        val changeResult = repository.changeStudentClass(
            studentId = student.id,
            targetClassId = newClassId,
            newRollNumber = newRoll,
            academicYear = "2026-27",
            reason = "Streamlined section balance"
        )
        assertTrue("Class change must succeed", changeResult.isSuccess)

        // Verify master record updated
        val updatedStudent = repository.getStudentById(student.id)
        assertEquals(newClassId, updatedStudent?.classId)
        assertEquals(newRoll, updatedStudent?.rollNumber)

        // Verify active enrollment updated
        val enrollment = repository.getEnrollmentForStudentAndYear(student.id, "2026-27")
        assertEquals(newClassId, enrollment?.classId)
        assertEquals(newRoll, enrollment?.rollNumber)
        assertEquals("ACTIVE", enrollment?.status)

        // Verify activity log recorded the transfer
        val activities = repository.getAllActivities().first()
        assertTrue("Activity log must record class change", activities.any { it.action.contains("Transferred") || it.details.contains("Transferred") })
    }

    @Test
    fun testPreventDuplicateRollNumberInSameClassAndYear() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getStudentsByClass("CLASS_10A").first()
        val existingStudent = students.first()
        val existingRoll = existingStudent.rollNumber

        // Attempt to create another student with the exact same roll number in the same class
        val duplicateStudent = Student(
            id = "STU_COLLISION_TEST",
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = existingRoll,
            name = "Collision Student",
            classId = "CLASS_10A",
            gender = "Female"
        )

        val result = repository.insertStudent(duplicateStudent)
        assertTrue("Inserting student with duplicate roll number in same class and year must fail", result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("already assigned") == true)
    }

    @Test
    fun testStudentStatusUpdateWithRemarks() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getAllStudents().first()
        val student = students.last()

        val statusResult = repository.updateStudentEnrollmentStatus(
            studentId = student.id,
            academicYear = "2026-27",
            newStatus = "TRANSFERRED",
            remarks = "Transferred to international school"
        )
        assertTrue("Updating student enrollment status must succeed", statusResult.isSuccess)

        val enrollment = repository.getEnrollmentForStudentAndYear(student.id, "2026-27")
        assertEquals("TRANSFERRED", enrollment?.status)
        assertEquals("Transferred to international school", enrollment?.remarks)
    }

    @Test
    fun testStudentPromotionFromGrade10ToGrade11() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        // Ensure 2027-28 exists
        val years = repository.getAllAcademicYears().first()
        if (years.none { it.yearCode == "2027-28" }) {
            repository.createAcademicYear("2027-28", "Academic Year 2027-28", "2027-04-01", "2028-03-31")
        }

        // Get Grade 10 A students in 2026-27
        val students10A = repository.getStudentsByClassAndYear("CLASS_10A", "2026-27").first()
        assertTrue("Grade 10A should have students enrolled in 2026-27", students10A.isNotEmpty())
        val studentToPromote = students10A.first()
        val originalId = studentToPromote.id

        // Promote student to Grade 11 A for 2027-28
        val promoteResult = repository.promoteStudent(
            studentId = originalId,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = "CLASS_11A",
            targetRollNumber = "01"
        )
        assertTrue("Promoting student to Grade 11 A must succeed: ${promoteResult.exceptionOrNull()?.message}", promoteResult.isSuccess)

        // Verify previous year enrollment is marked PROMOTED
        val prevEnrollment = repository.getEnrollmentForStudentAndYear(originalId, "2026-27")
        assertNotNull(prevEnrollment)
        assertEquals("PROMOTED", prevEnrollment?.status)
        assertEquals("CLASS_10A", prevEnrollment?.classId)

        // Verify target year enrollment exists and is ACTIVE
        val newEnrollment = repository.getEnrollmentForStudentAndYear(originalId, "2027-28")
        assertNotNull(newEnrollment)
        assertEquals("ACTIVE", newEnrollment?.status)
        assertEquals("CLASS_11A", newEnrollment?.classId)
        assertEquals("01", newEnrollment?.rollNumber)
        assertEquals("2026-27", newEnrollment?.promotedFromYear)
        assertEquals("CLASS_10A", newEnrollment?.promotedFromClassId)

        // Verify student ID and personal identity are completely preserved
        val studentAfterPromotion = repository.getStudentById(originalId)
        assertNotNull(studentAfterPromotion)
        assertEquals(studentToPromote.name, studentAfterPromotion?.name)
        assertEquals(studentToPromote.parentPhone, studentAfterPromotion?.parentPhone)

        // Verify fee record was initialized for 2027-28
        val targetFee = db.feeDao().getFeeForStudentAndYearDirect(originalId, "2027-28")
        assertNotNull("Target fee record should be created", targetFee)

        // Verify previous year fee record is completely preserved
        val prevFee = db.feeDao().getFeeForStudentAndYearDirect(originalId, "2026-27")
        assertNotNull("Previous year fee record should be intact", prevFee)
    }

    @Test
    fun testPreventDuplicatePromotionInSameAcademicYear() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val years = repository.getAllAcademicYears().first()
        if (years.none { it.yearCode == "2027-28" }) {
            repository.createAcademicYear("2027-28", "Academic Year 2027-28", "2027-04-01", "2028-03-31")
        }

        val students10A = repository.getStudentsByClassAndYear("CLASS_10A", "2026-27").first()
        val student = students10A.last()

        // First promotion
        val firstPromotion = repository.promoteStudent(
            studentId = student.id,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = "CLASS_11A",
            targetRollNumber = "05"
        )
        assertTrue("First promotion must succeed", firstPromotion.isSuccess)

        // Second promotion of the SAME student into the SAME target year 2027-28
        val secondPromotion = repository.promoteStudent(
            studentId = student.id,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = "CLASS_11B",
            targetRollNumber = "06"
        )
        assertTrue("Duplicate promotion in the same academic year must fail", secondPromotion.isFailure)
        assertTrue(secondPromotion.exceptionOrNull()?.message?.contains("already enrolled") == true)
    }

    @Test
    fun testPreventPromotionWithInvalidParameters() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students10A = repository.getStudentsByClassAndYear("CLASS_10A", "2026-27").first()
        val student = students10A.first()

        // Same source and target year
        val sameYearResult = repository.promoteStudent(
            studentId = student.id,
            fromYear = "2026-27",
            toYear = "2026-27",
            targetClassId = "CLASS_11A",
            targetRollNumber = "01"
        )
        assertTrue("Promotion with same source and target year must fail", sameYearResult.isFailure)

        // Invalid target class
        val invalidClassResult = repository.promoteStudent(
            studentId = student.id,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = "NON_EXISTENT_CLASS",
            targetRollNumber = "01"
        )
        assertTrue("Promotion with non-existent target class must fail", invalidClassResult.isFailure)
    }

    @Test
    fun testBatchStudentPromotionWorkflow() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val years = repository.getAllAcademicYears().first()
        if (years.none { it.yearCode == "2027-28" }) {
            repository.createAcademicYear("2027-28", "Academic Year 2027-28", "2027-04-01", "2028-03-31")
        }

        // Get all students in Grade 10 B for 2026-27
        val students10B = repository.getStudentsByClassAndYear("CLASS_10B", "2026-27").first()
        assertTrue("Grade 10 B should have students", students10B.isNotEmpty())
        val idsToPromote = students10B.map { it.id }

        // Batch promote to Grade 11 B
        val batchResult = repository.promoteBatchStudents(
            studentIds = idsToPromote,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = "CLASS_11B"
        )
        assertTrue("Batch promotion must succeed", batchResult.isSuccess)
        val stats = batchResult.getOrThrow()
        assertEquals(idsToPromote.size, stats.successCount)
        assertEquals(0, stats.failureCount)

        // Verify each student's enrollment in 2027-28
        for (id in idsToPromote) {
            val enrollment27 = repository.getEnrollmentForStudentAndYear(id, "2027-28")
            assertNotNull("Target enrollment must exist for $id", enrollment27)
            assertEquals("CLASS_11B", enrollment27?.classId)
            assertEquals("ACTIVE", enrollment27?.status)

            val enrollment26 = repository.getEnrollmentForStudentAndYear(id, "2026-27")
            assertEquals("PROMOTED", enrollment26?.status)
        }

        // Verify activity record was inserted
        val activities = repository.getAllActivities().first()
        assertTrue("Activity log must record batch promotion", activities.any { it.action.contains("Batch Promoted") || it.action.contains("Batch Promotion") })
    }

    @Test
    fun testClassChangeWorkflowWithinSameAcademicYear() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        // 1. Pick an existing student in CLASS_10A for 2026-27
        val students10A = repository.getStudentsByClassAndYear("CLASS_10A", "2026-27").first()
        assertTrue("Grade 10 A should have students", students10A.isNotEmpty())
        val student = students10A.first()
        val originalStudentId = student.id
        val originalName = student.name
        val originalParentPhone = student.parentPhone
        val originalYear = "2026-27"

        val initialYearsCount = repository.getAllAcademicYears().first().size

        // 2. Perform Class Change from CLASS_10A to CLASS_10B within the SAME academic year 2026-27
        val newRollNumber = "45"
        val changeResult = repository.changeStudentClass(
            studentId = originalStudentId,
            targetClassId = "CLASS_10B",
            newRollNumber = newRollNumber,
            academicYear = originalYear,
            reason = "Section transfer per parent request"
        )
        assertTrue("Class change within same academic year must succeed: ${changeResult.exceptionOrNull()?.message}", changeResult.isSuccess)

        // 3. Verify it did NOT create a new academic year
        val currentYearsCount = repository.getAllAcademicYears().first().size
        assertEquals("Class change must NOT create a new academic year", initialYearsCount, currentYearsCount)

        // 4. Verify student ID and personal details are strictly preserved
        val studentAfter = repository.getStudentById(originalStudentId)
        assertNotNull("Student master record must exist", studentAfter)
        assertEquals("Student ID must be strictly preserved", originalStudentId, studentAfter?.id)
        assertEquals("Student Name must be strictly preserved", originalName, studentAfter?.name)
        assertEquals("Parent phone must be preserved", originalParentPhone, studentAfter?.parentPhone)

        // 5. Verify master record immediately updates to target class and roll number
        assertEquals("CLASS_10B", studentAfter?.classId)
        assertEquals(newRollNumber, studentAfter?.rollNumber)

        // 6. Verify enrollment record for 2026-27 is updated
        val enrollment = repository.getEnrollmentForStudentAndYear(originalStudentId, originalYear)
        assertNotNull("Enrollment in 2026-27 must exist", enrollment)
        assertEquals("CLASS_10B", enrollment?.classId)
        assertEquals(newRollNumber, enrollment?.rollNumber)
        assertEquals("ACTIVE", enrollment?.status)

        // 7. Verify student appears in target class list immediately
        val targetClassStudents = repository.getStudentsByClass("CLASS_10B").first()
        assertTrue("Student must immediately appear in target class list", targetClassStudents.any { it.id == originalStudentId && it.rollNumber == newRollNumber })

        // 8. Verify student no longer appears in old class list
        val oldClassStudents = repository.getStudentsByClass("CLASS_10A").first()
        assertFalse("Student must not appear in old class list", oldClassStudents.any { it.id == originalStudentId })
    }

    @Test
    fun testClassChangeDuplicateRollNumberPrevention() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        // Pick student A from CLASS_10A
        val students10A = repository.getStudentsByClassAndYear("CLASS_10A", "2026-27").first()
        val studentA = students10A.first()

        // Pick student B from CLASS_10B to obtain their roll number
        val students10B = repository.getStudentsByClassAndYear("CLASS_10B", "2026-27").first()
        assertTrue("CLASS_10B must have students", students10B.isNotEmpty())
        val studentB = students10B.first()
        val takenRollNumber = studentB.rollNumber

        // Attempt to move student A to CLASS_10B using student B's already taken roll number
        val conflictResult = repository.changeStudentClass(
            studentId = studentA.id,
            targetClassId = "CLASS_10B",
            newRollNumber = takenRollNumber,
            academicYear = "2026-27",
            reason = "Transfer attempt"
        )
        assertTrue("Class change with colliding roll number must fail", conflictResult.isFailure)
        val errorMessage = conflictResult.exceptionOrNull()?.message ?: ""
        assertTrue("Error message should mention roll number or assignment: $errorMessage", 
            errorMessage.contains("already assigned", ignoreCase = true) || errorMessage.contains("taken", ignoreCase = true) || errorMessage.contains(takenRollNumber))
    }

    @Test
    fun testClassChangeSameClassAndRollNoOpPrevention() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students10A = repository.getStudentsByClassAndYear("CLASS_10A", "2026-27").first()
        val student = students10A.first()

        // Attempt to change to same class and same roll number
        val noOpResult = repository.changeStudentClass(
            studentId = student.id,
            targetClassId = student.classId,
            newRollNumber = student.rollNumber,
            academicYear = "2026-27"
        )
        assertTrue("Changing to identical class and roll must be rejected", noOpResult.isFailure)
        assertTrue(noOpResult.exceptionOrNull()?.message?.contains("already in this class", ignoreCase = true) == true)
    }

    @Test
    fun testAddStudentWorkflowAndDuplicateRollPrevention() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val newStudentId = repository.getNextAvailableStudentId()
        val nextRoll = repository.getNextAvailableRollNumber("CLASS_10A", "2026-27")

        // 1. Add valid new student to existing class
        val student = Student(
            id = newStudentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = nextRoll,
            name = "Meera Krishnan",
            classId = "CLASS_10A",
            gender = "Female",
            parentName = "Ramesh Krishnan",
            parentPhone = "+91 9444123456",
            emergencyContact = "+91 9444123456",
            address = "7 Rose Gardens, New Delhi"
        )

        val insertResult = repository.insertStudent(student, academicYear = "2026-27")
        assertTrue("Adding student should succeed: ${insertResult.exceptionOrNull()?.message}", insertResult.isSuccess)

        // Verify permanent save and appearance in student list
        val saved = repository.getStudentById(newStudentId)
        assertNotNull("Student must be saved permanently in DB", saved)
        assertEquals("Meera Krishnan", saved?.name)
        assertEquals("CLASS_10A", saved?.classId)
        assertEquals(nextRoll, saved?.rollNumber)

        val classStudents = repository.getStudentsByClass("CLASS_10A").first()
        assertTrue("Student must appear in class student list", classStudents.any { it.id == newStudentId })

        // 2. Attempt to add another student with the SAME roll number in the SAME class
        val duplicateRollStudent = Student(
            id = repository.getNextAvailableStudentId(),
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = nextRoll, // Duplicate roll!
            name = "Another Student",
            classId = "CLASS_10A",
            gender = "Male"
        )
        val dupRollResult = repository.insertStudent(duplicateRollStudent, academicYear = "2026-27")
        assertTrue("Adding student with duplicate roll must fail", dupRollResult.isFailure)

        // 3. Attempt to add another student with duplicate student ID
        val duplicateIdStudent = Student(
            id = newStudentId, // Duplicate ID!
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "99",
            name = "Duplicate ID Student",
            classId = "CLASS_10A",
            gender = "Male"
        )
        val dupIdResult = repository.insertStudent(duplicateIdStudent, academicYear = "2026-27")
        assertTrue("Adding student with duplicate ID must fail", dupIdResult.isFailure)
    }

    @Test
    fun testStudentClassChangeVsPromotionDistinction() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val years = repository.getAllAcademicYears().first()
        if (years.none { it.yearCode == "2027-28" }) {
            repository.createAcademicYear("2027-28", "Academic Year 2027-28", "2027-04-01", "2028-03-31")
        }

        val students10B = repository.getStudentsByClassAndYear("CLASS_10B", "2026-27").first()
        val studentForClassChange = students10B[0]
        val studentForPromotion = students10B[1]

        // Action A: Class Change (same academic year 2026-27)
        val classChangeResult = repository.changeStudentClass(
            studentId = studentForClassChange.id,
            targetClassId = "CLASS_10A",
            newRollNumber = "55",
            academicYear = "2026-27"
        )
        assertTrue("Class Change must succeed", classChangeResult.isSuccess)
        val enrollmentAfterChange = repository.getEnrollmentForStudentAndYear(studentForClassChange.id, "2026-27")
        assertEquals("ACTIVE", enrollmentAfterChange?.status) // Still ACTIVE in 2026-27, NOT PROMOTED
        assertEquals("CLASS_10A", enrollmentAfterChange?.classId)
        val nextYearEnrollmentChange = repository.getEnrollmentForStudentAndYear(studentForClassChange.id, "2027-28")
        assertEquals("Class change must NOT create enrollment in 2027-28", null, nextYearEnrollmentChange)

        // Action B: Promotion (moves to 2027-28, marks 2026-27 as PROMOTED)
        val promotionResult = repository.promoteStudent(
            studentId = studentForPromotion.id,
            fromYear = "2026-27",
            toYear = "2027-28",
            targetClassId = "CLASS_11A",
            targetRollNumber = "12"
        )
        assertTrue("Promotion must succeed", promotionResult.isSuccess)
        val enrollment26AfterPromo = repository.getEnrollmentForStudentAndYear(studentForPromotion.id, "2026-27")
        assertEquals("PROMOTED", enrollment26AfterPromo?.status)
        val enrollment27AfterPromo = repository.getEnrollmentForStudentAndYear(studentForPromotion.id, "2027-28")
        assertNotNull(enrollment27AfterPromo)
        assertEquals("ACTIVE", enrollment27AfterPromo?.status)
        assertEquals("CLASS_11A", enrollment27AfterPromo?.classId)
    }

    @Test
    fun testAttendancePercentageCalculationBoundaries() = runTest {
        // Test Attendance Percentage Logic:
        // Case 1: 0 attendance records -> 0.0% (no division by zero / NaN)
        val totalZero = 0
        val attendedZero = 0
        val pctZero = if (totalZero > 0) ((attendedZero.toDouble() / totalZero.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
        assertEquals(0.0, pctZero, 0.001)

        // Case 2: 10 present out of 10 -> exactly 100.0%
        val totalTen = 10
        val attendedTen = 10
        val pctTen = if (totalTen > 0) ((attendedTen.toDouble() / totalTen.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
        assertEquals(100.0, pctTen, 0.001)

        // Case 3: 0 present out of 10 -> 0.0%
        val attendedNone = 0
        val pctNone = if (totalTen > 0) ((attendedNone.toDouble() / totalTen.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
        assertEquals(0.0, pctNone, 0.001)

        // Case 4: Edge case where attended > total (e.g. duplicate entries coerced)
        val attendedExcess = 15
        val attendedClamped = attendedExcess.coerceAtMost(totalTen)
        val pctClamped = if (totalTen > 0) ((attendedClamped.toDouble() / totalTen.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
        assertEquals(100.0, pctClamped, 0.001)
        assertTrue("Percentage must never exceed 100%", pctClamped <= 100.0)

        // Case 5: Partial attendance (7 out of 10) -> 70.0%
        val attendedSeven = 7
        val pctSeven = if (totalTen > 0) ((attendedSeven.toDouble() / totalTen.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
        assertEquals(70.0, pctSeven, 0.001)
    }
}
