package com.example.ui.teacher

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.LeaveStatus
import com.example.data.model.LeaveType
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.repository.SchoolRepository
import com.example.data.session.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class TeacherTab {
    ATTENDANCE,
    STUDENTS,
    HOMEWORK,
    MARKS,
    LEAVES,
    ANNOUNCEMENTS,
    PROFILE
}

data class AttendanceDraft(
    val studentId: String,
    val studentName: String,
    val rollNumber: String,
    var status: AttendanceStatus = AttendanceStatus.PRESENT,
    var remarks: String = ""
)

class TeacherViewModel(
    private val repository: SchoolRepository,
    val teacherId: String
) : ViewModel() {

    val sessionState: StateFlow<UserSession?> = repository.sessionState

    private val _currentTab = MutableStateFlow(TeacherTab.ATTENDANCE)
    val currentTab: StateFlow<TeacherTab> = _currentTab.asStateFlow()

    private val _selectedDate = MutableStateFlow(
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    )
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    // Teacher profile info
    val teacherProfile: StateFlow<UserAccount?> = repository.getUserByIdFlow(teacherId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Assigned class info (Dynamic from teacherProfile's assignedClassId)
    val assignedClass: StateFlow<SchoolClass?> = teacherProfile.flatMapLatest { profile ->
        if (profile?.assignedClassId != null) {
            repository.getClassByIdFlow(profile.assignedClassId)
        } else {
            flowOf(null)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Students strictly of the assigned class
    val classStudents: StateFlow<List<Student>> = teacherProfile.flatMapLatest { profile ->
        if (profile?.assignedClassId != null) {
            repository.getStudentsByClass(profile.assignedClassId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected date's attendance records for the assigned class
    val todayAttendance: StateFlow<List<AttendanceRecord>> = _selectedDate.flatMapLatest { date ->
        teacherProfile.flatMapLatest { profile ->
            if (profile?.assignedClassId != null) {
                repository.getAttendanceByClassAndDate(profile.assignedClassId, date)
            } else {
                flowOf(emptyList())
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current date's submission status for the assigned class
    val currentSubmission: StateFlow<AttendanceSubmissionRecord?> = _selectedDate.flatMapLatest { date ->
        teacherProfile.flatMapLatest { profile ->
            if (profile?.assignedClassId != null) {
                repository.getAttendanceSubmissionByClassAndDateFlow(profile.assignedClassId, date)
            } else {
                flowOf(null)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Past attendance submissions for this class
    val pastSubmissions: StateFlow<List<AttendanceSubmissionRecord>> = teacherProfile.flatMapLatest { profile ->
        if (profile?.assignedClassId != null) {
            repository.getAttendanceSubmissionsByClass(profile.assignedClassId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active attendance draft map for taking attendance
    private val _attendanceDrafts = MutableStateFlow<Map<String, AttendanceStatus>>(emptyMap())
    val attendanceDrafts: StateFlow<Map<String, AttendanceStatus>> = _attendanceDrafts.asStateFlow()

    private val _remarksDrafts = MutableStateFlow<Map<String, String>>(emptyMap())
    val remarksDrafts: StateFlow<Map<String, String>> = _remarksDrafts.asStateFlow()

    // Homework for assigned class
    val homeworkList: StateFlow<List<Homework>> = teacherProfile.flatMapLatest { profile ->
        if (profile?.assignedClassId != null) {
            repository.getHomeworkByClass(profile.assignedClassId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Marks for assigned class
    val marksList: StateFlow<List<StudentMark>> = teacherProfile.flatMapLatest { profile ->
        if (profile?.assignedClassId != null) {
            repository.getMarksByClass(profile.assignedClassId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Leaves for this teacher
    val leaveRequests: StateFlow<List<LeaveRequest>> = repository.getLeaveRequestsByTeacher(teacherId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Announcements for this class or ALL
    val announcements: StateFlow<List<Announcement>> = teacherProfile.flatMapLatest { profile ->
        if (profile?.assignedClassId != null) {
            repository.getAnnouncementsForClass(profile.assignedClassId)
        } else {
            repository.getAllAnnouncements()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Pre-load attendance drafts when students and existing records load
        viewModelScope.launch {
            todayAttendance.collect { records ->
                if (records.isNotEmpty()) {
                    val statusMap = records.associate { it.studentId to AttendanceStatus.valueOf(it.status) }
                    val remarksMap = records.associate { it.studentId to (it.remarks ?: "") }
                    _attendanceDrafts.value = statusMap
                    _remarksDrafts.value = remarksMap
                }
            }
        }
    }

    fun selectTab(tab: TeacherTab) {
        _currentTab.value = tab
    }

    fun selectDate(date: String) {
        _selectedDate.value = date
    }

    fun clearMessage() {
        _message.value = null
    }

    // Attendance Actions
    fun setStudentStatus(studentId: String, status: AttendanceStatus) {
        val current = _attendanceDrafts.value.toMutableMap()
        current[studentId] = status
        _attendanceDrafts.value = current
    }

    fun setStudentRemark(studentId: String, remark: String) {
        val current = _remarksDrafts.value.toMutableMap()
        current[studentId] = remark
        _remarksDrafts.value = current
    }

    fun markAllPresent() {
        val students = classStudents.value
        val map = students.associate { it.id to AttendanceStatus.PRESENT }
        _attendanceDrafts.value = map
        _message.value = "Marked all students as Present"
    }

    fun submitAttendanceToPrincipal() {
        val profile = teacherProfile.value
        val assigned = assignedClass.value
        val classId = profile?.assignedClassId ?: return
        val className = assigned?.name ?: "Assigned Class"
        val teacherName = profile.name
        val students = classStudents.value
        val date = _selectedDate.value
        val drafts = _attendanceDrafts.value
        val remarks = _remarksDrafts.value

        if (students.isEmpty()) {
            _message.value = "No students in class to record attendance."
            return
        }

        viewModelScope.launch {
            val totalStudents = students.size
            val presentStudents = students.count { (drafts[it.id] ?: AttendanceStatus.PRESENT) == AttendanceStatus.PRESENT }
            val absentStudentsList = students.filter { (drafts[it.id] ?: AttendanceStatus.PRESENT) == AttendanceStatus.ABSENT }
            val absentCount = absentStudentsList.size

            val absentStudentNames = if (absentStudentsList.isEmpty()) {
                "None (100% Present)"
            } else {
                absentStudentsList.joinToString(", ") { "${it.rollNumber}. ${it.name}" }
            }

            val absentNotesList = absentStudentsList.mapNotNull { stu ->
                val note = remarks[stu.id]?.trim()
                if (!note.isNullOrBlank()) {
                    "${stu.name}: $note"
                } else null
            }

            val absentNotes = if (absentNotesList.isEmpty()) {
                if (absentCount == 0) "All students present" else "No notes provided"
            } else {
                absentNotesList.joinToString(" • ")
            }

            val submissionRecord = AttendanceSubmissionRecord(
                id = "${classId}_$date",
                date = date,
                classId = classId,
                className = className,
                classTeacherId = teacherId,
                classTeacherName = teacherName,
                totalStudents = totalStudents,
                presentStudents = presentStudents,
                absentStudents = absentCount,
                absentStudentNames = absentStudentNames,
                absentNotes = absentNotes,
                submittedStatus = "SUBMITTED",
                submittedAt = System.currentTimeMillis()
            )

            val records = students.map { student ->
                val status = drafts[student.id] ?: AttendanceStatus.PRESENT
                val note = remarks[student.id]?.ifBlank { null }
                AttendanceRecord(
                    id = "${classId}_${student.id}_$date",
                    date = date,
                    studentId = student.id,
                    studentName = student.name,
                    rollNumber = student.rollNumber,
                    classId = classId,
                    status = status.name,
                    markedByTeacherId = teacherId,
                    remarks = note,
                    isSubmitted = true
                )
            }

            repository.submitAttendanceReport(submissionRecord, records)
            _message.value = "Attendance for $date successfully submitted to Principal!"
        }
    }

    // Homework Actions
    fun createHomework(title: String, subject: String, description: String, dueDate: String) {
        val profile = teacherProfile.value ?: return
        val classId = profile.assignedClassId
        if (classId == null) {
            _message.value = "You must be assigned to a class before creating homework."
            return
        }

        viewModelScope.launch {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val homework = Homework(
                id = UUID.randomUUID().toString(),
                classId = classId,
                teacherId = teacherId,
                teacherName = profile.name,
                subject = subject.trim().ifBlank { profile.subject ?: "General" },
                title = title.trim(),
                description = description.trim(),
                assignedDate = todayStr,
                dueDate = dueDate.trim(),
                status = "ACTIVE"
            )
            repository.insertHomework(homework)
            _message.value = "Homework assignment created."
        }
    }

    fun deleteHomework(id: String) {
        viewModelScope.launch {
            repository.deleteHomework(id)
            _message.value = "Homework removed."
        }
    }

    // Marks Actions
    fun recordMark(
        student: Student,
        examName: String,
        subject: String,
        maxMarks: Int,
        obtained: Double,
        remarks: String
    ) {
        viewModelScope.launch {
            val percentage = (obtained / maxMarks) * 100.0
            val grade = when {
                percentage >= 90 -> "A+"
                percentage >= 80 -> "A"
                percentage >= 70 -> "B+"
                percentage >= 60 -> "B"
                percentage >= 50 -> "C"
                percentage >= 40 -> "D"
                else -> "F"
            }
            val mark = StudentMark(
                id = UUID.randomUUID().toString(),
                studentId = student.id,
                studentName = student.name,
                rollNumber = student.rollNumber,
                classId = student.classId,
                examName = examName.trim(),
                subject = subject.trim(),
                maxMarks = maxMarks,
                marksObtained = obtained,
                grade = grade,
                remarks = remarks.trim().ifBlank { null },
                date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            )
            repository.insertMark(mark)
            _message.value = "Marks saved for ${student.name} (Grade: $grade)."
        }
    }

    fun deleteMark(id: String) {
        viewModelScope.launch {
            repository.deleteMark(id)
            _message.value = "Mark record removed."
        }
    }

    // Leave Actions
    fun applyLeave(leaveType: LeaveType, startDate: String, endDate: String, days: Int, reason: String) {
        val profile = teacherProfile.value ?: return
        viewModelScope.launch {
            val leave = LeaveRequest(
                id = UUID.randomUUID().toString(),
                teacherId = teacherId,
                teacherName = profile.name,
                leaveType = leaveType.name,
                startDate = startDate.trim(),
                endDate = endDate.trim(),
                daysCount = days,
                reason = reason.trim(),
                status = LeaveStatus.PENDING.name,
                principalComment = null
            )
            repository.insertLeaveRequest(leave)
            _message.value = "Leave application submitted to Principal for approval."
        }
    }

    fun logout() {
        repository.logout()
    }
}

class TeacherViewModelFactory(
    private val repository: SchoolRepository,
    private val teacherId: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TeacherViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TeacherViewModel(repository, teacherId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
