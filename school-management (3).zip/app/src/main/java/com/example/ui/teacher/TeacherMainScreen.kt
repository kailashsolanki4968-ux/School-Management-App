package com.example.ui.teacher

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Announcement
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.LeaveType
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.ui.principal.AnnouncementItemCard
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusAbsentBg
import com.example.ui.theme.StatusExcused
import com.example.ui.theme.StatusExcusedBg
import com.example.ui.theme.StatusLate
import com.example.ui.theme.StatusLateBg
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.StatusPresentBg
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherMainScreen(
    viewModel: TeacherViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val profile by viewModel.teacherProfile.collectAsStateWithLifecycle()
    val assignedClass by viewModel.assignedClass.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isTablet = maxWidth >= 720.dp

        if (isTablet) {
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Teacher",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    },
                    modifier = Modifier.fillMaxHeight()
                ) {
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.ATTENDANCE,
                        onClick = { viewModel.selectTab(TeacherTab.ATTENDANCE) },
                        icon = { Icon(Icons.Default.HowToReg, contentDescription = "Attendance") },
                        label = { Text("Attendance") }
                    )
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.STUDENTS,
                        onClick = { viewModel.selectTab(TeacherTab.STUDENTS) },
                        icon = { Icon(Icons.Default.Group, contentDescription = "Students") },
                        label = { Text("My Class") }
                    )
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.HOMEWORK,
                        onClick = { viewModel.selectTab(TeacherTab.HOMEWORK) },
                        icon = { Icon(Icons.Default.Assignment, contentDescription = "Homework") },
                        label = { Text("Homework") }
                    )
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.MARKS,
                        onClick = { viewModel.selectTab(TeacherTab.MARKS) },
                        icon = { Icon(Icons.Default.Grade, contentDescription = "Marks") },
                        label = { Text("Marks") }
                    )
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.LEAVES,
                        onClick = { viewModel.selectTab(TeacherTab.LEAVES) },
                        icon = { Icon(Icons.Default.EventNote, contentDescription = "Leaves") },
                        label = { Text("Leaves") }
                    )
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.ANNOUNCEMENTS,
                        onClick = { viewModel.selectTab(TeacherTab.ANNOUNCEMENTS) },
                        icon = { Icon(Icons.Default.Campaign, contentDescription = "Notices") },
                        label = { Text("Notices") }
                    )
                    NavigationRailItem(
                        selected = currentTab == TeacherTab.PROFILE,
                        onClick = { viewModel.selectTab(TeacherTab.PROFILE) },
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("Profile") }
                    )
                }

                Scaffold(
                    topBar = {
                        TeacherTopAppBar(
                            profile = profile,
                            assignedClass = assignedClass,
                            onLogout = { viewModel.logout() }
                        )
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    TeacherTabContent(
                        currentTab = currentTab,
                        viewModel = viewModel,
                        profile = profile,
                        assignedClass = assignedClass,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        } else {
            // Phone Layout
            Scaffold(
                topBar = {
                    TeacherTopAppBar(
                        profile = profile,
                        assignedClass = assignedClass,
                        onLogout = { viewModel.logout() }
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
                        NavigationBarItem(
                            selected = currentTab == TeacherTab.ATTENDANCE,
                            onClick = { viewModel.selectTab(TeacherTab.ATTENDANCE) },
                            icon = { Icon(Icons.Default.HowToReg, contentDescription = "Attendance") },
                            label = { Text("Attendance", fontSize = 10.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == TeacherTab.STUDENTS,
                            onClick = { viewModel.selectTab(TeacherTab.STUDENTS) },
                            icon = { Icon(Icons.Default.Group, contentDescription = "Class") },
                            label = { Text("Students", fontSize = 10.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == TeacherTab.HOMEWORK,
                            onClick = { viewModel.selectTab(TeacherTab.HOMEWORK) },
                            icon = { Icon(Icons.Default.Assignment, contentDescription = "Homework") },
                            label = { Text("Homework", fontSize = 10.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == TeacherTab.MARKS,
                            onClick = { viewModel.selectTab(TeacherTab.MARKS) },
                            icon = { Icon(Icons.Default.Grade, contentDescription = "Marks") },
                            label = { Text("Marks", fontSize = 10.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab in listOf(TeacherTab.LEAVES, TeacherTab.ANNOUNCEMENTS, TeacherTab.PROFILE),
                            onClick = {
                                if (currentTab !in listOf(TeacherTab.LEAVES, TeacherTab.ANNOUNCEMENTS, TeacherTab.PROFILE)) {
                                    viewModel.selectTab(TeacherTab.LEAVES)
                                }
                            },
                            icon = { Icon(Icons.Default.EventNote, contentDescription = "More") },
                            label = { Text("More", fontSize = 10.sp) }
                        )
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                TeacherTabContent(
                    currentTab = currentTab,
                    viewModel = viewModel,
                    profile = profile,
                    assignedClass = assignedClass,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherTopAppBar(
    profile: UserAccount?,
    assignedClass: SchoolClass?,
    onLogout: () -> Unit
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = profile?.name ?: "Teacher Portal",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = if (assignedClass != null) "Class: ${assignedClass.name} (${assignedClass.roomNumber})" else "No Assigned Class",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (assignedClass != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        },
        actions = {
            IconButton(onClick = onLogout, modifier = Modifier.testTag("btn_logout")) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = "Logout",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun TeacherTabContent(
    currentTab: TeacherTab,
    viewModel: TeacherViewModel,
    profile: UserAccount?,
    assignedClass: SchoolClass?,
    modifier: Modifier = Modifier
) {
    val isSecondaryTab = currentTab in listOf(
        TeacherTab.LEAVES,
        TeacherTab.ANNOUNCEMENTS,
        TeacherTab.PROFILE
    )

    Column(modifier = modifier.fillMaxSize()) {
        if (isSecondaryTab) {
            TabRow(
                selectedTabIndex = when (currentTab) {
                    TeacherTab.LEAVES -> 0
                    TeacherTab.ANNOUNCEMENTS -> 1
                    TeacherTab.PROFILE -> 2
                    else -> 0
                },
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = currentTab == TeacherTab.LEAVES,
                    onClick = { viewModel.selectTab(TeacherTab.LEAVES) },
                    text = { Text("My Leaves", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == TeacherTab.ANNOUNCEMENTS,
                    onClick = { viewModel.selectTab(TeacherTab.ANNOUNCEMENTS) },
                    text = { Text("Notices", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == TeacherTab.PROFILE,
                    onClick = { viewModel.selectTab(TeacherTab.PROFILE) },
                    text = { Text("Profile", fontSize = 12.sp) }
                )
            }
        }

        if (assignedClass == null && currentTab != TeacherTab.LEAVES && currentTab != TeacherTab.ANNOUNCEMENTS && currentTab != TeacherTab.PROFILE) {
            UnassignedClassNotice(profile = profile)
        } else {
            when (currentTab) {
                TeacherTab.ATTENDANCE -> TeacherAttendanceView(viewModel, assignedClass)
                TeacherTab.STUDENTS -> TeacherStudentsView(viewModel, assignedClass)
                TeacherTab.HOMEWORK -> TeacherHomeworkView(viewModel, assignedClass)
                TeacherTab.MARKS -> TeacherMarksView(viewModel, assignedClass)
                TeacherTab.LEAVES -> TeacherLeavesView(viewModel)
                TeacherTab.ANNOUNCEMENTS -> TeacherAnnouncementsView(viewModel)
                TeacherTab.PROFILE -> TeacherProfileView(viewModel, profile, assignedClass)
            }
        }
    }
}

@Composable
fun UnassignedClassNotice(profile: UserAccount?) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Class Assigned Yet",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Hello ${profile?.name ?: "Teacher"}, your account is approved, but the Principal has not yet assigned a class to your profile. Please contact the Principal to assign your class.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

// ---------------- TEACHER ATTENDANCE VIEW ----------------

@Composable
fun TeacherAttendanceView(
    viewModel: TeacherViewModel,
    assignedClass: SchoolClass?
) {
    val students by viewModel.classStudents.collectAsStateWithLifecycle()
    val drafts by viewModel.attendanceDrafts.collectAsStateWithLifecycle()
    val remarks by viewModel.remarksDrafts.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val currentSubmission by viewModel.currentSubmission.collectAsStateWithLifecycle()
    val pastSubmissions by viewModel.pastSubmissions.collectAsStateWithLifecycle()

    var showHistoryDialog by remember { mutableStateOf(false) }

    val presentCount = students.count { (drafts[it.id] ?: AttendanceStatus.PRESENT) == AttendanceStatus.PRESENT }
    val absentCount = students.count { (drafts[it.id] ?: AttendanceStatus.PRESENT) == AttendanceStatus.ABSENT }
    val lateCount = students.count { (drafts[it.id] ?: AttendanceStatus.PRESENT) == AttendanceStatus.LATE }
    val excusedCount = students.count { (drafts[it.id] ?: AttendanceStatus.PRESENT) == AttendanceStatus.EXCUSED }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header stats and controls
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Class Attendance: ${assignedClass?.name ?: ""}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Date: $selectedDate • ${students.size} Students Enrolled",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { showHistoryDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.History, contentDescription = "History", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("History", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { viewModel.markAllPresent() },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("All Present", fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(StatusPresentBg)
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Present: $presentCount", color = StatusPresent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(StatusAbsentBg)
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Absent: $absentCount", color = StatusAbsent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(StatusLateBg)
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Late: $lateCount", color = StatusLate, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        if (excusedCount > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(StatusExcusedBg)
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Excused: $excusedCount", color = StatusExcused, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Submission Status Banner if submitted
            currentSubmission?.let { sub ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = StatusPresent,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Status: ${sub.submittedStatus} to Principal",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = StatusPresent)
                                )
                            }
                            Text(
                                text = "Date: ${sub.date}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Teacher: ${sub.classTeacherName} • Class: ${sub.className}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Summary: Total ${sub.totalStudents} | Present ${sub.presentStudents} | Absent ${sub.absentStudents}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        if (sub.absentStudents > 0) {
                            Text(
                                text = "Absentees: ${sub.absentStudentNames}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                            )
                            if (sub.absentNotes.isNotBlank() && sub.absentNotes != "No notes provided") {
                                Text(
                                    text = "Notes: ${sub.absentNotes}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (students.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No students in this class.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(students, key = { it.id }) { student ->
                        val currentStatus = drafts[student.id] ?: AttendanceStatus.PRESENT
                        val currentRemark = remarks[student.id] ?: ""

                        StudentAttendanceRow(
                            student = student,
                            status = currentStatus,
                            remark = currentRemark,
                            onStatusChange = { newStatus -> viewModel.setStudentStatus(student.id, newStatus) },
                            onRemarkChange = { newRemark -> viewModel.setStudentRemark(student.id, newRemark) }
                        )
                    }
                }
            }
        }

        // Submit Attendance to Principal Floating Action Button
        ExtendedFloatingActionButton(
            onClick = { viewModel.submitAttendanceToPrincipal() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("btn_submit_attendance"),
            icon = { Icon(Icons.Default.Send, contentDescription = null) },
            text = { Text("Submit to Principal", fontWeight = FontWeight.Bold) },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )

        // History Dialog
        if (showHistoryDialog) {
            AttendanceHistoryDialog(
                submissions = pastSubmissions,
                onDismiss = { showHistoryDialog = false }
            )
        }
    }
}

@Composable
fun AttendanceHistoryDialog(
    submissions: List<AttendanceSubmissionRecord>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Attendance History Records", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            if (submissions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No submitted attendance records yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(submissions, key = { it.id }) { sub ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "Date: ${sub.date}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(StatusPresentBg)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = sub.submittedStatus, color = StatusPresent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Class: ${sub.className} • Teacher: ${sub.classTeacherName}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Total: ${sub.totalStudents} | Present: ${sub.presentStudents} | Absent: ${sub.absentStudents}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (sub.absentStudents > 0) {
                                    Text(
                                        text = "Absent: ${sub.absentStudentNames}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        text = "Notes: ${sub.absentNotes}",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun StudentAttendanceRow(
    student: Student,
    status: AttendanceStatus,
    remark: String,
    onStatusChange: (AttendanceStatus) -> Unit,
    onRemarkChange: (String) -> Unit
) {
    var showRemarkField by remember { mutableStateOf(remark.isNotBlank()) }

    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = student.rollNumber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = student.name,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                // 4 Status Action Chips: Present (P), Absent (A), Late (L), Excused (E)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    AttendanceChip(
                        label = "P",
                        isSelected = status == AttendanceStatus.PRESENT,
                        color = StatusPresent,
                        bgColor = StatusPresentBg,
                        onClick = { onStatusChange(AttendanceStatus.PRESENT) }
                    )
                    AttendanceChip(
                        label = "A",
                        isSelected = status == AttendanceStatus.ABSENT,
                        color = StatusAbsent,
                        bgColor = StatusAbsentBg,
                        onClick = {
                            onStatusChange(AttendanceStatus.ABSENT)
                            showRemarkField = true
                        }
                    )
                    AttendanceChip(
                        label = "L",
                        isSelected = status == AttendanceStatus.LATE,
                        color = StatusLate,
                        bgColor = StatusLateBg,
                        onClick = {
                            onStatusChange(AttendanceStatus.LATE)
                            showRemarkField = true
                        }
                    )
                    AttendanceChip(
                        label = "E",
                        isSelected = status == AttendanceStatus.EXCUSED,
                        color = StatusExcused,
                        bgColor = StatusExcusedBg,
                        onClick = {
                            onStatusChange(AttendanceStatus.EXCUSED)
                            showRemarkField = true
                        }
                    )
                }
            }

            // Note input if Absent, Late or requested
            if (showRemarkField || status == AttendanceStatus.ABSENT || status == AttendanceStatus.LATE) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = remark,
                    onValueChange = onRemarkChange,
                    label = { Text("Absent Note (e.g. Flu, Medical leave, Parent informed)", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AttendanceChip(
    label: String,
    isSelected: Boolean,
    color: Color,
    bgColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (isSelected) color else bgColor.copy(alpha = 0.6f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else color,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}

// ---------------- TEACHER STUDENTS VIEW ----------------

@Composable
fun TeacherStudentsView(
    viewModel: TeacherViewModel,
    assignedClass: SchoolClass?
) {
    val students by viewModel.classStudents.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = "Class Roster (${students.size} Students)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Grade: ${assignedClass?.name ?: ""} • ${assignedClass?.roomNumber ?: ""}",
            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (students.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No students in this class.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 60.dp)
            ) {
                items(students, key = { it.id }) { student ->
                    ElevatedCard(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = student.rollNumber,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = student.name,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = "Parent: ${student.parentName}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    Text(
                                        text = "Phone: ${student.parentPhone}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }

                            if (student.parentPhone.isNotBlank()) {
                                OutlinedButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_DIAL).apply {
                                            data = Uri.parse("tel:${student.parentPhone.replace(" ", "")}")
                                        }
                                        try { context.startActivity(intent) } catch (_: Exception) {}
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Call", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- TEACHER HOMEWORK VIEW ----------------

@Composable
fun TeacherHomeworkView(
    viewModel: TeacherViewModel,
    assignedClass: SchoolClass?
) {
    val homeworkList by viewModel.homeworkList.collectAsStateWithLifecycle()
    var showCreateHomeworkDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Class Homework (${homeworkList.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Assigned to ${assignedClass?.name ?: ""}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
                Button(
                    onClick = { showCreateHomeworkDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Assign")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (homeworkList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No homework assigned yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(homeworkList, key = { it.id }) { hw ->
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = hw.subject,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteHomework(hw.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = hw.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = hw.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Due Date: ${hw.dueDate}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showCreateHomeworkDialog) {
            CreateHomeworkDialog(
                onDismiss = { showCreateHomeworkDialog = false },
                onAdd = { title, subject, desc, dueDate ->
                    viewModel.createHomework(title, subject, desc, dueDate)
                    showCreateHomeworkDialog = false
                }
            )
        }
    }
}

@Composable
fun CreateHomeworkDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, subject: String, desc: String, dueDate: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("Mathematics") }
    var desc by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("Tomorrow 9:00 AM") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assign New Homework", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Math, Physics)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Homework Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Instructions & Page Numbers") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("Due Date / Time") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && desc.isNotBlank()) {
                        onAdd(title, subject, desc, dueDate)
                    }
                }
            ) {
                Text("Assign Homework")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- TEACHER MARKS & GRADES VIEW ----------------

@Composable
fun TeacherMarksView(
    viewModel: TeacherViewModel,
    assignedClass: SchoolClass?
) {
    val marks by viewModel.marksList.collectAsStateWithLifecycle()
    val students by viewModel.classStudents.collectAsStateWithLifecycle()

    var showAddMarkDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Student Marks & Grades (${marks.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Class: ${assignedClass?.name ?: ""}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
                Button(
                    onClick = { showAddMarkDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Enter Marks")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (marks.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No exam marks recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(marks, key = { it.id }) { mark ->
                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${mark.studentName} (Roll: ${mark.rollNumber})",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${mark.examName} • ${mark.subject}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    mark.remarks?.let {
                                        Text(
                                            text = "Note: $it",
                                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${mark.marksObtained} / ${mark.maxMarks}",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "Grade ${mark.grade}",
                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { viewModel.deleteMark(mark.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAddMarkDialog) {
            AddStudentMarkDialog(
                students = students,
                onDismiss = { showAddMarkDialog = false },
                onSave = { student, exam, subject, maxMarks, obtained, remarks ->
                    viewModel.recordMark(student, exam, subject, maxMarks, obtained, remarks)
                    showAddMarkDialog = false
                }
            )
        }
    }
}

@Composable
fun AddStudentMarkDialog(
    students: List<Student>,
    onDismiss: () -> Unit,
    onSave: (student: Student, exam: String, subject: String, maxMarks: Int, obtained: Double, remarks: String) -> Unit
) {
    var selectedStudent by remember { mutableStateOf(students.firstOrNull()) }
    var examName by remember { mutableStateOf("Mid-Term Examination") }
    var subject by remember { mutableStateOf("Mathematics") }
    var maxMarksStr by remember { mutableStateOf("100") }
    var obtainedMarksStr by remember { mutableStateOf("85.0") }
    var remarks by remember { mutableStateOf("Good progress") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Student Mark", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Select Student:", style = MaterialTheme.typography.labelMedium)
                students.forEach { st ->
                    FilterChip(
                        selected = selectedStudent?.id == st.id,
                        onClick = { selectedStudent = st },
                        label = { Text("${st.rollNumber} - ${st.name}") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = examName,
                    onValueChange = { examName = it },
                    label = { Text("Exam Name (e.g. Mid-Term, Unit Test 1)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = obtainedMarksStr,
                        onValueChange = { obtainedMarksStr = it },
                        label = { Text("Marks Scored") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = maxMarksStr,
                        onValueChange = { maxMarksStr = it },
                        label = { Text("Max Marks") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Feedback / Remarks") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val st = selectedStudent
                    val maxM = maxMarksStr.toIntOrNull() ?: 100
                    val obt = obtainedMarksStr.toDoubleOrNull() ?: 0.0
                    if (st != null && examName.isNotBlank() && subject.isNotBlank()) {
                        onSave(st, examName, subject, maxM, obt, remarks)
                    }
                }
            ) {
                Text("Save Grade")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- TEACHER LEAVES VIEW ----------------

@Composable
fun TeacherLeavesView(viewModel: TeacherViewModel) {
    val leaves by viewModel.leaveRequests.collectAsStateWithLifecycle()
    var showApplyLeaveDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "My Leave Applications (${leaves.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Button(
                    onClick = { showApplyLeaveDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Apply Leave")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (leaves.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No leave requests submitted.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(leaves, key = { it.id }) { leave ->
                        val statusColor = when (leave.status) {
                            "APPROVED" -> StatusPresent
                            "REJECTED" -> StatusAbsent
                            else -> StatusLate
                        }

                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${leave.leaveType} Leave (${leave.daysCount} Days)",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(statusColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = leave.status,
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Dates: ${leave.startDate} to ${leave.endDate}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Reason: ${leave.reason}",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                leave.principalComment?.let { comment ->
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "Principal Note: $comment",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary),
                                            modifier = Modifier.padding(8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showApplyLeaveDialog) {
            ApplyLeaveDialog(
                onDismiss = { showApplyLeaveDialog = false },
                onApply = { type, start, end, days, reason ->
                    viewModel.applyLeave(type, start, end, days, reason)
                    showApplyLeaveDialog = false
                }
            )
        }
    }
}

@Composable
fun ApplyLeaveDialog(
    onDismiss: () -> Unit,
    onApply: (type: LeaveType, start: String, end: String, days: Int, reason: String) -> Unit
) {
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    var leaveType by remember { mutableStateOf(LeaveType.CASUAL) }
    var startDate by remember { mutableStateOf(todayStr) }
    var endDate by remember { mutableStateOf(todayStr) }
    var daysStr by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Apply for Leave", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Leave Type:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = leaveType == LeaveType.CASUAL,
                        onClick = { leaveType = LeaveType.CASUAL },
                        label = { Text("Casual", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = leaveType == LeaveType.SICK,
                        onClick = { leaveType = LeaveType.SICK },
                        label = { Text("Sick", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = leaveType == LeaveType.EMERGENCY,
                        onClick = { leaveType = LeaveType.EMERGENCY },
                        label = { Text("Emergency", fontSize = 11.sp) }
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("Start Date") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("End Date") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = daysStr,
                    onValueChange = { daysStr = it },
                    label = { Text("Number of Days") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason for Leave") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val days = daysStr.toIntOrNull() ?: 1
                    if (reason.isNotBlank()) {
                        onApply(leaveType, startDate, endDate, days, reason)
                    }
                }
            ) {
                Text("Submit Application")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- TEACHER ANNOUNCEMENTS VIEW ----------------

@Composable
fun TeacherAnnouncementsView(viewModel: TeacherViewModel) {
    val announcements by viewModel.announcements.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = "School & Class Announcements (${announcements.size})",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (announcements.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No announcements for your class.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 60.dp)
            ) {
                items(announcements, key = { it.id }) { ann ->
                    AnnouncementItemCard(announcement = ann, onDelete = null)
                }
            }
        }
    }
}

// ---------------- TEACHER PROFILE VIEW ----------------

@Composable
fun TeacherProfileView(
    viewModel: TeacherViewModel,
    profile: UserAccount?,
    assignedClass: SchoolClass?
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = profile?.name ?: "Teacher",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Teacher ID: ${profile?.id ?: ""} • ${profile?.subject ?: "General"}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "Class: ${assignedClass?.name ?: "None Assigned"}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                            )
                        }
                    }
                }
            }
        }

        item {
            ElevatedCard(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Account & Privacy Details",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text("• Email: ${profile?.email ?: "Not set"}", style = MaterialTheme.typography.bodySmall)
                    Text("• Phone: ${profile?.phone ?: "Not set"}", style = MaterialTheme.typography.bodySmall)
                    Text("• Security Question: ${profile?.securityQuestion ?: ""}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "• Role Restriction: You have access strictly to your assigned class records.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Logout from Teacher Portal")
            }
        }
    }
}
