package com.example.ui.principal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.LeaveStatus
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.data.session.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class PrincipalTab {
    DASHBOARD,
    TEACHERS,
    CLASSES_STUDENTS,
    ATTENDANCE,
    ACADEMICS,
    LEAVES,
    ANNOUNCEMENTS,
    SETTINGS
}

data class AttendanceSummary(
    val totalEnrolled: Int = 0,
    val presentCount: Int = 0,
    val absentCount: Int = 0,
    val lateCount: Int = 0,
    val excusedCount: Int = 0,
    val attendancePercentage: Double = 0.0
)

class PrincipalViewModel(private val repository: SchoolRepository) : ViewModel() {

    val sessionState: StateFlow<UserSession?> = repository.sessionState

    private val _currentTab = MutableStateFlow(PrincipalTab.DASHBOARD)
    val currentTab: StateFlow<PrincipalTab> = _currentTab.asStateFlow()

    private val _selectedDate = MutableStateFlow(
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    )
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _selectedClassId = MutableStateFlow<String?>(null)
    val selectedClassId: StateFlow<String?> = _selectedClassId.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    // Teachers
    val allTeachers: StateFlow<List<UserAccount>> = repository.getAllTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingTeachers: StateFlow<List<UserAccount>> = repository.getPendingTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val approvedTeachers: StateFlow<List<UserAccount>> = repository.getApprovedTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Classes & Students
    val allClasses: StateFlow<List<SchoolClass>> = repository.getAllClasses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStudents: StateFlow<List<Student>> = repository.getAllStudents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedClassStudents: StateFlow<List<Student>> = _selectedClassId
        .flatMapLatest { classId ->
            if (classId != null) repository.getStudentsByClass(classId)
            else repository.getAllStudents()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Attendance
    val todayAttendanceRecords: StateFlow<List<AttendanceRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAllAttendanceByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayAbsentStudents: StateFlow<List<AttendanceRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAbsentStudentsByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAttendanceSubmissions: StateFlow<List<AttendanceSubmissionRecord>> = repository.getAllAttendanceSubmissions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedDateSubmissions: StateFlow<List<AttendanceSubmissionRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAttendanceSubmissionsByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendanceSummary: StateFlow<AttendanceSummary> = combine(
        allStudents,
        todayAttendanceRecords
    ) { students, records ->
        val total = students.size
        val present = records.count { it.status == "PRESENT" }
        val absent = records.count { it.status == "ABSENT" }
        val late = records.count { it.status == "LATE" }
        val excused = records.count { it.status == "EXCUSED" }
        val pct = if (total > 0 && records.isNotEmpty()) {
            ((present + late).toDouble() / total.toDouble()) * 100.0
        } else {
            0.0
        }
        AttendanceSummary(
            totalEnrolled = total,
            presentCount = present,
            absentCount = absent,
            lateCount = late,
            excusedCount = excused,
            attendancePercentage = pct
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AttendanceSummary())

    // Academics
    val allHomework: StateFlow<List<Homework>> = repository.getAllHomework()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMarks: StateFlow<List<StudentMark>> = repository.getAllMarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Announcements
    val allAnnouncements: StateFlow<List<Announcement>> = repository.getAllAnnouncements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Leaves
    val allLeaves: StateFlow<List<LeaveRequest>> = repository.getAllLeaveRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingLeaves: StateFlow<List<LeaveRequest>> = repository.getPendingLeaveRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: PrincipalTab) {
        _currentTab.value = tab
    }

    fun selectDate(date: String) {
        _selectedDate.value = date
    }

    fun selectClass(classId: String?) {
        _selectedClassId.value = classId
    }

    fun clearMessage() {
        _message.value = null
    }

    // Teacher Management
    fun addTeacher(
        name: String,
        email: String,
        phone: String,
        subject: String,
        customId: String?,
        password: String
    ) {
        viewModelScope.launch {
            val id = customId?.trim()?.ifEmpty { null }
                ?: ("TCH_" + System.currentTimeMillis().toString().takeLast(4))

            val teacher = UserAccount(
                id = id,
                name = name.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = UserRole.TEACHER.name,
                passwordHash = password.trim().ifEmpty { "teacher123" },
                securityQuestion = "What is your primary school?",
                securityAnswer = "Greenwood",
                status = AccountStatus.APPROVED.name,
                assignedClassId = null,
                subject = subject.trim()
            )
            val res = repository.registerUser(teacher)
            if (res.isSuccess) {
                _message.value = "Teacher account '${teacher.name}' ($id) added successfully."
            } else {
                _message.value = res.exceptionOrNull()?.message ?: "Failed to add teacher."
            }
        }
    }

    fun approveTeacher(teacherId: String) {
        viewModelScope.launch {
            repository.updateTeacherStatus(teacherId, AccountStatus.APPROVED.name)
            _message.value = "Teacher account '$teacherId' approved."
        }
    }

    fun rejectTeacher(teacherId: String) {
        viewModelScope.launch {
            repository.updateTeacherStatus(teacherId, AccountStatus.REJECTED.name)
            _message.value = "Teacher registration '$teacherId' rejected."
        }
    }

    fun assignClassTeacher(teacherId: String, classId: String?) {
        viewModelScope.launch {
            repository.updateTeacherClass(teacherId, classId)
            _message.value = "Class assignment updated."
        }
    }

    fun resetTeacherPassword(teacherId: String, newPass: String) {
        viewModelScope.launch {
            repository.directUpdatePassword(teacherId, newPass)
            _message.value = "Password updated for teacher '$teacherId'."
        }
    }

    fun deleteTeacher(teacherId: String) {
        viewModelScope.launch {
            repository.deleteTeacher(teacherId)
            _message.value = "Teacher deleted."
        }
    }

    // Class Management
    fun addClass(name: String, grade: String, section: String, room: String, classTeacherId: String?) {
        viewModelScope.launch {
            val id = "CLASS_" + grade.replace(" ", "") + section.replace(" ", "")
            val schoolClass = SchoolClass(
                id = id,
                name = name.trim(),
                grade = grade.trim(),
                section = section.trim(),
                classTeacherId = classTeacherId,
                roomNumber = room.trim().ifEmpty { "Room 101" }
            )
            repository.insertClass(schoolClass)
            _message.value = "Class '$name' created successfully."
        }
    }

    fun deleteClass(classId: String) {
        viewModelScope.launch {
            repository.deleteClass(classId)
            _message.value = "Class deleted."
        }
    }

    // Student Management
    fun addStudent(
        rollNo: String,
        name: String,
        classId: String,
        gender: String,
        parentName: String,
        parentPhone: String,
        emergency: String,
        address: String
    ) {
        viewModelScope.launch {
            val id = "STU_" + System.currentTimeMillis().toString().takeLast(6)
            val student = Student(
                id = id,
                rollNumber = rollNo.trim(),
                name = name.trim(),
                classId = classId,
                gender = gender,
                parentName = parentName.trim(),
                parentPhone = parentPhone.trim(),
                emergencyContact = emergency.trim(),
                address = address.trim()
            )
            repository.insertStudent(student)
            _message.value = "Student '$name' enrolled."
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch {
            repository.deleteStudent(studentId)
            _message.value = "Student removed."
        }
    }

    // Announcements
    fun sendAnnouncement(title: String, content: String, targetAudience: String, priority: AnnouncementPriority) {
        viewModelScope.launch {
            val author = sessionState.value?.name ?: "Principal"
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val announcement = Announcement(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                content = content.trim(),
                targetAudience = targetAudience,
                priority = priority.name,
                authorName = author,
                date = todayStr
            )
            repository.insertAnnouncement(announcement)
            _message.value = "Announcement published."
        }
    }

    fun deleteAnnouncement(id: String) {
        viewModelScope.launch {
            repository.deleteAnnouncement(id)
            _message.value = "Announcement deleted."
        }
    }

    // Leave Management
    fun approveLeave(leaveId: String, comment: String?) {
        viewModelScope.launch {
            repository.updateLeaveStatus(leaveId, LeaveStatus.APPROVED.name, comment?.trim())
            _message.value = "Leave request approved."
        }
    }

    fun rejectLeave(leaveId: String, comment: String?) {
        viewModelScope.launch {
            repository.updateLeaveStatus(leaveId, LeaveStatus.REJECTED.name, comment?.trim())
            _message.value = "Leave request rejected."
        }
    }

    fun logout() {
        repository.logout()
    }
}

class PrincipalViewModelFactory(private val repository: SchoolRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PrincipalViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PrincipalViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
