package com.example.ui.principal

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Verified
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusAbsentBg
import com.example.ui.theme.StatusLate
import com.example.ui.theme.StatusLateBg
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.StatusPresentBg
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalMainScreen(
    viewModel: PrincipalViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val pendingTeachers by viewModel.pendingTeachers.collectAsStateWithLifecycle()
    val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isTablet = maxWidth >= 720.dp

        if (isTablet) {
            // Tablet Navigation Rail Layout
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Principal",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    },
                    modifier = Modifier.fillMaxHeight()
                ) {
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.DASHBOARD,
                        onClick = { viewModel.selectTab(PrincipalTab.DASHBOARD) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                        label = { Text("Dashboard") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.TEACHERS,
                        onClick = { viewModel.selectTab(PrincipalTab.TEACHERS) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (pendingTeachers.isNotEmpty()) {
                                        Badge { Text("${pendingTeachers.size}") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Badge, contentDescription = "Teachers")
                            }
                        },
                        label = { Text("Teachers") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.CLASSES_STUDENTS,
                        onClick = { viewModel.selectTab(PrincipalTab.CLASSES_STUDENTS) },
                        icon = { Icon(Icons.Default.Class, contentDescription = "Classes") },
                        label = { Text("Classes") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.ATTENDANCE,
                        onClick = { viewModel.selectTab(PrincipalTab.ATTENDANCE) },
                        icon = { Icon(Icons.Default.HowToReg, contentDescription = "Attendance") },
                        label = { Text("Attendance") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.ACADEMICS,
                        onClick = { viewModel.selectTab(PrincipalTab.ACADEMICS) },
                        icon = { Icon(Icons.Default.Grade, contentDescription = "Academics") },
                        label = { Text("Academics") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.LEAVES,
                        onClick = { viewModel.selectTab(PrincipalTab.LEAVES) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (pendingLeaves.isNotEmpty()) {
                                        Badge { Text("${pendingLeaves.size}") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.EventNote, contentDescription = "Leaves")
                            }
                        },
                        label = { Text("Leaves") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.ANNOUNCEMENTS,
                        onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) },
                        icon = { Icon(Icons.Default.Campaign, contentDescription = "Announcements") },
                        label = { Text("Notices") }
                    )
                    NavigationRailItem(
                        selected = currentTab == PrincipalTab.SETTINGS,
                        onClick = { viewModel.selectTab(PrincipalTab.SETTINGS) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") }
                    )
                }

                // Content for Tablet
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = getPrincipalTabTitle(currentTab),
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Logged in as ${session?.name ?: "Principal"} (ID: ${session?.userId ?: ""})",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = { viewModel.logout() },
                                    modifier = Modifier.testTag("btn_logout")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ExitToApp,
                                        contentDescription = "Logout",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    PrincipalTabContent(
                        currentTab = currentTab,
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        } else {
            // Phone Layout with Bottom Navigation Bar
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = getPrincipalTabTitle(currentTab),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Principal: ${session?.name ?: "Admin"}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { viewModel.logout() },
                                modifier = Modifier.testTag("btn_logout")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = "Logout",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.DASHBOARD,
                            onClick = { viewModel.selectTab(PrincipalTab.DASHBOARD) },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                            label = { Text("Home", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.TEACHERS,
                            onClick = { viewModel.selectTab(PrincipalTab.TEACHERS) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (pendingTeachers.isNotEmpty()) {
                                            Badge { Text("${pendingTeachers.size}") }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Badge, contentDescription = "Teachers")
                                }
                            },
                            label = { Text("Teachers", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.CLASSES_STUDENTS,
                            onClick = { viewModel.selectTab(PrincipalTab.CLASSES_STUDENTS) },
                            icon = { Icon(Icons.Default.Class, contentDescription = "Classes") },
                            label = { Text("Classes", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.ATTENDANCE,
                            onClick = { viewModel.selectTab(PrincipalTab.ATTENDANCE) },
                            icon = { Icon(Icons.Default.HowToReg, contentDescription = "Attendance") },
                            label = { Text("Attendance", fontSize = 11.sp) }
                        )
                        NavigationBarItem(
                            selected = currentTab == PrincipalTab.LEAVES || currentTab == PrincipalTab.ACADEMICS || currentTab == PrincipalTab.ANNOUNCEMENTS || currentTab == PrincipalTab.SETTINGS,
                            onClick = {
                                if (currentTab !in listOf(PrincipalTab.LEAVES, PrincipalTab.ACADEMICS, PrincipalTab.ANNOUNCEMENTS, PrincipalTab.SETTINGS)) {
                                    viewModel.selectTab(PrincipalTab.LEAVES)
                                }
                            },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (pendingLeaves.isNotEmpty()) {
                                            Badge { Text("${pendingLeaves.size}") }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.EventNote, contentDescription = "More")
                                }
                            },
                            label = { Text("More", fontSize = 11.sp) }
                        )
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                PrincipalTabContent(
                    currentTab = currentTab,
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}

private fun getPrincipalTabTitle(tab: PrincipalTab): String {
    return when (tab) {
        PrincipalTab.DASHBOARD -> "School Dashboard"
        PrincipalTab.TEACHERS -> "Teacher Management"
        PrincipalTab.CLASSES_STUDENTS -> "Classes & Students"
        PrincipalTab.ATTENDANCE -> "Attendance Overview"
        PrincipalTab.ACADEMICS -> "Homework & Marks"
        PrincipalTab.LEAVES -> "Teacher Leave Requests"
        PrincipalTab.ANNOUNCEMENTS -> "School Announcements"
        PrincipalTab.SETTINGS -> "Settings & Security"
    }
}

@Composable
fun PrincipalTabContent(
    currentTab: PrincipalTab,
    viewModel: PrincipalViewModel,
    modifier: Modifier = Modifier
) {
    // Secondary sub-tab row for phone when on "More" tab (Leaves, Academics, Announcements, Settings)
    val isSecondaryTab = currentTab in listOf(
        PrincipalTab.LEAVES,
        PrincipalTab.ACADEMICS,
        PrincipalTab.ANNOUNCEMENTS,
        PrincipalTab.SETTINGS
    )

    Column(modifier = modifier.fillMaxSize()) {
        if (isSecondaryTab) {
            val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()
            TabRow(
                selectedTabIndex = when (currentTab) {
                    PrincipalTab.LEAVES -> 0
                    PrincipalTab.ACADEMICS -> 1
                    PrincipalTab.ANNOUNCEMENTS -> 2
                    PrincipalTab.SETTINGS -> 3
                    else -> 0
                },
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = currentTab == PrincipalTab.LEAVES,
                    onClick = { viewModel.selectTab(PrincipalTab.LEAVES) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Leaves", fontSize = 12.sp)
                            if (pendingLeaves.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.error)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "${pendingLeaves.size}",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                )
                Tab(
                    selected = currentTab == PrincipalTab.ACADEMICS,
                    onClick = { viewModel.selectTab(PrincipalTab.ACADEMICS) },
                    text = { Text("Academics", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == PrincipalTab.ANNOUNCEMENTS,
                    onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) },
                    text = { Text("Notices", fontSize = 12.sp) }
                )
                Tab(
                    selected = currentTab == PrincipalTab.SETTINGS,
                    onClick = { viewModel.selectTab(PrincipalTab.SETTINGS) },
                    text = { Text("Settings", fontSize = 12.sp) }
                )
            }
        }

        when (currentTab) {
            PrincipalTab.DASHBOARD -> PrincipalDashboardView(viewModel)
            PrincipalTab.TEACHERS -> PrincipalTeachersView(viewModel)
            PrincipalTab.CLASSES_STUDENTS -> PrincipalClassesStudentsView(viewModel)
            PrincipalTab.ATTENDANCE -> PrincipalAttendanceView(viewModel)
            PrincipalTab.ACADEMICS -> PrincipalAcademicsView(viewModel)
            PrincipalTab.LEAVES -> PrincipalLeavesView(viewModel)
            PrincipalTab.ANNOUNCEMENTS -> PrincipalAnnouncementsView(viewModel)
            PrincipalTab.SETTINGS -> PrincipalSettingsView(viewModel)
        }
    }
}

// ---------------- DASHBOARD VIEW ----------------

@Composable
fun PrincipalDashboardView(viewModel: PrincipalViewModel) {
    val teachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val pendingTeachers by viewModel.pendingTeachers.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val students by viewModel.allStudents.collectAsStateWithLifecycle()
    val attendanceSummary by viewModel.attendanceSummary.collectAsStateWithLifecycle()
    val absentStudents by viewModel.todayAbsentStudents.collectAsStateWithLifecycle()
    val announcements by viewModel.allAnnouncements.collectAsStateWithLifecycle()
    val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Pending action alerts
        if (pendingTeachers.isNotEmpty() || pendingLeaves.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Action Required",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (pendingTeachers.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectTab(PrincipalTab.TEACHERS) }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${pendingTeachers.size} new Teacher registration(s) awaiting your approval",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                )
                                Text(
                                    text = "Review >",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }
                        if (pendingLeaves.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectTab(PrincipalTab.LEAVES) }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• ${pendingLeaves.size} Teacher leave request(s) awaiting decision",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                )
                                Text(
                                    text = "Review >",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Summary KPI Cards Grid
        item {
            Text(
                text = "Key Metrics",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Students",
                    value = "${students.size}",
                    icon = Icons.Default.Group,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Active Classes",
                    value = "${classes.size}",
                    icon = Icons.Default.Class,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Total Teachers",
                    value = "${teachers.size}",
                    icon = Icons.Default.Badge,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Today's Attendance",
                    value = if (attendanceSummary.totalEnrolled > 0) String.format(Locale.US, "%.1f%%", attendanceSummary.attendancePercentage) else "N/A",
                    icon = Icons.Default.HowToReg,
                    color = if (attendanceSummary.attendancePercentage >= 85) StatusPresent else StatusLate,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Navigation Buttons
        item {
            Text(
                text = "Quick Actions",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.selectTab(PrincipalTab.TEACHERS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Teachers", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { viewModel.selectTab(PrincipalTab.CLASSES_STUDENTS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Class, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Classes", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Broadcast", fontSize = 12.sp)
                }
            }
        }

        // Absent Students Highlight
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Today's Absent Students (${absentStudents.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(onClick = { viewModel.selectTab(PrincipalTab.ATTENDANCE) }) {
                    Text("Full Roster >")
                }
            }

            if (absentStudents.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✅ All recorded students are present today or attendance not yet marked.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    absentStudents.take(5).forEach { record ->
                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(StatusAbsentBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "A",
                                            color = StatusAbsent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = record.studentName,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                                        )
                                        Text(
                                            text = "Class: ${record.classId} • Roll: ${record.rollNumber}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                        record.remarks?.let {
                                            Text(
                                                text = "Note: $it",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = MaterialTheme.colorScheme.error
                                                )
                                            )
                                        }
                                    }
                                }

                                // Quick Call parent button
                                OutlinedButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_DIAL).apply {
                                            data = Uri.parse("tel:5550192831")
                                        }
                                        try {
                                            context.startActivity(intent)
                                        } catch (_: Exception) {}
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Phone, contentDescription = "Call", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Contact", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent School Announcements
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Announcements",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(onClick = { viewModel.selectTab(PrincipalTab.ANNOUNCEMENTS) }) {
                    Text("View All >")
                }
            }

            if (announcements.isEmpty()) {
                Text(
                    text = "No active announcements.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    announcements.take(3).forEach { ann ->
                        AnnouncementItemCard(announcement = ann, onDelete = { viewModel.deleteAnnouncement(ann.id) })
                    }
                }
            }
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

// ---------------- TEACHERS MANAGEMENT VIEW ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalTeachersView(viewModel: PrincipalViewModel) {
    val allTeachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val pendingTeachers by viewModel.pendingTeachers.collectAsStateWithLifecycle()
    val approvedTeachers by viewModel.approvedTeachers.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()

    var filterMode by remember { mutableStateOf("ALL") } // ALL, PENDING, APPROVED
    var showAddTeacherDialog by remember { mutableStateOf(false) }
    var teacherToAssignClass by remember { mutableStateOf<UserAccount?>(null) }
    var teacherToResetPassword by remember { mutableStateOf<UserAccount?>(null) }

    val displayedTeachers = when (filterMode) {
        "PENDING" -> pendingTeachers
        "APPROVED" -> approvedTeachers
        else -> allTeachers
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filterMode == "ALL",
                    onClick = { filterMode = "ALL" },
                    label = { Text("All (${allTeachers.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
                FilterChip(
                    selected = filterMode == "PENDING",
                    onClick = { filterMode = "PENDING" },
                    label = { Text("Pending Approval (${pendingTeachers.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.errorContainer
                    )
                )
                FilterChip(
                    selected = filterMode == "APPROVED",
                    onClick = { filterMode = "APPROVED" },
                    label = { Text("Active (${approvedTeachers.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (displayedTeachers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No teachers found in this filter category.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(displayedTeachers, key = { it.id }) { teacher ->
                        TeacherManagementCard(
                            teacher = teacher,
                            classes = classes,
                            onApprove = { viewModel.approveTeacher(teacher.id) },
                            onReject = { viewModel.rejectTeacher(teacher.id) },
                            onAssignClass = { teacherToAssignClass = teacher },
                            onResetPassword = { teacherToResetPassword = teacher },
                            onDelete = { viewModel.deleteTeacher(teacher.id) }
                        )
                    }
                }
            }
        }

        // Add Teacher Floating Action Button
        ExtendedFloatingActionButton(
            onClick = { showAddTeacherDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("fab_add_teacher"),
            icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
            text = { Text("Add Teacher") },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )

        // Add Teacher Dialog
        if (showAddTeacherDialog) {
            AddTeacherDialog(
                onDismiss = { showAddTeacherDialog = false },
                onAdd = { name, email, phone, subject, id, pass ->
                    viewModel.addTeacher(name, email, phone, subject, id, pass)
                    showAddTeacherDialog = false
                }
            )
        }

        // Assign Class Teacher Dialog
        teacherToAssignClass?.let { teacher ->
            AssignClassDialog(
                teacher = teacher,
                classes = classes,
                onDismiss = { teacherToAssignClass = null },
                onAssign = { classId ->
                    viewModel.assignClassTeacher(teacher.id, classId)
                    teacherToAssignClass = null
                }
            )
        }

        // Reset Password Dialog
        teacherToResetPassword?.let { teacher ->
            ResetTeacherPasswordDialog(
                teacher = teacher,
                onDismiss = { teacherToResetPassword = null },
                onReset = { newPass ->
                    viewModel.resetTeacherPassword(teacher.id, newPass)
                    teacherToResetPassword = null
                }
            )
        }
    }
}

@Composable
fun TeacherManagementCard(
    teacher: UserAccount,
    classes: List<SchoolClass>,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onAssignClass: () -> Unit,
    onResetPassword: () -> Unit,
    onDelete: () -> Unit
) {
    val assignedClass = classes.find { it.id == teacher.assignedClassId }

    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = teacher.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Teacher ID: ${teacher.id} • ${teacher.subject ?: "General"}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // Status Badge
                when (teacher.status) {
                    AccountStatus.PENDING.name -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.errorContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Pending Approval",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    AccountStatus.APPROVED.name -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.tertiaryContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Active",
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    AccountStatus.REJECTED.name -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Rejected",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "Assigned Class: ${assignedClass?.name ?: "None"}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                )
                Text(
                    text = "Contact: ${teacher.phone}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), thickness = 0.5.dp)

            // Action Buttons
            if (teacher.status == AccountStatus.PENDING.name) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve Account")
                    }
                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Decline")
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onAssignClass,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Class, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Assign Class", fontSize = 12.sp)
                    }

                    Row {
                        IconButton(onClick = onResetPassword) {
                            Icon(
                                imageVector = Icons.Default.LockReset,
                                contentDescription = "Reset Password",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onDelete) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddTeacherDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, email: String, phone: String, subject: String, customId: String?, pass: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("Mathematics") }
    var customId by remember { mutableStateOf("TCH_" + System.currentTimeMillis().toString().takeLast(4)) }
    var password by remember { mutableStateOf("teacher123") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add New Teacher", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customId,
                    onValueChange = { customId = it },
                    label = { Text("Teacher ID (Unique)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Teacher Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Physics, Math)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Initial Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onAdd(name, email, phone, subject, customId, password)
                    }
                }
            ) {
                Text("Save Teacher")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignClassDialog(
    teacher: UserAccount,
    classes: List<SchoolClass>,
    onDismiss: () -> Unit,
    onAssign: (classId: String?) -> Unit
) {
    var selectedClassId by remember { mutableStateOf(teacher.assignedClassId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assign Class Teacher", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select class for ${teacher.name}:", style = MaterialTheme.typography.bodyMedium)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedClassId = null }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = selectedClassId == null,
                        onClick = { selectedClassId = null },
                        label = { Text("None (Unassigned)") }
                    )
                }

                classes.forEach { schoolClass ->
                    FilterChip(
                        selected = selectedClassId == schoolClass.id,
                        onClick = { selectedClassId = schoolClass.id },
                        label = { Text("${schoolClass.name} (${schoolClass.roomNumber})") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = { onAssign(selectedClassId) }) { Text("Save Assignment") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ResetTeacherPasswordDialog(
    teacher: UserAccount,
    onDismiss: () -> Unit,
    onReset: (newPassword: String) -> Unit
) {
    var newPassword by remember { mutableStateOf("teacher123") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reset Teacher Password", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Set a new password for ${teacher.name} (${teacher.id}):",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("New Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (newPassword.isNotBlank()) onReset(newPassword)
            }) {
                Text("Update Password")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- CLASSES & STUDENTS VIEW ----------------

@Composable
fun PrincipalClassesStudentsView(viewModel: PrincipalViewModel) {
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val teachers by viewModel.allTeachers.collectAsStateWithLifecycle()
    val students by viewModel.allStudents.collectAsStateWithLifecycle()
    val selectedClassId by viewModel.selectedClassId.collectAsStateWithLifecycle()

    var showAddClassDialog by remember { mutableStateOf(false) }
    var showAddStudentDialog by remember { mutableStateOf(false) }

    val currentClass = classes.find { it.id == selectedClassId }
    val displayedStudents = if (selectedClassId != null) {
        students.filter { it.classId == selectedClassId }
    } else {
        students
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Horizontal Class Selector Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedClassId == null,
                        onClick = { viewModel.selectClass(null) },
                        label = { Text("All Classes (${students.size} students)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
                items(classes) { schoolClass ->
                    val classStudentCount = students.count { it.classId == schoolClass.id }
                    FilterChip(
                        selected = selectedClassId == schoolClass.id,
                        onClick = { viewModel.selectClass(schoolClass.id) },
                        label = { Text("${schoolClass.name} ($classStudentCount)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Class details banner if selected
            currentClass?.let { cls ->
                val classTeacher = teachers.find { it.id == cls.classTeacherId }
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = cls.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Class Teacher: ${classTeacher?.name ?: "Unassigned"} • ${cls.roomNumber}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                        IconButton(onClick = { viewModel.deleteClass(cls.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Class", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Students List Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Enrolled Students (${displayedStudents.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { showAddClassDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Class", fontSize = 12.sp)
                    }
                    Button(
                        onClick = { showAddStudentDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Student", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (displayedStudents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No students enrolled in this class yet.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(displayedStudents, key = { it.id }) { student ->
                        StudentItemCard(
                            student = student,
                            onDelete = { viewModel.deleteStudent(student.id) }
                        )
                    }
                }
            }
        }

        // Add Class Dialog
        if (showAddClassDialog) {
            AddClassDialog(
                teachers = teachers,
                onDismiss = { showAddClassDialog = false },
                onAdd = { name, grade, section, room, teacherId ->
                    viewModel.addClass(name, grade, section, room, teacherId)
                    showAddClassDialog = false
                }
            )
        }

        // Add Student Dialog
        if (showAddStudentDialog) {
            AddStudentDialog(
                classes = classes,
                defaultClassId = selectedClassId,
                onDismiss = { showAddStudentDialog = false },
                onAdd = { roll, name, classId, gender, parent, phone, emergency, address ->
                    viewModel.addStudent(roll, name, classId, gender, parent, phone, emergency, address)
                    showAddStudentDialog = false
                }
            )
        }
    }
}

@Composable
fun StudentItemCard(
    student: Student,
    onDelete: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = student.rollNumber,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = student.name,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = "Class: ${student.classId} • Parent: ${student.parentName} (${student.parentPhone})",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AddClassDialog(
    teachers: List<UserAccount>,
    onDismiss: () -> Unit,
    onAdd: (name: String, grade: String, section: String, room: String, teacherId: String?) -> Unit
) {
    var grade by remember { mutableStateOf("Grade 11") }
    var section by remember { mutableStateOf("A") }
    var room by remember { mutableStateOf("Room 205") }
    var selectedTeacherId by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Class", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = grade,
                    onValueChange = { grade = it },
                    label = { Text("Grade / Year (e.g. Grade 10)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = section,
                    onValueChange = { section = it },
                    label = { Text("Section (e.g. A, B)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("Room Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Assign Class Teacher (Optional):", style = MaterialTheme.typography.labelMedium)
                teachers.filter { it.status == AccountStatus.APPROVED.name }.forEach { teacher ->
                    FilterChip(
                        selected = selectedTeacherId == teacher.id,
                        onClick = {
                            selectedTeacherId = if (selectedTeacherId == teacher.id) null else teacher.id
                        },
                        label = { Text("${teacher.name} (${teacher.subject ?: ""})") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (grade.isNotBlank() && section.isNotBlank()) {
                        val name = "$grade - Section $section"
                        onAdd(name, grade, section, room, selectedTeacherId)
                    }
                }
            ) {
                Text("Create Class")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddStudentDialog(
    classes: List<SchoolClass>,
    defaultClassId: String?,
    onDismiss: () -> Unit,
    onAdd: (roll: String, name: String, classId: String, gender: String, parent: String, phone: String, emergency: String, address: String) -> Unit
) {
    var rollNo by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var selectedClassId by remember { mutableStateOf(defaultClassId ?: classes.firstOrNull()?.id ?: "CLASS_10A") }
    var gender by remember { mutableStateOf("Male") }
    var parentName by remember { mutableStateOf("") }
    var parentPhone by remember { mutableStateOf("") }
    var emergencyContact by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enroll New Student", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = rollNo,
                    onValueChange = { rollNo = it },
                    label = { Text("Roll Number (e.g. 107)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Student Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Select Class:", style = MaterialTheme.typography.labelMedium)
                classes.forEach { cls ->
                    FilterChip(
                        selected = selectedClassId == cls.id,
                        onClick = { selectedClassId = cls.id },
                        label = { Text(cls.name) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = gender == "Male",
                        onClick = { gender = "Male" },
                        label = { Text("Male") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = gender == "Female",
                        onClick = { gender = "Female" },
                        label = { Text("Female") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = parentName,
                    onValueChange = { parentName = it },
                    label = { Text("Parent / Guardian Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = parentPhone,
                    onValueChange = { parentPhone = it },
                    label = { Text("Parent Phone Number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = emergencyContact,
                    onValueChange = { emergencyContact = it },
                    label = { Text("Emergency Contact Phone") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Residential Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (rollNo.isNotBlank() && name.isNotBlank()) {
                        onAdd(rollNo, name, selectedClassId, gender, parentName, parentPhone, emergencyContact, address)
                    }
                }
            ) {
                Text("Enroll Student")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- ATTENDANCE VIEW ----------------

@Composable
fun PrincipalAttendanceView(viewModel: PrincipalViewModel) {
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val attendanceSummary by viewModel.attendanceSummary.collectAsStateWithLifecycle()
    val allRecords by viewModel.todayAttendanceRecords.collectAsStateWithLifecycle()
    val absentStudents by viewModel.todayAbsentStudents.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()
    val selectedDateSubmissions by viewModel.selectedDateSubmissions.collectAsStateWithLifecycle()
    val allSubmissions by viewModel.allAttendanceSubmissions.collectAsStateWithLifecycle()

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        // Date Selector Row
        item {
            ElevatedCard(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Viewing Attendance For:",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Text(
                                text = selectedDate,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        OutlinedButton(
                            onClick = { viewModel.selectDate(todayStr) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Today", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Metrics breakdown
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "School Attendance Overview",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { (attendanceSummary.attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = StatusPresent,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatusMetric(label = "Present", count = attendanceSummary.presentCount, color = StatusPresent)
                        StatusMetric(label = "Absent", count = attendanceSummary.absentCount, color = StatusAbsent)
                        StatusMetric(label = "Late", count = attendanceSummary.lateCount, color = StatusLate)
                        StatusMetric(label = "Total Marked", count = allRecords.size, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Submitted Attendance Reports Section
        item {
            Text(
                text = "Submitted Reports from Teachers (${selectedDateSubmissions.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (selectedDateSubmissions.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No teacher attendance reports submitted yet for this date.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        } else {
            items(selectedDateSubmissions, key = { it.id }) { sub ->
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = StatusPresent,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = sub.className,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(StatusPresentBg)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = sub.submittedStatus,
                                    color = StatusPresent,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Class Teacher: ${sub.classTeacherName} • Date: ${sub.date}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Text(
                            text = "Total Students: ${sub.totalStudents} | Present: ${sub.presentStudents} | Absent: ${sub.absentStudents}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )

                        if (sub.absentStudents > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Absent Students: ${sub.absentStudentNames}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                            )
                            if (sub.absentNotes.isNotBlank() && sub.absentNotes != "No notes provided") {
                                Text(
                                    text = "Absent Notes: ${sub.absentNotes}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Absent Students Section
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Absent Students (${absentStudents.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (absentStudents.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No absent students reported for this date.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        } else {
            items(absentStudents, key = { it.id }) { record ->
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = record.studentName,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Class: ${record.classId} • Roll: ${record.rollNumber}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            record.remarks?.let {
                                Text(
                                    text = "Reason: $it",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:5550192831")
                                }
                                try {
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call Parent", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Class-by-Class Attendance Breakdown
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Class-wise Attendance Status",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(classes, key = { it.id }) { cls ->
            val classRecords = allRecords.filter { it.classId == cls.id }
            val presentInClass = classRecords.count { it.status == "PRESENT" || it.status == "LATE" }
            val absentInClass = classRecords.count { it.status == "ABSENT" }

            ElevatedCard(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = cls.name,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "${cls.roomNumber} • Recorded: ${classRecords.size} students",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(StatusPresentBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Present: $presentInClass",
                                color = StatusPresent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(StatusAbsentBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Absent: $absentInClass",
                                color = StatusAbsent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusMetric(label: String, count: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$count",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
    }
}

// ---------------- ACADEMICS (HOMEWORK & MARKS) VIEW ----------------

@Composable
fun PrincipalAcademicsView(viewModel: PrincipalViewModel) {
    val homeworkList by viewModel.allHomework.collectAsStateWithLifecycle()
    val marksList by viewModel.allMarks.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()

    var academicSubTab by remember { mutableStateOf(0) } // 0: Homework, 1: Marks

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        TabRow(
            selectedTabIndex = academicSubTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = academicSubTab == 0,
                onClick = { academicSubTab = 0 },
                text = { Text("Homework Assignments (${homeworkList.size})", fontWeight = FontWeight.SemiBold) }
            )
            Tab(
                selected = academicSubTab == 1,
                onClick = { academicSubTab = 1 },
                text = { Text("Exam Marks & Grades (${marksList.size})", fontWeight = FontWeight.SemiBold) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (academicSubTab == 0) {
            // Homework List
            if (homeworkList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No homework assignments posted yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(homeworkList, key = { it.id }) { hw ->
                        val cls = classes.find { it.id == hw.classId }
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = hw.subject,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Text(
                                        text = "Class: ${cls?.name ?: hw.classId}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = hw.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = hw.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(thickness = 0.5.dp)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "By: ${hw.teacherName}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    Text(
                                        text = "Due: ${hw.dueDate}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Marks List
            if (marksList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No exam marks entered yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(marksList, key = { it.id }) { mark ->
                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${mark.studentName} (Roll: ${mark.rollNumber})",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${mark.examName} • ${mark.subject} (Class: ${mark.classId})",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    mark.remarks?.let {
                                        Text(
                                            text = "Remarks: $it",
                                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${mark.marksObtained} / ${mark.maxMarks}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "Grade ${mark.grade}",
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- LEAVE REQUESTS VIEW ----------------

@Composable
fun PrincipalLeavesView(viewModel: PrincipalViewModel) {
    val allLeaves by viewModel.allLeaves.collectAsStateWithLifecycle()
    val pendingLeaves by viewModel.pendingLeaves.collectAsStateWithLifecycle()

    var filterPendingOnly by remember { mutableStateOf(false) }
    var leaveToApprove by remember { mutableStateOf<LeaveRequest?>(null) }
    var leaveToReject by remember { mutableStateOf<LeaveRequest?>(null) }

    val displayedLeaves = if (filterPendingOnly) pendingLeaves else allLeaves

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !filterPendingOnly,
                    onClick = { filterPendingOnly = false },
                    label = { Text("All Requests (${allLeaves.size})") }
                )
                FilterChip(
                    selected = filterPendingOnly,
                    onClick = { filterPendingOnly = true },
                    label = { Text("Pending (${pendingLeaves.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.errorContainer
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (displayedLeaves.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No leave requests found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(displayedLeaves, key = { it.id }) { leave ->
                        ElevatedCard(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = leave.teacherName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${leave.leaveType} Leave • ${leave.daysCount} Day(s) (${leave.startDate} to ${leave.endDate})",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        )
                                    }

                                    // Status
                                    val statusColor = when (leave.status) {
                                        "APPROVED" -> StatusPresent
                                        "REJECTED" -> StatusAbsent
                                        else -> StatusLate
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(statusColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = leave.status,
                                            color = statusColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Reason: ${leave.reason}",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                leave.principalComment?.let { comment ->
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Principal Note: $comment",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                }

                                if (leave.status == "PENDING") {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { leaveToApprove = leave },
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusPresent),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Approve")
                                        }
                                        OutlinedButton(
                                            onClick = { leaveToReject = leave },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Reject")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Leave Decision Dialogs
        leaveToApprove?.let { leave ->
            LeaveDecisionDialog(
                title = "Approve Leave Request",
                teacherName = leave.teacherName,
                isApproval = true,
                onDismiss = { leaveToApprove = null },
                onConfirm = { comment ->
                    viewModel.approveLeave(leave.id, comment)
                    leaveToApprove = null
                }
            )
        }

        leaveToReject?.let { leave ->
            LeaveDecisionDialog(
                title = "Reject Leave Request",
                teacherName = leave.teacherName,
                isApproval = false,
                onDismiss = { leaveToReject = null },
                onConfirm = { comment ->
                    viewModel.rejectLeave(leave.id, comment)
                    leaveToReject = null
                }
            )
        }
    }
}

@Composable
fun LeaveDecisionDialog(
    title: String,
    teacherName: String,
    isApproval: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (comment: String?) -> Unit
) {
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Decision for $teacherName's leave request:")
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Remarks / Instructions (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(comment.ifBlank { null }) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isApproval) StatusPresent else MaterialTheme.colorScheme.error
                )
            ) {
                Text(if (isApproval) "Confirm Approval" else "Confirm Rejection")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- ANNOUNCEMENTS VIEW ----------------

@Composable
fun PrincipalAnnouncementsView(viewModel: PrincipalViewModel) {
    val announcements by viewModel.allAnnouncements.collectAsStateWithLifecycle()
    val classes by viewModel.allClasses.collectAsStateWithLifecycle()

    var showNewAnnouncementDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Broadcast Center (${announcements.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Button(
                    onClick = { showNewAnnouncementDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Notice")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (announcements.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No announcements published.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 60.dp)
                ) {
                    items(announcements, key = { it.id }) { ann ->
                        AnnouncementItemCard(
                            announcement = ann,
                            onDelete = { viewModel.deleteAnnouncement(ann.id) }
                        )
                    }
                }
            }
        }

        if (showNewAnnouncementDialog) {
            CreateAnnouncementDialog(
                classes = classes,
                onDismiss = { showNewAnnouncementDialog = false },
                onPublish = { title, content, audience, priority ->
                    viewModel.sendAnnouncement(title, content, audience, priority)
                    showNewAnnouncementDialog = false
                }
            )
        }
    }
}

@Composable
fun AnnouncementItemCard(
    announcement: Announcement,
    onDelete: (() -> Unit)? = null
) {
    val priorityColor = when (announcement.priority) {
        AnnouncementPriority.URGENT.name -> MaterialTheme.colorScheme.error
        AnnouncementPriority.EVENT.name -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.primary
    }

    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(priorityColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = announcement.priority,
                        color = priorityColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Audience: ${if (announcement.targetAudience == "ALL") "All School" else announcement.targetAudience}",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    onDelete?.let {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(onClick = it, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = announcement.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = announcement.content,
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface)
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "By: ${announcement.authorName}",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                Text(
                    text = announcement.date,
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }
    }
}

@Composable
fun CreateAnnouncementDialog(
    classes: List<SchoolClass>,
    onDismiss: () -> Unit,
    onPublish: (title: String, content: String, audience: String, priority: AnnouncementPriority) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var audience by remember { mutableStateOf("ALL") }
    var priority by remember { mutableStateOf(AnnouncementPriority.NORMAL) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Publish Announcement", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Announcement Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Details & Description") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Priority Level:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = priority == AnnouncementPriority.NORMAL,
                        onClick = { priority = AnnouncementPriority.NORMAL },
                        label = { Text("Normal", fontSize = 12.sp) }
                    )
                    FilterChip(
                        selected = priority == AnnouncementPriority.URGENT,
                        onClick = { priority = AnnouncementPriority.URGENT },
                        label = { Text("Urgent", fontSize = 12.sp) }
                    )
                    FilterChip(
                        selected = priority == AnnouncementPriority.EVENT,
                        onClick = { priority = AnnouncementPriority.EVENT },
                        label = { Text("Event", fontSize = 12.sp) }
                    )
                }

                Text("Target Audience:", style = MaterialTheme.typography.labelMedium)
                FilterChip(
                    selected = audience == "ALL",
                    onClick = { audience = "ALL" },
                    label = { Text("All School (Teachers & Students)") },
                    modifier = Modifier.fillMaxWidth()
                )
                classes.forEach { cls ->
                    FilterChip(
                        selected = audience == cls.id,
                        onClick = { audience = cls.id },
                        label = { Text(cls.name) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onPublish(title, content, audience, priority)
                    }
                }
            ) {
                Text("Publish Notice")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ---------------- SETTINGS & ACCOUNT VIEW ----------------

@Composable
fun PrincipalSettingsView(viewModel: PrincipalViewModel) {
    val session by viewModel.sessionState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = session?.name ?: "Principal",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Principal ID: ${session?.userId ?: ""}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "Role: School Administration (Full Access)",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Security & Multi-Device Sync",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        item {
            ElevatedCard(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "🔐 Persistent Login & Recovery",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Your login session is securely maintained on this device until you explicitly press Logout. Closing or reopening the app does not log you out.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "Teachers and Principals can recover their passwords anytime via their verified security questions.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Logout from School Portal")
            }
        }
    }
}
