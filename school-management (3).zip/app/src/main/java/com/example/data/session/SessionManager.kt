package com.example.data.session

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSession(
    val userId: String,
    val role: String,
    val name: String,
    val assignedClassId: String? = null
)

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("school_management_session", Context.MODE_PRIVATE)

    private val _sessionState = MutableStateFlow<UserSession?>(loadSavedSession())
    val sessionState: StateFlow<UserSession?> = _sessionState.asStateFlow()

    private fun loadSavedSession(): UserSession? {
        val userId = prefs.getString(KEY_USER_ID, null)
        val role = prefs.getString(KEY_ROLE, null)
        val name = prefs.getString(KEY_NAME, null)
        val assignedClassId = prefs.getString(KEY_CLASS_ID, null)

        return if (!userId.isNullOrBlank() && !role.isNullOrBlank() && !name.isNullOrBlank()) {
            UserSession(
                userId = userId,
                role = role,
                name = name,
                assignedClassId = assignedClassId
            )
        } else {
            null
        }
    }

    fun saveSession(userId: String, role: String, name: String, assignedClassId: String? = null) {
        prefs.edit()
            .putString(KEY_USER_ID, userId)
            .putString(KEY_ROLE, role)
            .putString(KEY_NAME, name)
            .putString(KEY_CLASS_ID, assignedClassId)
            .apply()

        _sessionState.value = UserSession(userId, role, name, assignedClassId)
    }

    fun updateAssignedClass(classId: String?) {
        val current = _sessionState.value ?: return
        prefs.edit().putString(KEY_CLASS_ID, classId).apply()
        _sessionState.value = current.copy(assignedClassId = classId)
    }

    fun clearSession() {
        prefs.edit().clear().apply()
        _sessionState.value = null
    }

    companion object {
        private const val KEY_USER_ID = "logged_user_id"
        private const val KEY_ROLE = "logged_user_role"
        private const val KEY_NAME = "logged_user_name"
        private const val KEY_CLASS_ID = "logged_class_id"

        @Volatile
        private var INSTANCE: SessionManager? = null

        fun getInstance(context: Context): SessionManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SessionManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
