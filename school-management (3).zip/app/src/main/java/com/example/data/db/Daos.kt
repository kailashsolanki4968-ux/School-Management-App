package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserAccount?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserByIdFlow(id: String): Flow<UserAccount?>

    @Query("SELECT * FROM users WHERE role = 'TEACHER' ORDER BY name ASC")
    fun getAllTeachers(): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE role = 'TEACHER' AND status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingTeachers(): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE role = 'TEACHER' AND status = 'APPROVED' ORDER BY name ASC")
    fun getApprovedTeachers(): Flow<List<UserAccount>>

    @Query("SELECT COUNT(*) FROM users WHERE role = 'PRINCIPAL'")
    suspend fun getPrincipalCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccount)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserAccount>)

    @Update
    suspend fun updateUser(user: UserAccount)

    @Query("UPDATE users SET status = :status WHERE id = :userId")
    suspend fun updateTeacherStatus(userId: String, status: String)

    @Query("UPDATE users SET assignedClassId = :classId WHERE id = :teacherId")
    suspend fun updateAssignedClass(teacherId: String, classId: String?)

    @Query("UPDATE users SET passwordHash = :newPassword WHERE id = :userId")
    suspend fun updatePassword(userId: String, newPassword: String)

    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUser(userId: String)
}

@Dao
interface ClassDao {
    @Query("SELECT * FROM classes ORDER BY name ASC")
    fun getAllClasses(): Flow<List<SchoolClass>>

    @Query("SELECT * FROM classes WHERE id = :id LIMIT 1")
    suspend fun getClassById(id: String): SchoolClass?

    @Query("SELECT * FROM classes WHERE id = :id LIMIT 1")
    fun getClassByIdFlow(id: String): Flow<SchoolClass?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(schoolClass: SchoolClass)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<SchoolClass>)

    @Update
    suspend fun updateClass(schoolClass: SchoolClass)

    @Query("UPDATE classes SET classTeacherId = :teacherId WHERE id = :classId")
    suspend fun updateClassTeacher(classId: String, teacherId: String?)

    @Query("DELETE FROM classes WHERE id = :id")
    suspend fun deleteClass(id: String)
}

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY rollNumber ASC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY rollNumber ASC")
    fun getStudentsByClass(classId: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY rollNumber ASC")
    suspend fun getStudentsByClassDirect(classId: String): List<Student>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentById(id: String): Student?

    @Query("SELECT COUNT(*) FROM students")
    fun getTotalStudentCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM students WHERE classId = :classId")
    fun getStudentCountByClass(classId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<Student>)

    @Update
    suspend fun updateStudent(student: Student)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun deleteStudent(id: String)
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE classId = :classId AND date = :date ORDER BY rollNumber ASC")
    fun getAttendanceByClassAndDate(classId: String, date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE classId = :classId AND date = :date")
    suspend fun getAttendanceByClassAndDateDirect(classId: String, date: String): List<AttendanceRecord>

    @Query("SELECT * FROM attendance_records WHERE date = :date")
    fun getAllAttendanceByDate(date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE date = :date AND status = 'ABSENT' ORDER BY classId ASC, rollNumber ASC")
    fun getAbsentStudentsByDate(date: String): Flow<List<AttendanceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(records: List<AttendanceRecord>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSingleAttendance(record: AttendanceRecord)

    @Query("DELETE FROM attendance_records WHERE classId = :classId AND date = :date")
    suspend fun deleteAttendanceForClassDate(classId: String, date: String)
}

@Dao
interface AttendanceSubmissionDao {
    @Query("SELECT * FROM attendance_submissions ORDER BY date DESC, submittedAt DESC")
    fun getAllSubmissions(): Flow<List<AttendanceSubmissionRecord>>

    @Query("SELECT * FROM attendance_submissions WHERE date = :date ORDER BY className ASC")
    fun getSubmissionsByDate(date: String): Flow<List<AttendanceSubmissionRecord>>

    @Query("SELECT * FROM attendance_submissions WHERE classId = :classId ORDER BY date DESC")
    fun getSubmissionsByClass(classId: String): Flow<List<AttendanceSubmissionRecord>>

    @Query("SELECT * FROM attendance_submissions WHERE classId = :classId AND date = :date LIMIT 1")
    fun getSubmissionByClassAndDateFlow(classId: String, date: String): Flow<AttendanceSubmissionRecord?>

    @Query("SELECT * FROM attendance_submissions WHERE classId = :classId AND date = :date LIMIT 1")
    suspend fun getSubmissionByClassAndDate(classId: String, date: String): AttendanceSubmissionRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubmission(submission: AttendanceSubmissionRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubmissions(submissions: List<AttendanceSubmissionRecord>)

    @Query("DELETE FROM attendance_submissions WHERE id = :id")
    suspend fun deleteSubmission(id: String)
}

@Dao
interface HomeworkDao {
    @Query("SELECT * FROM homework WHERE classId = :classId ORDER BY assignedDate DESC")
    fun getHomeworkByClass(classId: String): Flow<List<Homework>>

    @Query("SELECT * FROM homework ORDER BY assignedDate DESC")
    fun getAllHomework(): Flow<List<Homework>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomeworkList(list: List<Homework>)

    @Update
    suspend fun updateHomework(homework: Homework)

    @Query("DELETE FROM homework WHERE id = :id")
    suspend fun deleteHomework(id: String)
}

@Dao
interface MarkDao {
    @Query("SELECT * FROM student_marks WHERE classId = :classId ORDER BY examName ASC, subject ASC, rollNumber ASC")
    fun getMarksByClass(classId: String): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE studentId = :studentId ORDER BY examName ASC, subject ASC")
    fun getMarksByStudent(studentId: String): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks ORDER BY examName ASC, subject ASC")
    fun getAllMarks(): Flow<List<StudentMark>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMark(mark: StudentMark)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarks(marks: List<StudentMark>)

    @Update
    suspend fun updateMark(mark: StudentMark)

    @Query("DELETE FROM student_marks WHERE id = :id")
    suspend fun deleteMark(id: String)
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements WHERE targetAudience = 'ALL' OR targetAudience = :classId ORDER BY timestamp DESC")
    fun getAnnouncementsForClass(classId: String): Flow<List<Announcement>>

    @Query("SELECT * FROM announcements ORDER BY timestamp DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncements(list: List<Announcement>)

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncement(id: String)
}

@Dao
interface LeaveDao {
    @Query("SELECT * FROM leave_requests ORDER BY appliedAt DESC")
    fun getAllLeaveRequests(): Flow<List<LeaveRequest>>

    @Query("SELECT * FROM leave_requests WHERE teacherId = :teacherId ORDER BY appliedAt DESC")
    fun getLeaveRequestsByTeacher(teacherId: String): Flow<List<LeaveRequest>>

    @Query("SELECT * FROM leave_requests WHERE status = 'PENDING' ORDER BY appliedAt DESC")
    fun getPendingLeaveRequests(): Flow<List<LeaveRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveRequest(request: LeaveRequest)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveRequests(requests: List<LeaveRequest>)

    @Query("UPDATE leave_requests SET status = :status, principalComment = :comment WHERE id = :id")
    suspend fun updateLeaveStatus(id: String, status: String, comment: String?)

    @Query("DELETE FROM leave_requests WHERE id = :id")
    suspend fun deleteLeaveRequest(id: String)
}
