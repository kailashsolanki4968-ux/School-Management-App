package com.example.data.repository

import android.content.Context
import com.example.data.db.AppDatabase
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.session.SessionManager
import com.example.data.session.UserSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class SchoolRepository(
    private val database: AppDatabase,
    private val sessionManager: SessionManager
) {
    val sessionState: StateFlow<UserSession?> = sessionManager.sessionState

    // Users & Auth
    fun getAllTeachers(): Flow<List<UserAccount>> = database.userDao().getAllTeachers()
    fun getPendingTeachers(): Flow<List<UserAccount>> = database.userDao().getPendingTeachers()
    fun getApprovedTeachers(): Flow<List<UserAccount>> = database.userDao().getApprovedTeachers()
    fun getUserByIdFlow(id: String): Flow<UserAccount?> = database.userDao().getUserByIdFlow(id)

    suspend fun getUserById(id: String): UserAccount? = withContext(Dispatchers.IO) {
        database.userDao().getUserById(id)
    }

    suspend fun registerUser(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
        val existing = database.userDao().getUserById(user.id)
        if (existing != null) {
            return@withContext Result.failure(Exception("Account ID '${user.id}' already exists. Please choose a different ID."))
        }
        database.userDao().insertUser(user)
        Result.success(user)
    }

    suspend fun login(id: String, password: String, expectedRole: String): Result<UserAccount> = withContext(Dispatchers.IO) {
        val user = database.userDao().getUserById(id.trim())
            ?: return@withContext Result.failure(Exception("Account with ID '$id' not found."))

        if (user.passwordHash != password) {
            return@withContext Result.failure(Exception("Incorrect password."))
        }

        if (user.role != expectedRole) {
            return@withContext Result.failure(
                Exception("Unauthorized role. This account is registered as ${user.role}, not $expectedRole.")
            )
        }

        if (user.role == UserRole.TEACHER.name) {
            when (user.status) {
                AccountStatus.PENDING.name -> {
                    return@withContext Result.failure(
                        Exception("Your Teacher account is pending Principal approval. Please wait for the Principal to approve your account.")
                    )
                }
                AccountStatus.REJECTED.name -> {
                    return@withContext Result.failure(
                        Exception("Your Teacher account registration was declined by the Principal.")
                    )
                }
            }
        }

        // Save session
        sessionManager.saveSession(user.id, user.role, user.name, user.assignedClassId)
        Result.success(user)
    }

    fun logout() {
        sessionManager.clearSession()
    }

    suspend fun updateTeacherStatus(teacherId: String, status: String) = withContext(Dispatchers.IO) {
        database.userDao().updateTeacherStatus(teacherId, status)
    }

    suspend fun updateTeacherClass(teacherId: String, classId: String?) = withContext(Dispatchers.IO) {
        database.userDao().updateAssignedClass(teacherId, classId)
        if (classId != null) {
            database.classDao().updateClassTeacher(classId, teacherId)
        }
    }

    suspend fun resetPasswordWithSecurity(
        userId: String,
        securityAnswer: String,
        newPassword: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val user = database.userDao().getUserById(userId.trim())
            ?: return@withContext Result.failure(Exception("User ID not found."))

        if (!user.securityAnswer.trim().equals(securityAnswer.trim(), ignoreCase = true)) {
            return@withContext Result.failure(Exception("Security answer is incorrect."))
        }

        database.userDao().updatePassword(user.id, newPassword)
        Result.success(Unit)
    }

    suspend fun directUpdatePassword(userId: String, newPassword: String) = withContext(Dispatchers.IO) {
        database.userDao().updatePassword(userId, newPassword)
    }

    suspend fun deleteTeacher(teacherId: String) = withContext(Dispatchers.IO) {
        database.userDao().deleteUser(teacherId)
    }

    // Classes
    fun getAllClasses(): Flow<List<SchoolClass>> = database.classDao().getAllClasses()
    fun getClassByIdFlow(id: String): Flow<SchoolClass?> = database.classDao().getClassByIdFlow(id)
    suspend fun getClassById(id: String): SchoolClass? = withContext(Dispatchers.IO) {
        database.classDao().getClassById(id)
    }

    suspend fun insertClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        database.classDao().insertClass(schoolClass)
        schoolClass.classTeacherId?.let { teacherId ->
            database.userDao().updateAssignedClass(teacherId, schoolClass.id)
        }
    }

    suspend fun updateClass(schoolClass: SchoolClass) = withContext(Dispatchers.IO) {
        database.classDao().updateClass(schoolClass)
        schoolClass.classTeacherId?.let { teacherId ->
            database.userDao().updateAssignedClass(teacherId, schoolClass.id)
        }
    }

    suspend fun deleteClass(classId: String) = withContext(Dispatchers.IO) {
        database.classDao().deleteClass(classId)
    }

    // Students
    fun getAllStudents(): Flow<List<Student>> = database.studentDao().getAllStudents()
    fun getStudentsByClass(classId: String): Flow<List<Student>> = database.studentDao().getStudentsByClass(classId)
    suspend fun getStudentsByClassDirect(classId: String): List<Student> = withContext(Dispatchers.IO) {
        database.studentDao().getStudentsByClassDirect(classId)
    }

    suspend fun insertStudent(student: Student) = withContext(Dispatchers.IO) {
        database.studentDao().insertStudent(student)
    }

    suspend fun updateStudent(student: Student) = withContext(Dispatchers.IO) {
        database.studentDao().updateStudent(student)
    }

    suspend fun deleteStudent(studentId: String) = withContext(Dispatchers.IO) {
        database.studentDao().deleteStudent(studentId)
    }

    // Attendance
    fun getAttendanceByClassAndDate(classId: String, date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAttendanceByClassAndDate(classId, date)

    suspend fun getAttendanceByClassAndDateDirect(classId: String, date: String): List<AttendanceRecord> =
        withContext(Dispatchers.IO) {
            database.attendanceDao().getAttendanceByClassAndDateDirect(classId, date)
        }

    fun getAllAttendanceByDate(date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAllAttendanceByDate(date)

    fun getAbsentStudentsByDate(date: String): Flow<List<AttendanceRecord>> =
        database.attendanceDao().getAbsentStudentsByDate(date)

    suspend fun saveAttendance(records: List<AttendanceRecord>) = withContext(Dispatchers.IO) {
        database.attendanceDao().insertAttendance(records)
    }

    suspend fun saveSingleAttendance(record: AttendanceRecord) = withContext(Dispatchers.IO) {
        database.attendanceDao().insertSingleAttendance(record)
    }

    // Attendance Submissions
    fun getAllAttendanceSubmissions(): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getAllSubmissions()

    fun getAttendanceSubmissionsByDate(date: String): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getSubmissionsByDate(date)

    fun getAttendanceSubmissionsByClass(classId: String): Flow<List<AttendanceSubmissionRecord>> =
        database.attendanceSubmissionDao().getSubmissionsByClass(classId)

    fun getAttendanceSubmissionByClassAndDateFlow(classId: String, date: String): Flow<AttendanceSubmissionRecord?> =
        database.attendanceSubmissionDao().getSubmissionByClassAndDateFlow(classId, date)

    suspend fun getAttendanceSubmissionByClassAndDate(classId: String, date: String): AttendanceSubmissionRecord? =
        withContext(Dispatchers.IO) {
            database.attendanceSubmissionDao().getSubmissionByClassAndDate(classId, date)
        }

    suspend fun submitAttendanceReport(
        submission: AttendanceSubmissionRecord,
        records: List<AttendanceRecord>
    ) = withContext(Dispatchers.IO) {
        database.attendanceDao().insertAttendance(records)
        database.attendanceSubmissionDao().insertSubmission(submission)
    }

    // Homework
    fun getHomeworkByClass(classId: String): Flow<List<Homework>> = database.homeworkDao().getHomeworkByClass(classId)
    fun getAllHomework(): Flow<List<Homework>> = database.homeworkDao().getAllHomework()
    suspend fun insertHomework(homework: Homework) = withContext(Dispatchers.IO) {
        database.homeworkDao().insertHomework(homework)
    }
    suspend fun deleteHomework(id: String) = withContext(Dispatchers.IO) {
        database.homeworkDao().deleteHomework(id)
    }

    // Marks
    fun getMarksByClass(classId: String): Flow<List<StudentMark>> = database.markDao().getMarksByClass(classId)
    fun getMarksByStudent(studentId: String): Flow<List<StudentMark>> = database.markDao().getMarksByStudent(studentId)
    fun getAllMarks(): Flow<List<StudentMark>> = database.markDao().getAllMarks()
    suspend fun insertMark(mark: StudentMark) = withContext(Dispatchers.IO) {
        database.markDao().insertMark(mark)
    }
    suspend fun insertMarks(marks: List<StudentMark>) = withContext(Dispatchers.IO) {
        database.markDao().insertMarks(marks)
    }
    suspend fun deleteMark(id: String) = withContext(Dispatchers.IO) {
        database.markDao().deleteMark(id)
    }

    // Announcements
    fun getAnnouncementsForClass(classId: String): Flow<List<Announcement>> =
        database.announcementDao().getAnnouncementsForClass(classId)
    fun getAllAnnouncements(): Flow<List<Announcement>> = database.announcementDao().getAllAnnouncements()
    suspend fun insertAnnouncement(announcement: Announcement) = withContext(Dispatchers.IO) {
        database.announcementDao().insertAnnouncement(announcement)
    }
    suspend fun deleteAnnouncement(id: String) = withContext(Dispatchers.IO) {
        database.announcementDao().deleteAnnouncement(id)
    }

    // Leaves
    fun getAllLeaveRequests(): Flow<List<LeaveRequest>> = database.leaveDao().getAllLeaveRequests()
    fun getLeaveRequestsByTeacher(teacherId: String): Flow<List<LeaveRequest>> =
        database.leaveDao().getLeaveRequestsByTeacher(teacherId)
    fun getPendingLeaveRequests(): Flow<List<LeaveRequest>> = database.leaveDao().getPendingLeaveRequests()
    suspend fun insertLeaveRequest(request: LeaveRequest) = withContext(Dispatchers.IO) {
        database.leaveDao().insertLeaveRequest(request)
    }
    suspend fun updateLeaveStatus(id: String, status: String, comment: String?) = withContext(Dispatchers.IO) {
        database.leaveDao().updateLeaveStatus(id, status, comment)
    }
    suspend fun deleteLeaveRequest(id: String) = withContext(Dispatchers.IO) {
        database.leaveDao().deleteLeaveRequest(id)
    }

    // Backup & Restore for multi-device sync
    suspend fun exportDataJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        // Export logic if needed
        root.put("version", 1)
        root.put("exportTime", System.currentTimeMillis())
        root.toString(2)
    }

    companion object {
        @Volatile
        private var INSTANCE: SchoolRepository? = null

        fun getInstance(context: Context): SchoolRepository {
            return INSTANCE ?: synchronized(this) {
                val db = AppDatabase.getDatabase(context)
                val session = SessionManager.getInstance(context)
                INSTANCE ?: SchoolRepository(db, session).also { INSTANCE = it }
            }
        }
    }
}
