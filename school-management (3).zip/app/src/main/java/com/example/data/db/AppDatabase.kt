package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.LeaveStatus
import com.example.data.model.LeaveType
import com.example.data.model.SchoolClass
import com.example.data.model.Student
import com.example.data.model.StudentMark
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Database(
    entities = [
        UserAccount::class,
        SchoolClass::class,
        Student::class,
        AttendanceRecord::class,
        AttendanceSubmissionRecord::class,
        Homework::class,
        StudentMark::class,
        Announcement::class,
        LeaveRequest::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun classDao(): ClassDao
    abstract fun studentDao(): StudentDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun attendanceSubmissionDao(): AttendanceSubmissionDao
    abstract fun homeworkDao(): HomeworkDao
    abstract fun markDao(): MarkDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun leaveDao(): LeaveDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "school_management.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                CoroutineScope(Dispatchers.IO).launch {
                    ensureSeedData(instance)
                }
                instance
            }
        }

        suspend fun ensureSeedData(db: AppDatabase) {
            try {
                if (db.userDao().getPrincipalCount() == 0) {
                    populateInitialData(db)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val todayStr = dateFormat.format(Date())

            // 1. Initial Principal Account
            val principal = UserAccount(
                id = "PRIN001",
                name = "Dr. Arthur Vance",
                email = "principal@school.edu",
                phone = "+1 (555) 019-2831",
                role = UserRole.PRINCIPAL.name,
                passwordHash = "principal123",
                securityQuestion = "What is your primary school name?",
                securityAnswer = "Greenwood",
                status = AccountStatus.APPROVED.name,
                assignedClassId = null,
                subject = "Administration"
            )
            db.userDao().insertUser(principal)

            // 2. Initial Classes
            val class10A = SchoolClass(
                id = "CLASS_10A",
                name = "Grade 10 - Section A",
                grade = "Grade 10",
                section = "A",
                classTeacherId = "TCH101",
                roomNumber = "Room 201"
            )
            val class10B = SchoolClass(
                id = "CLASS_10B",
                name = "Grade 10 - Section B",
                grade = "Grade 10",
                section = "B",
                classTeacherId = "TCH102",
                roomNumber = "Room 202"
            )
            val class9A = SchoolClass(
                id = "CLASS_9A",
                name = "Grade 9 - Section A",
                grade = "Grade 9",
                section = "A",
                classTeacherId = "TCH103",
                roomNumber = "Room 105"
            )
            db.classDao().insertClasses(listOf(class10A, class10B, class9A))

            // 3. Initial Teachers
            val teachers = listOf(
                UserAccount(
                    id = "TCH101",
                    name = "Prof. Eleanor Woods",
                    email = "eleanor.woods@school.edu",
                    phone = "+1 (555) 432-8765",
                    role = UserRole.TEACHER.name,
                    passwordHash = "teacher123",
                    securityQuestion = "What is your favorite subject?",
                    securityAnswer = "Mathematics",
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_10A",
                    subject = "Mathematics"
                ),
                UserAccount(
                    id = "TCH102",
                    name = "Mr. Robert Chen",
                    email = "robert.chen@school.edu",
                    phone = "+1 (555) 876-1234",
                    role = UserRole.TEACHER.name,
                    passwordHash = "teacher123",
                    securityQuestion = "What city were you born in?",
                    securityAnswer = "Seattle",
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_10B",
                    subject = "Science & Physics"
                ),
                UserAccount(
                    id = "TCH103",
                    name = "Ms. Sarah Jenkins",
                    email = "sarah.jenkins@school.edu",
                    phone = "+1 (555) 987-6543",
                    role = UserRole.TEACHER.name,
                    passwordHash = "teacher123",
                    securityQuestion = "What was your first pet's name?",
                    securityAnswer = "Oliver",
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_9A",
                    subject = "English Literature"
                ),
                UserAccount(
                    id = "TCH104",
                    name = "Mr. David Miller",
                    email = "david.miller@school.edu",
                    phone = "+1 (555) 345-6789",
                    role = UserRole.TEACHER.name,
                    passwordHash = "teacher123",
                    securityQuestion = "What is your mother's maiden name?",
                    securityAnswer = "Taylor",
                    status = AccountStatus.PENDING.name,
                    assignedClassId = null,
                    subject = "History & Social Studies"
                )
            )
            db.userDao().insertUsers(teachers)

            // 4. Initial Students for Grade 10-A
            val students10A = listOf(
                Student(id = "STU_1001", rollNumber = "101", name = "Lucas Bennett", classId = "CLASS_10A", gender = "Male", parentName = "Mark Bennett", parentPhone = "+1 (555) 234-5678", emergencyContact = "+1 (555) 234-5679", address = "742 Evergreen Terrace"),
                Student(id = "STU_1002", rollNumber = "102", name = "Sophia Martinez", classId = "CLASS_10A", gender = "Female", parentName = "Elena Martinez", parentPhone = "+1 (555) 345-6789", emergencyContact = "+1 (555) 345-6780", address = "120 Elm Street"),
                Student(id = "STU_1003", rollNumber = "103", name = "Ethan Davies", classId = "CLASS_10A", gender = "Male", parentName = "Paul Davies", parentPhone = "+1 (555) 456-7890", emergencyContact = "+1 (555) 456-7891", address = "45 Oak Avenue"),
                Student(id = "STU_1004", rollNumber = "104", name = "Mia Tanaka", classId = "CLASS_10A", gender = "Female", parentName = "Kenji Tanaka", parentPhone = "+1 (555) 567-8901", emergencyContact = "+1 (555) 567-8902", address = "88 Pine Lane"),
                Student(id = "STU_1005", rollNumber = "105", name = "Noah Williams", classId = "CLASS_10A", gender = "Male", parentName = "Sarah Williams", parentPhone = "+1 (555) 678-9012", emergencyContact = "+1 (555) 678-9013", address = "310 Maple Drive"),
                Student(id = "STU_1006", rollNumber = "106", name = "Ava Robinson", classId = "CLASS_10A", gender = "Female", parentName = "James Robinson", parentPhone = "+1 (555) 789-0123", emergencyContact = "+1 (555) 789-0124", address = "512 Cedar Court")
            )

            // Students for Grade 10-B
            val students10B = listOf(
                Student(id = "STU_1007", rollNumber = "201", name = "Liam Johnson", classId = "CLASS_10B", gender = "Male", parentName = "Eric Johnson", parentPhone = "+1 (555) 890-1234", emergencyContact = "+1 (555) 890-1235", address = "19 Sunset Blvd"),
                Student(id = "STU_1008", rollNumber = "202", name = "Emma Clark", classId = "CLASS_10B", gender = "Female", parentName = "Jessica Clark", parentPhone = "+1 (555) 901-2345", emergencyContact = "+1 (555) 901-2346", address = "402 Birch Way"),
                Student(id = "STU_1009", rollNumber = "203", name = "Benjamin Lee", classId = "CLASS_10B", gender = "Male", parentName = "David Lee", parentPhone = "+1 (555) 012-3456", emergencyContact = "+1 (555) 012-3457", address = "63 Walnut Street")
            )

            // Students for Grade 9-A
            val students9A = listOf(
                Student(id = "STU_1010", rollNumber = "301", name = "Charlotte Brown", classId = "CLASS_9A", gender = "Female", parentName = "Gregory Brown", parentPhone = "+1 (555) 123-4560", emergencyContact = "+1 (555) 123-4561", address = "91 River Road"),
                Student(id = "STU_1011", rollNumber = "302", name = "Daniel Garcia", classId = "CLASS_9A", gender = "Male", parentName = "Carlos Garcia", parentPhone = "+1 (555) 234-5670", emergencyContact = "+1 (555) 234-5671", address = "77 Highland Ave")
            )

            db.studentDao().insertStudents(students10A + students10B + students9A)

            // 5. Initial Attendance Records for Today
            val attendance10A = listOf(
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1001", studentName = "Lucas Bennett", rollNumber = "101", classId = "CLASS_10A", status = AttendanceStatus.PRESENT.name, markedByTeacherId = "TCH101"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1002", studentName = "Sophia Martinez", rollNumber = "102", classId = "CLASS_10A", status = AttendanceStatus.PRESENT.name, markedByTeacherId = "TCH101"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1003", studentName = "Ethan Davies", rollNumber = "103", classId = "CLASS_10A", status = AttendanceStatus.ABSENT.name, markedByTeacherId = "TCH101", remarks = "Parent informed: Flu"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1004", studentName = "Mia Tanaka", rollNumber = "104", classId = "CLASS_10A", status = AttendanceStatus.PRESENT.name, markedByTeacherId = "TCH101"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1005", studentName = "Noah Williams", rollNumber = "105", classId = "CLASS_10A", status = AttendanceStatus.LATE.name, markedByTeacherId = "TCH101", remarks = "School bus delay"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1006", studentName = "Ava Robinson", rollNumber = "106", classId = "CLASS_10A", status = AttendanceStatus.PRESENT.name, markedByTeacherId = "TCH101")
            )

            val attendance10B = listOf(
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1007", studentName = "Liam Johnson", rollNumber = "201", classId = "CLASS_10B", status = AttendanceStatus.PRESENT.name, markedByTeacherId = "TCH102"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1008", studentName = "Emma Clark", rollNumber = "202", classId = "CLASS_10B", status = AttendanceStatus.ABSENT.name, markedByTeacherId = "TCH102", remarks = "Medical appointment"),
                AttendanceRecord(id = UUID.randomUUID().toString(), date = todayStr, studentId = "STU_1009", studentName = "Benjamin Lee", rollNumber = "203", classId = "CLASS_10B", status = AttendanceStatus.PRESENT.name, markedByTeacherId = "TCH102")
            )

            db.attendanceDao().insertAttendance(attendance10A + attendance10B)

            // Seed Attendance Submissions
            val submission10A = AttendanceSubmissionRecord(
                id = "CLASS_10A_$todayStr",
                date = todayStr,
                classId = "CLASS_10A",
                className = "Grade 10 - Section A",
                classTeacherId = "TCH101",
                classTeacherName = "Prof. Eleanor Woods",
                totalStudents = 6,
                presentStudents = 5,
                absentStudents = 1,
                absentStudentNames = "Ethan Davies",
                absentNotes = "Ethan Davies: Parent informed: Flu",
                submittedStatus = "SUBMITTED",
                submittedAt = System.currentTimeMillis() - 3600000
            )

            val submission10B = AttendanceSubmissionRecord(
                id = "CLASS_10B_$todayStr",
                date = todayStr,
                classId = "CLASS_10B",
                className = "Grade 10 - Section B",
                classTeacherId = "TCH102",
                classTeacherName = "Mr. Robert Chen",
                totalStudents = 3,
                presentStudents = 2,
                absentStudents = 1,
                absentStudentNames = "Emma Clark",
                absentNotes = "Emma Clark: Medical appointment",
                submittedStatus = "SUBMITTED",
                submittedAt = System.currentTimeMillis() - 1800000
            )

            db.attendanceSubmissionDao().insertSubmissions(listOf(submission10A, submission10B))

            // 6. Initial Homework
            val homeworkList = listOf(
                Homework(
                    id = UUID.randomUUID().toString(),
                    classId = "CLASS_10A",
                    teacherId = "TCH101",
                    teacherName = "Prof. Eleanor Woods",
                    subject = "Mathematics",
                    title = "Quadratic Equations Exercise 4.2",
                    description = "Solve problems 1 to 15 on page 84. Show complete step-by-step factorization.",
                    assignedDate = todayStr,
                    dueDate = "Tomorrow 9:00 AM",
                    status = "ACTIVE"
                ),
                Homework(
                    id = UUID.randomUUID().toString(),
                    classId = "CLASS_10A",
                    teacherId = "TCH101",
                    teacherName = "Prof. Eleanor Woods",
                    subject = "Trigonometry",
                    title = "Sine and Cosine Law Practice",
                    description = "Review triangle heights and submit proof worksheet.",
                    assignedDate = todayStr,
                    dueDate = "Friday 11:30 AM",
                    status = "ACTIVE"
                ),
                Homework(
                    id = UUID.randomUUID().toString(),
                    classId = "CLASS_10B",
                    teacherId = "TCH102",
                    teacherName = "Mr. Robert Chen",
                    subject = "Physics",
                    title = "Newton's Third Law Lab Report",
                    description = "Write a 2-page report on action-reaction pairs with circuit diagram.",
                    assignedDate = todayStr,
                    dueDate = "Thursday 3:00 PM",
                    status = "ACTIVE"
                )
            )
            db.homeworkDao().insertHomeworkList(homeworkList)

            // 7. Initial Marks
            val marksList = listOf(
                StudentMark(id = UUID.randomUUID().toString(), studentId = "STU_1001", studentName = "Lucas Bennett", rollNumber = "101", classId = "CLASS_10A", examName = "Mid-Term Examination", subject = "Mathematics", maxMarks = 100, marksObtained = 94.5, grade = "A+", remarks = "Outstanding analytical ability", date = todayStr),
                StudentMark(id = UUID.randomUUID().toString(), studentId = "STU_1002", studentName = "Sophia Martinez", rollNumber = "102", classId = "CLASS_10A", examName = "Mid-Term Examination", subject = "Mathematics", maxMarks = 100, marksObtained = 88.0, grade = "A", remarks = "Very thorough working", date = todayStr),
                StudentMark(id = UUID.randomUUID().toString(), studentId = "STU_1003", studentName = "Ethan Davies", rollNumber = "103", classId = "CLASS_10A", examName = "Mid-Term Examination", subject = "Mathematics", maxMarks = 100, marksObtained = 76.0, grade = "B", remarks = "Good effort, focus on geometry", date = todayStr),
                StudentMark(id = UUID.randomUUID().toString(), studentId = "STU_1004", studentName = "Mia Tanaka", rollNumber = "104", classId = "CLASS_10A", examName = "Mid-Term Examination", subject = "Mathematics", maxMarks = 100, marksObtained = 98.0, grade = "A+", remarks = "Top performer in class", date = todayStr),
                StudentMark(id = UUID.randomUUID().toString(), studentId = "STU_1005", studentName = "Noah Williams", rollNumber = "105", classId = "CLASS_10A", examName = "Mid-Term Examination", subject = "Mathematics", maxMarks = 100, marksObtained = 82.5, grade = "B+", remarks = "Consistent improvement", date = todayStr),
                StudentMark(id = UUID.randomUUID().toString(), studentId = "STU_1006", studentName = "Ava Robinson", rollNumber = "106", classId = "CLASS_10A", examName = "Mid-Term Examination", subject = "Mathematics", maxMarks = 100, marksObtained = 91.0, grade = "A", remarks = "Excellent clarity and speed", date = todayStr)
            )
            db.markDao().insertMarks(marksList)

            // 8. Initial Announcements
            val announcements = listOf(
                Announcement(
                    id = UUID.randomUUID().toString(),
                    title = "Annual Science Exhibition & Robotics Fair",
                    content = "The annual inter-school science fair will take place next Friday in the main auditorium. All project submissions must be verified by class teachers.",
                    targetAudience = "ALL",
                    priority = AnnouncementPriority.URGENT.name,
                    authorName = "Principal Dr. Arthur Vance",
                    date = todayStr
                ),
                Announcement(
                    id = UUID.randomUUID().toString(),
                    title = "Parent-Teacher Conference Schedule",
                    content = "Parent-Teacher meetings for Grades 9 and 10 are scheduled for this coming Saturday from 9:00 AM to 1:00 PM. Teachers should have student grade cards prepared.",
                    targetAudience = "ALL",
                    priority = AnnouncementPriority.NORMAL.name,
                    authorName = "Principal Dr. Arthur Vance",
                    date = todayStr
                ),
                Announcement(
                    id = UUID.randomUUID().toString(),
                    title = "Math Olympiad Registration - Grade 10",
                    content = "Interested students in Grade 10 should submit their names to Prof. Eleanor Woods by Wednesday.",
                    targetAudience = "CLASS_10A",
                    priority = AnnouncementPriority.EVENT.name,
                    authorName = "Prof. Eleanor Woods",
                    date = todayStr
                )
            )
            db.announcementDao().insertAnnouncements(announcements)

            // 9. Initial Leave Requests
            val leaves = listOf(
                LeaveRequest(
                    id = UUID.randomUUID().toString(),
                    teacherId = "TCH102",
                    teacherName = "Mr. Robert Chen",
                    leaveType = LeaveType.CASUAL.name,
                    startDate = todayStr,
                    endDate = todayStr,
                    daysCount = 1,
                    reason = "Attending regional education conference on digital STEM teaching.",
                    status = LeaveStatus.PENDING.name,
                    principalComment = null
                ),
                LeaveRequest(
                    id = UUID.randomUUID().toString(),
                    teacherId = "TCH103",
                    teacherName = "Ms. Sarah Jenkins",
                    leaveType = LeaveType.SICK.name,
                    startDate = "2026-08-20",
                    endDate = "2026-08-21",
                    daysCount = 2,
                    reason = "Dental surgery recovery.",
                    status = LeaveStatus.APPROVED.name,
                    principalComment = "Approved. Substitute teacher arranged."
                )
            )
            db.leaveDao().insertLeaveRequests(leaves)
        }
    }
}
