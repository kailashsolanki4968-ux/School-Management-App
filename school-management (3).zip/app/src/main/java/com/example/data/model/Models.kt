package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    PRINCIPAL,
    TEACHER
}

enum class AccountStatus {
    APPROVED,
    PENDING,
    REJECTED
}

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    EXCUSED
}

enum class LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}

enum class LeaveType {
    SICK,
    CASUAL,
    EMERGENCY,
    ANNUAL
}

enum class AnnouncementPriority {
    NORMAL,
    URGENT,
    EVENT
}

@Entity(tableName = "users")
data class UserAccount(
    @PrimaryKey val id: String, // e.g. "PRIN001", "TCH101", or custom username
    val name: String,
    val email: String,
    val phone: String,
    val role: String, // UserRole.PRINCIPAL.name or UserRole.TEACHER.name
    val passwordHash: String,
    val securityQuestion: String,
    val securityAnswer: String,
    val status: String = AccountStatus.APPROVED.name,
    val assignedClassId: String? = null,
    val subject: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "classes")
data class SchoolClass(
    @PrimaryKey val id: String, // e.g. "CLASS_10A"
    val name: String, // e.g. "Grade 10 - Section A"
    val grade: String, // e.g. "Grade 10"
    val section: String, // e.g. "A"
    val classTeacherId: String? = null,
    val roomNumber: String = "Room 101"
)

@Entity(tableName = "students")
data class Student(
    @PrimaryKey val id: String, // e.g. "STU_1001"
    val rollNumber: String,
    val name: String,
    val classId: String,
    val gender: String = "Male",
    val parentName: String = "",
    val parentPhone: String = "",
    val emergencyContact: String = "",
    val address: String = ""
)

@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey val id: String, // UUID
    val date: String, // "yyyy-MM-dd"
    val studentId: String,
    val studentName: String,
    val rollNumber: String,
    val classId: String,
    val status: String, // AttendanceStatus
    val markedByTeacherId: String = "",
    val remarks: String? = null,
    val isSubmitted: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "attendance_submissions")
data class AttendanceSubmissionRecord(
    @PrimaryKey val id: String, // "${classId}_${date}"
    val date: String, // "yyyy-MM-dd"
    val classId: String,
    val className: String,
    val classTeacherId: String,
    val classTeacherName: String,
    val totalStudents: Int,
    val presentStudents: Int,
    val absentStudents: Int,
    val absentStudentNames: String, // Comma separated absent students or "None"
    val absentNotes: String, // Combined notes for absentees or "No notes"
    val submittedStatus: String = "SUBMITTED", // "SUBMITTED", "PENDING", "APPROVED"
    val submittedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey val id: String, // UUID
    val classId: String,
    val teacherId: String,
    val teacherName: String,
    val subject: String,
    val title: String,
    val description: String,
    val assignedDate: String, // "yyyy-MM-dd"
    val dueDate: String, // "yyyy-MM-dd"
    val status: String = "ACTIVE"
)

@Entity(tableName = "student_marks")
data class StudentMark(
    @PrimaryKey val id: String, // UUID
    val studentId: String,
    val studentName: String,
    val rollNumber: String,
    val classId: String,
    val examName: String, // e.g. "Mid-Term Exam", "Unit Test 1"
    val subject: String,
    val maxMarks: Int = 100,
    val marksObtained: Double = 0.0,
    val grade: String = "A",
    val remarks: String? = null,
    val date: String = ""
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey val id: String, // UUID
    val title: String,
    val content: String,
    val targetAudience: String = "ALL", // "ALL" or specific classId
    val priority: String = AnnouncementPriority.NORMAL.name,
    val authorName: String = "Principal",
    val date: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "leave_requests")
data class LeaveRequest(
    @PrimaryKey val id: String, // UUID
    val teacherId: String,
    val teacherName: String,
    val leaveType: String, // LeaveType
    val startDate: String,
    val endDate: String,
    val daysCount: Int = 1,
    val reason: String,
    val status: String = LeaveStatus.PENDING.name,
    val principalComment: String? = null,
    val appliedAt: Long = System.currentTimeMillis()
)
