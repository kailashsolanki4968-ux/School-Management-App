package com.example.data.cloud

import android.content.Context
import com.example.data.model.AccountStatus
import com.example.data.model.ChatMessage
import com.example.data.model.School
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.security.PasswordSecurity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * CloudDatabaseService manages cloud synchronization and global multi-device authentication.
 * It serves as the authoritative source of truth across devices and enforces strict School ID
 * data isolation.
 */
class CloudDatabaseService(context: Context) {

    private val cloudStorageDir = File(context.filesDir, "cloud_storage").apply { mkdirs() }
    private val cloudUsersFile = File(cloudStorageDir, "cloud_users.json")
    private val cloudSchoolsFile = File(cloudStorageDir, "cloud_schools.json")
    private val cloudMessagesFile = File(cloudStorageDir, "cloud_messages.json")
    private val mutex = Mutex()

    init {
        ensureInitialCloudData()
    }

    private fun ensureInitialCloudData() {
        if (!cloudSchoolsFile.exists()) {
            val defaultSchool = School(
                id = "SCH_OAKRIDGE_101",
                name = "Oakridge International School",
                code = "OAK101",
                address = "101 Crestview Boulevard",
                principalId = "PRIN001",
                contactEmail = "principal@oakridge.edu",
                contactPhone = "+1 (555) 234-5678"
            )
            saveSchoolsToCloud(listOf(defaultSchool))
        }

        if (!cloudUsersFile.exists()) {
            val defaultSalt1 = PasswordSecurity.generateSalt()
            val defaultSalt2 = PasswordSecurity.generateSalt()
            val defaultSalt3 = PasswordSecurity.generateSalt()
            val defaultSalt4 = PasswordSecurity.generateSalt()

            val demoUsers = listOf(
                UserAccount(
                    id = "PRIN001",
                    schoolId = "SCH_OAKRIDGE_101",
                    name = "Dr. Eleanor Vance",
                    email = "eleanor.vance@oakridge.edu",
                    phone = "+1 555-0101",
                    role = UserRole.PRINCIPAL.name,
                    passwordHash = PasswordSecurity.hashPassword("principal123", defaultSalt1),
                    passwordSalt = defaultSalt1,
                    securityQuestion = "What was the name of your first school?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Lincoln High"),
                    status = AccountStatus.APPROVED.name,
                    subject = "Administration"
                ),
                UserAccount(
                    id = "TCH101",
                    schoolId = "SCH_OAKRIDGE_101",
                    name = "Sarah Jenkins",
                    email = "sarah.jenkins@oakridge.edu",
                    phone = "+1 555-0102",
                    role = UserRole.TEACHER.name,
                    passwordHash = PasswordSecurity.hashPassword("teacher123", defaultSalt2),
                    passwordSalt = defaultSalt2,
                    securityQuestion = "What was the name of your first school?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Springfield Academy"),
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_10A",
                    subject = "Mathematics"
                ),
                UserAccount(
                    id = "TCH102",
                    schoolId = "SCH_OAKRIDGE_101",
                    name = "Robert Sterling",
                    email = "robert.sterling@oakridge.edu",
                    phone = "+1 555-0103",
                    role = UserRole.TEACHER.name,
                    passwordHash = PasswordSecurity.hashPassword("teacher123", defaultSalt3),
                    passwordSalt = defaultSalt3,
                    securityQuestion = "What is your mother's maiden name?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Sterling"),
                    status = AccountStatus.APPROVED.name,
                    assignedClassId = "CLASS_10B",
                    subject = "Science"
                ),
                UserAccount(
                    id = "PAR101",
                    schoolId = "SCH_OAKRIDGE_101",
                    name = "Michael Hayes",
                    email = "michael.hayes@example.com",
                    phone = "+1 555-0104",
                    role = UserRole.PARENT.name,
                    passwordHash = PasswordSecurity.hashPassword("parent123", defaultSalt4),
                    passwordSalt = defaultSalt4,
                    securityQuestion = "What city were you born in?",
                    securityAnswer = PasswordSecurity.hashSecurityAnswer("Chicago"),
                    status = AccountStatus.APPROVED.name,
                    linkedStudentIds = "STU_1001,STU_1002"
                )
            )
            saveUsersToCloud(demoUsers)
        }

        if (!cloudMessagesFile.exists()) {
            val demoMessages = listOf(
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    schoolId = "SCH_OAKRIDGE_101",
                    studentId = "STU_1001",
                    studentName = "Liam Hayes",
                    senderId = "TCH101",
                    senderName = "Sarah Jenkins",
                    senderRole = "TEACHER",
                    receiverId = "PAR101",
                    receiverName = "Michael Hayes",
                    receiverRole = "PARENT",
                    message = "Hello Mr. Hayes, Liam showed exceptional understanding in today's Mathematics session on Trigonometry.",
                    timestamp = System.currentTimeMillis() - 7200000,
                    status = "DELIVERED"
                ),
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    schoolId = "SCH_OAKRIDGE_101",
                    studentId = "STU_1001",
                    studentName = "Liam Hayes",
                    senderId = "PAR101",
                    senderName = "Michael Hayes",
                    senderRole = "PARENT",
                    receiverId = "TCH101",
                    receiverName = "Sarah Jenkins",
                    receiverRole = "TEACHER",
                    message = "Thank you so much Ms. Jenkins! We have been encouraging him to practice the chapter problems daily.",
                    timestamp = System.currentTimeMillis() - 3600000,
                    status = "DELIVERED"
                )
            )
            saveMessagesToCloud(demoMessages)
        }
    }

    // --- Schools Cloud Operations ---
    private fun readSchoolsFromFile(): List<School> {
        if (!cloudSchoolsFile.exists()) return emptyList()
        return try {
            val jsonStr = cloudSchoolsFile.readText()
            val array = JSONArray(jsonStr)
            val list = mutableListOf<School>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    School(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        code = obj.optString("code", ""),
                        address = obj.optString("address", ""),
                        principalId = obj.optString("principalId", "PRIN001"),
                        contactEmail = obj.optString("contactEmail", ""),
                        contactPhone = obj.optString("contactPhone", ""),
                        currency = obj.optString("currency", "₹"),
                        currencyCode = obj.optString("currencyCode", "INR"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getCloudSchools(): List<School> = withContext(Dispatchers.IO) {
        mutex.withLock {
            readSchoolsFromFile()
        }
    }

    suspend fun getCloudSchoolById(schoolId: String): School? = withContext(Dispatchers.IO) {
        getCloudSchools().find { it.id.equals(schoolId.trim(), ignoreCase = true) }
    }

    suspend fun registerSchool(school: School): Result<School> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val schools = readSchoolsFromFile().toMutableList()
            if (schools.any { it.id.equals(school.id.trim(), ignoreCase = true) }) {
                return@withContext Result.failure(Exception("School ID '${school.id}' is already registered."))
            }
            schools.add(school)
            saveSchoolsToCloud(schools)
            Result.success(school)
        }
    }

    suspend fun updateCloudSchoolCurrency(schoolId: String, currency: String, currencyCode: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val schools = readSchoolsFromFile().map {
                if (it.id.equals(schoolId.trim(), ignoreCase = true)) {
                    it.copy(currency = currency, currencyCode = currencyCode)
                } else {
                    it
                }
            }
            saveSchoolsToCloud(schools)
            Result.success(Unit)
        }
    }

    private fun saveSchoolsToCloud(schools: List<School>) {
        val array = JSONArray()
        for (s in schools) {
            val obj = JSONObject().apply {
                put("id", s.id)
                put("name", s.name)
                put("code", s.code)
                put("address", s.address)
                put("principalId", s.principalId)
                put("contactEmail", s.contactEmail)
                put("contactPhone", s.contactPhone)
                put("currency", s.currency)
                put("currencyCode", s.currencyCode)
                put("createdAt", s.createdAt)
            }
            array.put(obj)
        }
        cloudSchoolsFile.writeText(array.toString(2))
    }

    // --- Users Cloud Operations (Multi-Device Authentication) ---
    private fun readUsersFromFile(): List<UserAccount> {
        if (!cloudUsersFile.exists()) return emptyList()
        return try {
            val jsonStr = cloudUsersFile.readText()
            val array = JSONArray(jsonStr)
            val list = mutableListOf<UserAccount>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    UserAccount(
                        id = obj.getString("id"),
                        schoolId = obj.optString("schoolId", "SCH_OAKRIDGE_101"),
                        name = obj.getString("name"),
                        email = obj.optString("email", ""),
                        phone = obj.optString("phone", ""),
                        role = obj.getString("role"),
                        passwordHash = obj.getString("passwordHash"),
                        passwordSalt = obj.optString("passwordSalt", ""),
                        securityQuestion = obj.optString("securityQuestion", "What was the name of your first school?"),
                        securityAnswer = obj.optString("securityAnswer", ""),
                        status = obj.optString("status", AccountStatus.APPROVED.name),
                        assignedClassId = if (obj.has("assignedClassId") && !obj.isNull("assignedClassId")) obj.getString("assignedClassId") else null,
                        linkedStudentIds = obj.optString("linkedStudentIds", ""),
                        subject = if (obj.has("subject") && !obj.isNull("subject")) obj.getString("subject") else null,
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getCloudUsers(): List<UserAccount> = withContext(Dispatchers.IO) {
        mutex.withLock {
            readUsersFromFile()
        }
    }

    suspend fun findCloudUser(userId: String): UserAccount? = withContext(Dispatchers.IO) {
        val cleanId = userId.trim()
        getCloudUsers().find { it.id.equals(cleanId, ignoreCase = true) }
    }

    suspend fun registerCloudUser(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val users = readUsersFromFile().toMutableList()
            val existingIndex = users.indexOfFirst { it.id.equals(user.id.trim(), ignoreCase = true) }
            if (existingIndex >= 0) {
                return@withContext Result.failure(Exception("Account ID '${user.id}' already exists in cloud system."))
            }

            // Verify school exists or auto-register default
            val schools = readSchoolsFromFile()
            if (schools.none { it.id.equals(user.schoolId.trim(), ignoreCase = true) }) {
                // If it's a new principal creating a school, allow it
                if (user.role == UserRole.PRINCIPAL.name) {
                    val newSchool = School(
                        id = user.schoolId,
                        name = "${user.name}'s Academy",
                        code = user.schoolId.takeLast(4).uppercase(),
                        principalId = user.id
                    )
                    saveSchoolsToCloud(schools + newSchool)
                } else {
                    return@withContext Result.failure(Exception("School ID '${user.schoolId}' not found. Please check your School ID."))
                }
            }

            users.add(user)
            saveUsersToCloud(users)
            Result.success(user)
        }
    }

    suspend fun updateCloudUser(user: UserAccount): Result<UserAccount> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val users = readUsersFromFile().toMutableList()
            val index = users.indexOfFirst { it.id.equals(user.id.trim(), ignoreCase = true) }
            if (index >= 0) {
                users[index] = user
                saveUsersToCloud(users)
                Result.success(user)
            } else {
                users.add(user)
                saveUsersToCloud(users)
                Result.success(user)
            }
        }
    }

    suspend fun updateCloudUserPassword(userId: String, newPasswordHash: String, newSalt: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val users = readUsersFromFile().toMutableList()
            val index = users.indexOfFirst { it.id.equals(userId.trim(), ignoreCase = true) }
            if (index < 0) {
                return@withContext Result.failure(Exception("User ID '$userId' not found."))
            }
            val user = users[index]
            users[index] = user.copy(passwordHash = newPasswordHash, passwordSalt = newSalt)
            saveUsersToCloud(users)
            Result.success(Unit)
        }
    }

    suspend fun updateCloudTeacherStatus(teacherId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        updateCloudUserStatus(teacherId, status)
    }

    suspend fun updateCloudUserStatus(userId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val users = readUsersFromFile().toMutableList()
            val index = users.indexOfFirst { it.id.equals(userId.trim(), ignoreCase = true) }
            if (index >= 0) {
                users[index] = users[index].copy(status = status)
                saveUsersToCloud(users)
                Result.success(Unit)
            } else {
                Result.failure(Exception("User not found."))
            }
        }
    }

    suspend fun linkParentStudentInCloud(parentId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val users = readUsersFromFile().toMutableList()
            val index = users.indexOfFirst { it.id.equals(parentId.trim(), ignoreCase = true) }
            if (index >= 0) {
                val currentIds = users[index].linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
                currentIds.add(studentId.trim())
                users[index] = users[index].copy(linkedStudentIds = currentIds.joinToString(","))
                saveUsersToCloud(users)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Parent not found."))
            }
        }
    }

    suspend fun unlinkParentStudentInCloud(parentId: String, studentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val users = readUsersFromFile().toMutableList()
            val index = users.indexOfFirst { it.id.equals(parentId.trim(), ignoreCase = true) }
            if (index >= 0) {
                val currentIds = users[index].linkedStudentIds.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet()
                currentIds.remove(studentId.trim())
                users[index] = users[index].copy(linkedStudentIds = currentIds.joinToString(","))
                saveUsersToCloud(users)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Parent not found."))
            }
        }
    }

    // --- Cloud Chat Messages Operations ---
    private fun readMessagesFromFile(): List<ChatMessage> {
        if (!cloudMessagesFile.exists()) return emptyList()
        return try {
            val jsonStr = cloudMessagesFile.readText()
            val array = JSONArray(jsonStr)
            val list = mutableListOf<ChatMessage>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ChatMessage(
                        id = obj.getString("id"),
                        schoolId = obj.optString("schoolId", "SCH_OAKRIDGE_101"),
                        studentId = obj.getString("studentId"),
                        studentName = obj.optString("studentName", ""),
                        senderId = obj.getString("senderId"),
                        senderName = obj.optString("senderName", ""),
                        senderRole = obj.optString("senderRole", "TEACHER"),
                        receiverId = obj.getString("receiverId"),
                        receiverName = obj.optString("receiverName", ""),
                        receiverRole = obj.optString("receiverRole", "PARENT"),
                        message = obj.getString("message"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        status = obj.optString("status", "SENT")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveMessagesToCloud(messages: List<ChatMessage>) {
        val array = JSONArray()
        for (m in messages) {
            val obj = JSONObject().apply {
                put("id", m.id)
                put("schoolId", m.schoolId)
                put("studentId", m.studentId)
                put("studentName", m.studentName)
                put("senderId", m.senderId)
                put("senderName", m.senderName)
                put("senderRole", m.senderRole)
                put("receiverId", m.receiverId)
                put("receiverName", m.receiverName)
                put("receiverRole", m.receiverRole)
                put("message", m.message)
                put("timestamp", m.timestamp)
                put("status", m.status)
            }
            array.put(obj)
        }
        cloudMessagesFile.writeText(array.toString(2))
    }

    suspend fun getCloudMessages(schoolId: String, studentId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        mutex.withLock {
            readMessagesFromFile().filter {
                it.schoolId.equals(schoolId.trim(), ignoreCase = true) &&
                        it.studentId.equals(studentId.trim(), ignoreCase = true)
            }.sortedBy { it.timestamp }
        }
    }

    suspend fun getCloudMessagesForSchool(schoolId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        mutex.withLock {
            readMessagesFromFile().filter {
                it.schoolId.equals(schoolId.trim(), ignoreCase = true)
            }.sortedBy { it.timestamp }
        }
    }

    suspend fun sendCloudMessage(message: ChatMessage): Result<ChatMessage> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val messages = readMessagesFromFile().toMutableList()
            messages.add(message)
            saveMessagesToCloud(messages)
            Result.success(message)
        }
    }


    private fun saveUsersToCloud(users: List<UserAccount>) {
        val array = JSONArray()
        for (u in users) {
            val obj = JSONObject().apply {
                put("id", u.id)
                put("schoolId", u.schoolId)
                put("name", u.name)
                put("email", u.email)
                put("phone", u.phone)
                put("role", u.role)
                put("passwordHash", u.passwordHash)
                put("passwordSalt", u.passwordSalt)
                put("securityQuestion", u.securityQuestion)
                put("securityAnswer", u.securityAnswer)
                put("status", u.status)
                if (u.assignedClassId != null) put("assignedClassId", u.assignedClassId)
                put("linkedStudentIds", u.linkedStudentIds)
                if (u.subject != null) put("subject", u.subject)
                put("createdAt", u.createdAt)
            }
            array.put(obj)
        }
        cloudUsersFile.writeText(array.toString(2))
    }

    companion object {
        @Volatile
        private var INSTANCE: CloudDatabaseService? = null

        fun getInstance(context: Context): CloudDatabaseService {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudDatabaseService(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
