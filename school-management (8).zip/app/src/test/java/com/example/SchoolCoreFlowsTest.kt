package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.cloud.CloudDatabaseService
import com.example.data.db.AppDatabase
import com.example.data.model.AccountStatus
import com.example.data.model.ActivityRecord
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.Student
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.session.SessionManager
import com.example.data.repository.SchoolRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SchoolCoreFlowsTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var cloudService: CloudDatabaseService
    private lateinit var sessionManager: SessionManager
    private lateinit var repository: SchoolRepository

    @Before
    fun setUp() = runTest {
        context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        AppDatabase.ensureSeedData(db)

        cloudService = CloudDatabaseService(context)
        sessionManager = SessionManager(context)
        repository = SchoolRepository(db, sessionManager, cloudService)
    }

    @After
    fun tearDown() {
        db.close()
        val cloudDir = File(context.filesDir, "cloud_school_db")
        if (cloudDir.exists()) {
            cloudDir.deleteRecursively()
        }
    }

    @Test
    fun testPrincipalLoginAndSeedData() = runTest {
        val loginResult = repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        assertTrue("Principal login should succeed", loginResult.isSuccess)

        val session = repository.sessionState.value
        assertNotNull("Session should exist", session)
        assertEquals(UserRole.PRINCIPAL.name, session?.role)
        assertEquals("SCH_OAKRIDGE_101", session?.schoolId)

        val teachers = repository.getAllTeachers().first()
        assertTrue("Seed teachers should be populated", teachers.isNotEmpty())

        val classes = repository.getAllClasses().first()
        assertTrue("Seed classes should be populated", classes.isNotEmpty())
    }

    @Test
    fun testStudentCreationAndPermanentStudentID() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_9901"
        val newStudent = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "15",
            name = "Aarav Sharma",
            classId = "CLASS_10A",
            gender = "Male",
            parentName = "Rajesh Sharma",
            parentPhone = "+91 9876543210",
            emergencyContact = "+91 9876543210",
            address = "42 Green Valley, New Delhi"
        )
        repository.insertStudent(newStudent)

        val retrievedStudent = repository.getStudentById(studentId)
        assertNotNull("Student should be retrievable by generated student ID", retrievedStudent)
        assertEquals("Aarav Sharma", retrievedStudent?.name)
        assertEquals("15", retrievedStudent?.rollNumber)
    }

    @Test
    fun testParentRegistrationAndPrincipalApprovalFlow() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_9902"
        val student = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "16",
            name = "Diya Patel",
            classId = "CLASS_10A",
            gender = "Female",
            parentName = "Sunita Patel",
            parentPhone = "+91 9123456780"
        )
        repository.insertStudent(student)

        val parentId = "PAR_TEST_9902"
        val parentUser = UserAccount(
            id = parentId,
            schoolId = "SCH_OAKRIDGE_101",
            name = "Sunita Patel",
            email = "sunita@example.com",
            phone = "+91 9123456780",
            role = UserRole.PARENT.name,
            passwordHash = "",
            securityQuestion = "What is your pet name?",
            securityAnswer = "",
            status = AccountStatus.PENDING.name,
            linkedStudentIds = studentId
        )

        val registerResult = repository.registerUser(parentUser, "password123", "Fluffy")
        assertTrue("Parent registration should succeed", registerResult.isSuccess)

        val pendingParents = repository.getPendingParents().first()
        assertTrue("Pending parents list should include the new registration", pendingParents.any { it.id == parentId })

        repository.approveParentAndLinkStudents(parentId)

        val approvedUser = repository.getUserById(parentId)
        assertNotNull(approvedUser)
        assertEquals(AccountStatus.APPROVED.name, approvedUser?.status)
        assertEquals(studentId, approvedUser?.linkedStudentIds)
    }

    @Test
    fun testAttendanceAndMarksWorkflow() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val students = repository.getStudentsByClass("CLASS_10A").first()
        assertTrue("Students should exist in class 10A", students.isNotEmpty())
        val firstStudent = students.first()

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val attendanceRecord = AttendanceRecord(
            id = UUID.randomUUID().toString(),
            schoolId = "SCH_OAKRIDGE_101",
            date = today,
            studentId = firstStudent.id,
            studentName = firstStudent.name,
            rollNumber = firstStudent.rollNumber,
            classId = firstStudent.classId,
            status = AttendanceStatus.PRESENT.name,
            markedByTeacherId = "TCH101"
        )
        repository.saveAttendance(listOf(attendanceRecord))

        val fetchedAtt = repository.getAttendanceByClassAndDateDirect(firstStudent.classId, today)
        assertTrue("Attendance should be recorded", fetchedAtt.any { it.studentId == firstStudent.id && it.status == AttendanceStatus.PRESENT.name })

        val marksDrafts = listOf(
            Pair(firstStudent, Pair(46.5, "Outstanding performance"))
        )
        val testRes = repository.createTestWithMarks(
            testId = UUID.randomUUID().toString(),
            classId = firstStudent.classId,
            className = "Grade 10 - Section A",
            testName = "Optics Unit Test",
            subject = "Physics",
            date = today,
            maxMarks = 50.0,
            teacherId = "TCH101",
            teacherName = "Dr. Teacher",
            marksDrafts = marksDrafts
        )
        assertTrue("Test and marks creation should succeed", testRes.isSuccess)

        val studentMarks = repository.getMarksByStudent(firstStudent.id).first()
        assertTrue("Student marks should be recorded", studentMarks.any { it.subject == "Physics" && it.marksObtained == 46.5 })
    }

    @Test
    fun testFeeManagementAndCurrencyCustomization() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")

        val studentId = "STU_TEST_FEE_01"
        val student = Student(
            id = studentId,
            schoolId = "SCH_OAKRIDGE_101",
            rollNumber = "99",
            name = "Rohan Verma",
            classId = "CLASS_10A",
            gender = "Male",
            parentName = "Sanjay Verma",
            parentPhone = "+91 9988776655"
        )
        repository.insertStudent(student)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        repository.setStudentTotalFee(student, 25000.0)
        val fee = repository.getFeeForStudent(student.id).first()
        assertNotNull("Student fee record should exist", fee)
        assertEquals(25000.0, fee?.totalFee ?: 0.0, 0.01)
        assertEquals(0.0, fee?.totalPaid ?: 0.0, 0.01)

        val payResult = repository.recordFeePayment(
            student = student,
            amount = 10000.0,
            date = today,
            paymentMode = "Online UPI",
            note = "Term 1 installment",
            recordedBy = "Principal Office"
        )
        assertTrue("Fee payment should succeed", payResult.isSuccess)

        val updatedFee = repository.getFeeForStudent(student.id).first()
        assertEquals(10000.0, updatedFee?.totalPaid ?: 0.0, 0.01)
        assertEquals(15000.0, updatedFee?.remainingFee ?: 0.0, 0.01)

        repository.updateSchoolCurrency("$", "USD")
        val school = repository.getSchoolById("SCH_OAKRIDGE_101")
        assertEquals("$", school?.currency)
        assertEquals("USD", school?.currencyCode)
    }

    @Test
    fun testTeacherSalaryAndHistoryLogs() = runTest {
        repository.login("PRIN001", "principal123", UserRole.PRINCIPAL.name, "SCH_OAKRIDGE_101")
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val salResult = repository.recordTeacherSalary(
            teacherId = "TCH101",
            teacherName = "Mr. David Miller",
            month = "September 2026",
            monthlySalary = 4500.0,
            amountPaid = 4500.0,
            paymentDate = today,
            remainingAmount = 0.0,
            paymentMode = "Bank Transfer",
            transactionRef = "TXN-88219",
            remarks = "Paid in full",
            recordedBy = "Principal"
        )
        assertTrue("Teacher salary record should succeed", salResult.isSuccess)

        val salaries = repository.getSalariesForTeacher("TCH101").first()
        assertTrue("Salary records should exist", salaries.any { it.month == "September 2026" && it.amountPaid == 4500.0 })

        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = "SCH_OAKRIDGE_101",
            date = today,
            time = "10:30 AM",
            timestamp = System.currentTimeMillis(),
            category = "FINANCE",
            personName = "Principal",
            personRole = "PRINCIPAL",
            action = "Updated School Currency to USD",
            performedBy = "PRIN001"
        )
        repository.logActivity(activity)

        val activities = repository.getAllActivities().first()
        assertTrue("Audit history should contain logged activity", activities.any { it.action == "Updated School Currency to USD" })
    }
}
