package com.example.ui.common

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object PhoneCallHelper {
    /**
     * Initiates a phone call via the Android dialer with the exact saved contact number.
     * Uses Intent.ACTION_DIAL so that the user can confirm before placing the call using
     * their device's active SIM card without needing dangerous CALL_PHONE permissions.
     */
    fun dialExactNumber(context: Context, rawNumber: String, contactName: String = "Contact") {
        val trimmed = rawNumber.trim()
        if (trimmed.isBlank()) {
            Toast.makeText(context, "No phone number on file for $contactName", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:${Uri.encode(trimmed)}")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open phone dialer on this device.", Toast.LENGTH_LONG).show()
        }
    }
}
