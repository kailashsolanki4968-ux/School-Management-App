package com.example.ui.principal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountStatus
import com.example.data.model.Announcement
import com.example.data.model.AnnouncementPriority
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.LeaveStatus
import com.example.data.model.SchoolClass
import com.example.data.model.SchoolTest
import com.example.data.model.Student
import com.example.data.model.StudentFee
import com.example.data.model.FeePayment
import com.example.data.model.StudentMark
import com.example.data.model.TeacherSalary
import com.example.data.model.ActivityRecord
import com.example.data.model.ActivityCategory
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.data.session.UserSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class PrincipalTab {
    DASHBOARD,
    TEACHERS,
    CLASSES_STUDENTS,
    ATTENDANCE,
    ACADEMICS,
    FEES,
    LEAVES,
    ANNOUNCEMENTS,
    HISTORY,
    SETTINGS
}

data class AttendanceSummary(
    val totalEnrolled: Int = 0,
    val presentCount: Int = 0,
    val absentCount: Int = 0,
    val lateCount: Int = 0,
    val excusedCount: Int = 0,
    val attendancePercentage: Double = 0.0
)

class PrincipalViewModel(val repository: SchoolRepository) : ViewModel() {

    val sessionState: StateFlow<UserSession?> = repository.sessionState

    val principalProfile: StateFlow<UserAccount?> = sessionState.flatMapLatest { sess ->
        if (sess != null) repository.getUserByIdFlow(sess.userId)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentTab = MutableStateFlow(PrincipalTab.DASHBOARD)
    val currentTab: StateFlow<PrincipalTab> = _currentTab.asStateFlow()

    private val _selectedDate = MutableStateFlow(
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    )
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _selectedClassId = MutableStateFlow<String?>(null)
    val selectedClassId: StateFlow<String?> = _selectedClassId.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    // Teachers
    val allTeachers: StateFlow<List<UserAccount>> = repository.getAllTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingTeachers: StateFlow<List<UserAccount>> = repository.getPendingTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val approvedTeachers: StateFlow<List<UserAccount>> = repository.getApprovedTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Parents
    val allParents: StateFlow<List<UserAccount>> = repository.getAllParents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingParents: StateFlow<List<UserAccount>> = repository.getPendingParents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val approvedParents: StateFlow<List<UserAccount>> = repository.getApprovedParents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // Classes & Students
    val allClasses: StateFlow<List<SchoolClass>> = repository.getAllClasses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStudents: StateFlow<List<Student>> = repository.getAllStudents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedClassStudents: StateFlow<List<Student>> = _selectedClassId
        .flatMapLatest { classId ->
            if (classId != null) repository.getStudentsByClass(classId)
            else repository.getAllStudents()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Attendance
    val todayAttendanceRecords: StateFlow<List<AttendanceRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAllAttendanceByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayAbsentStudents: StateFlow<List<AttendanceRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAbsentStudentsByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAttendanceSubmissions: StateFlow<List<AttendanceSubmissionRecord>> = repository.getAllAttendanceSubmissions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedDateSubmissions: StateFlow<List<AttendanceSubmissionRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getAttendanceSubmissionsByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendanceSummary: StateFlow<AttendanceSummary> = combine(
        allStudents,
        todayAttendanceRecords
    ) { students, records ->
        val total = students.size
        val present = records.count { it.status == "PRESENT" }
        val absent = records.count { it.status == "ABSENT" }
        val late = records.count { it.status == "LATE" }
        val excused = records.count { it.status == "EXCUSED" }
        val pct = if (total > 0 && records.isNotEmpty()) {
            ((present + late).toDouble() / total.toDouble()) * 100.0
        } else {
            0.0
        }
        AttendanceSummary(
            totalEnrolled = total,
            presentCount = present,
            absentCount = absent,
            lateCount = late,
            excusedCount = excused,
            attendancePercentage = pct
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AttendanceSummary())

    // Academics: Tests, Marks, Homework
    val allHomework: StateFlow<List<Homework>> = repository.getAllHomework()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMarks: StateFlow<List<StudentMark>> = repository.getAllMarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTests: StateFlow<List<SchoolTest>> = repository.getAllTests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Fees Management
    val allStudentFees: StateFlow<List<StudentFee>> = repository.getAllStudentFees()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFeePayments: StateFlow<List<FeePayment>> = repository.getAllPayments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Announcements
    val allAnnouncements: StateFlow<List<Announcement>> = repository.getAllAnnouncements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Leaves
    val allLeaves: StateFlow<List<LeaveRequest>> = repository.getAllLeaveRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingLeaves: StateFlow<List<LeaveRequest>> = repository.getPendingLeaveRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Teacher Salaries (Principal has access to all records)
    val allTeacherSalaries: StateFlow<List<TeacherSalary>> = repository.getAllSalaries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // School Operations & Activity History (Permanent Room Persistence)
    val allActivities: StateFlow<List<ActivityRecord>> = repository.getAllActivities()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // History Filters & Search
    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyCategoryFilter = MutableStateFlow("ALL")
    val historyCategoryFilter: StateFlow<String> = _historyCategoryFilter.asStateFlow()

    private val _historyDateFilter = MutableStateFlow("")
    val historyDateFilter: StateFlow<String> = _historyDateFilter.asStateFlow()

    private val _historyClassFilter = MutableStateFlow("")
    val historyClassFilter: StateFlow<String> = _historyClassFilter.asStateFlow()

    private val _historyPersonFilter = MutableStateFlow("")
    val historyPersonFilter: StateFlow<String> = _historyPersonFilter.asStateFlow()

    private data class ActivityFilters(
        val query: String,
        val category: String,
        val date: String,
        val classFilter: String,
        val personFilter: String
    )

    private val activityFiltersFlow: Flow<ActivityFilters> = combine(
        _historySearchQuery,
        _historyCategoryFilter,
        _historyDateFilter,
        _historyClassFilter,
        _historyPersonFilter
    ) { query, category, date, classFilter, personFilter ->
        ActivityFilters(query, category, date, classFilter, personFilter)
    }

    val filteredActivities: StateFlow<List<ActivityRecord>> = combine(
        allActivities,
        activityFiltersFlow
    ) { activities, filters ->
        activities.filter { item ->
            val matchesCategory = (filters.category == "ALL" || item.category.equals(filters.category, ignoreCase = true))
            val matchesDate = (filters.date.isBlank() || item.date.equals(filters.date.trim(), ignoreCase = true))
            val matchesClass = (filters.classFilter.isBlank() ||
                    item.classId.contains(filters.classFilter.trim(), ignoreCase = true) ||
                    item.className.contains(filters.classFilter.trim(), ignoreCase = true))
            val matchesPerson = (filters.personFilter.isBlank() ||
                    item.personName.contains(filters.personFilter.trim(), ignoreCase = true) ||
                    item.personId.contains(filters.personFilter.trim(), ignoreCase = true))
            val matchesQuery = filters.query.isBlank() ||
                    item.personName.contains(filters.query.trim(), ignoreCase = true) ||
                    item.action.contains(filters.query.trim(), ignoreCase = true) ||
                    item.details.contains(filters.query.trim(), ignoreCase = true) ||
                    item.className.contains(filters.query.trim(), ignoreCase = true) ||
                    item.category.contains(filters.query.trim(), ignoreCase = true) ||
                    item.date.contains(filters.query.trim(), ignoreCase = true) ||
                    (item.marks?.contains(filters.query.trim(), ignoreCase = true) == true) ||
                    (item.amount != null && item.amount.toString().contains(filters.query.trim()))
            matchesCategory && matchesDate && matchesClass && matchesPerson && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: PrincipalTab) {
        _currentTab.value = tab
    }

    fun selectDate(date: String) {
        _selectedDate.value = date
    }

    fun selectClass(classId: String?) {
        _selectedClassId.value = classId
    }

    fun clearMessage() {
        _message.value = null
    }

    // Teacher Management
    fun addTeacher(
        name: String,
        email: String,
        phone: String,
        subject: String,
        customId: String?,
        password: String
    ) {
        viewModelScope.launch {
            val id = customId?.trim()?.ifEmpty { null }
                ?: ("TCH_" + System.currentTimeMillis().toString().takeLast(4))

            val teacher = UserAccount(
                id = id,
                schoolId = repository.currentSchoolId,
                name = name.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = UserRole.TEACHER.name,
                passwordHash = "",
                securityQuestion = "What is your primary school?",
                securityAnswer = "",
                status = AccountStatus.APPROVED.name,
                assignedClassId = null,
                subject = subject.trim()
            )
            val rawPass = password.trim().ifEmpty { "teacher123" }
            val res = repository.registerUser(teacher, rawPass, "Greenwood")
            if (res.isSuccess) {
                _message.value = "Teacher account '${teacher.name}' ($id) added successfully."
            } else {
                _message.value = res.exceptionOrNull()?.message ?: "Failed to add teacher."
            }
        }
    }

    fun approveTeacher(teacherId: String) {
        viewModelScope.launch {
            repository.updateTeacherStatus(teacherId, AccountStatus.APPROVED.name)
            _message.value = "Teacher account '$teacherId' approved."
        }
    }

    fun rejectTeacher(teacherId: String) {
        viewModelScope.launch {
            repository.updateTeacherStatus(teacherId, AccountStatus.REJECTED.name)
            _message.value = "Teacher registration '$teacherId' rejected."
        }
    }

    // Parent Management & Linking Workflow
    fun approveParent(parentId: String) {
        viewModelScope.launch {
            repository.updateParentStatus(parentId, AccountStatus.APPROVED.name)
            _message.value = "Parent account '$parentId' approved."
        }
    }

    fun rejectParent(parentId: String) {
        viewModelScope.launch {
            repository.updateParentStatus(parentId, AccountStatus.REJECTED.name)
            _message.value = "Parent account '$parentId' rejected."
        }
    }

    fun linkParentToStudent(parentId: String, studentId: String) {
        viewModelScope.launch {
            repository.linkParentToStudent(parentId, studentId)
            _message.value = "Parent successfully linked to student."
        }
    }

    fun unlinkParentFromStudent(parentId: String, studentId: String) {
        viewModelScope.launch {
            repository.unlinkParentFromStudent(parentId, studentId)
            _message.value = "Parent unlinked from student."
        }
    }


    fun assignClassTeacher(teacherId: String, classId: String?) {
        viewModelScope.launch {
            repository.updateTeacherClass(teacherId, classId)
            _message.value = "Class assignment updated."
        }
    }

    fun resetTeacherPassword(teacherId: String, newPass: String) {
        viewModelScope.launch {
            repository.directUpdatePassword(teacherId, newPass)
            _message.value = "Password updated for teacher '$teacherId'."
        }
    }

    fun deleteTeacher(teacherId: String) {
        viewModelScope.launch {
            repository.deleteTeacher(teacherId)
            _message.value = "Teacher deleted."
        }
    }

    fun deleteParent(parentId: String) {
        viewModelScope.launch {
            repository.deleteParent(parentId)
            _message.value = "Parent account deleted."
        }
    }

    // Class Management
    fun addClass(name: String, grade: String, section: String, room: String, classTeacherId: String?) {
        viewModelScope.launch {
            val id = "CLASS_" + grade.replace(" ", "") + section.replace(" ", "")
            val schoolClass = SchoolClass(
                id = id,
                name = name.trim(),
                grade = grade.trim(),
                section = section.trim(),
                classTeacherId = classTeacherId,
                roomNumber = room.trim().ifEmpty { "Room 101" }
            )
            repository.insertClass(schoolClass)
            _message.value = "Class '$name' created successfully."
        }
    }

    fun deleteClass(classId: String) {
        viewModelScope.launch {
            repository.deleteClass(classId)
            _message.value = "Class deleted."
        }
    }

    // Student Management
    fun addStudent(
        rollNo: String,
        name: String,
        classId: String,
        gender: String,
        parentName: String,
        parentPhone: String,
        emergency: String,
        address: String
    ) {
        viewModelScope.launch {
            val id = "STU_" + System.currentTimeMillis().toString().takeLast(6)
            val student = Student(
                id = id,
                rollNumber = rollNo.trim(),
                name = name.trim(),
                classId = classId,
                gender = gender,
                parentName = parentName.trim(),
                parentPhone = parentPhone.trim(),
                emergencyContact = emergency.trim(),
                address = address.trim()
            )
            repository.insertStudent(student)
            _message.value = "Student '$name' enrolled."
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch {
            repository.deleteStudent(studentId)
            _message.value = "Student removed."
        }
    }

    // Announcements
    fun sendAnnouncement(title: String, content: String, targetAudience: String, priority: AnnouncementPriority) {
        viewModelScope.launch {
            val author = sessionState.value?.name ?: "Principal"
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val announcement = Announcement(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                content = content.trim(),
                targetAudience = targetAudience,
                priority = priority.name,
                authorName = author,
                date = todayStr
            )
            repository.insertAnnouncement(announcement)
            _message.value = "Announcement published."
        }
    }

    fun deleteAnnouncement(id: String) {
        viewModelScope.launch {
            repository.deleteAnnouncement(id)
            _message.value = "Announcement deleted."
        }
    }

    // Leave Management
    fun approveLeave(leaveId: String, comment: String?) {
        viewModelScope.launch {
            repository.updateLeaveStatus(leaveId, LeaveStatus.APPROVED.name, comment?.trim())
            _message.value = "Leave request approved."
        }
    }

    fun rejectLeave(leaveId: String, comment: String?) {
        viewModelScope.launch {
            repository.updateLeaveStatus(leaveId, LeaveStatus.REJECTED.name, comment?.trim())
            _message.value = "Leave request rejected."
        }
    }

    // Fee Management Actions
    fun setStudentTotalFee(student: Student, totalFee: Double) {
        viewModelScope.launch {
            repository.setStudentTotalFee(student, totalFee)
            _message.value = "Total fee set for ${student.name} to $$totalFee."
        }
    }

    fun recordFeePayment(
        student: Student,
        amount: Double,
        paymentDate: String,
        paymentMode: String,
        note: String
    ) {
        val prof = principalProfile.value
        val recordedBy = prof?.name ?: "Principal"

        viewModelScope.launch {
            val res = repository.recordFeePayment(
                student = student,
                amount = amount,
                date = paymentDate,
                paymentMode = paymentMode,
                note = note,
                recordedBy = recordedBy
            )
            if (res.isSuccess) {
                _message.value = "Payment of $$amount recorded for ${student.name}!"
            } else {
                _message.value = res.exceptionOrNull()?.message ?: "Failed to record payment."
            }
        }
    }

    fun deleteFeePayment(paymentId: String, studentId: String) {
        viewModelScope.launch {
            repository.deleteFeePayment(paymentId, studentId)
            _message.value = "Payment record removed."
        }
    }

    fun getFeeForStudent(studentId: String): Flow<StudentFee?> {
        return repository.getFeeForStudent(studentId)
    }

    fun getPaymentsByStudent(studentId: String): Flow<List<FeePayment>> {
        return repository.getPaymentsByStudent(studentId)
    }

    // Test & Academic Actions
    fun getMarksByTest(testId: String): Flow<List<StudentMark>> {
        return repository.getMarksByTest(testId)
    }

    fun deleteTest(testId: String) {
        viewModelScope.launch {
            repository.deleteTest(testId)
            _message.value = "Test record removed."
        }
    }

    fun deleteMark(markId: String) {
        viewModelScope.launch {
            repository.deleteMark(markId)
            _message.value = "Mark record removed."
        }
    }

    // History filter helpers
    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun setHistoryCategoryFilter(category: String) {
        _historyCategoryFilter.value = category
    }

    fun setHistoryDateFilter(date: String) {
        _historyDateFilter.value = date
    }

    fun setHistoryClassFilter(classFilter: String) {
        _historyClassFilter.value = classFilter
    }

    fun setHistoryPersonFilter(person: String) {
        _historyPersonFilter.value = person
    }

    fun clearHistoryFilters() {
        _historySearchQuery.value = ""
        _historyCategoryFilter.value = "ALL"
        _historyDateFilter.value = ""
        _historyClassFilter.value = ""
        _historyPersonFilter.value = ""
    }

    fun deleteActivity(id: String) {
        viewModelScope.launch {
            repository.deleteActivity(id)
            _message.value = "History record removed."
        }
    }

    fun logCustomActivity(
        category: String,
        personName: String,
        action: String,
        details: String,
        amount: Double? = null,
        marks: String? = null,
        className: String = ""
    ) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val activity = ActivityRecord(
            id = UUID.randomUUID().toString(),
            schoolId = repository.currentSchoolId,
            date = today,
            time = timeStr,
            timestamp = System.currentTimeMillis(),
            category = category,
            personName = personName,
            personRole = "PRINCIPAL",
            action = action,
            amount = amount,
            marks = marks,
            details = details,
            className = className,
            performedBy = principalProfile.value?.name ?: "Principal"
        )
        viewModelScope.launch {
            repository.logActivity(activity)
            _message.value = "Activity logged in School History."
        }
    }

    // Teacher Salary Actions (Principal Only)
    fun recordTeacherSalary(
        teacherId: String,
        teacherName: String,
        month: String,
        monthlySalary: Double,
        amountPaid: Double,
        paymentDate: String,
        remainingAmount: Double,
        paymentMode: String,
        transactionRef: String,
        remarks: String
    ) {
        val recordedBy = principalProfile.value?.name ?: "Principal"
        viewModelScope.launch {
            val res = repository.recordTeacherSalary(
                teacherId = teacherId,
                teacherName = teacherName,
                month = month,
                monthlySalary = monthlySalary,
                amountPaid = amountPaid,
                paymentDate = paymentDate,
                remainingAmount = remainingAmount,
                paymentMode = paymentMode,
                transactionRef = transactionRef,
                remarks = remarks,
                recordedBy = recordedBy
            )
            if (res.isSuccess) {
                _message.value = "Salary record saved for $teacherName ($month)."
            } else {
                _message.value = res.exceptionOrNull()?.message ?: "Failed to record salary."
            }
        }
    }

    fun deleteTeacherSalary(id: String) {
        viewModelScope.launch {
            repository.deleteTeacherSalary(id)
            _message.value = "Teacher salary record removed."
        }
    }

    fun logout() {
        repository.logout()
    }
}

class PrincipalViewModelFactory(private val repository: SchoolRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PrincipalViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PrincipalViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
