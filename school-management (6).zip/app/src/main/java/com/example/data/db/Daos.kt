package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Announcement
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceSubmissionRecord
import com.example.data.model.ChatMessage
import com.example.data.model.FeePayment
import com.example.data.model.Homework
import com.example.data.model.LeaveRequest
import com.example.data.model.School
import com.example.data.model.SchoolClass
import com.example.data.model.SchoolTest
import com.example.data.model.Student
import com.example.data.model.StudentFee
import com.example.data.model.StudentMark
import com.example.data.model.TeacherSalary
import com.example.data.model.ActivityRecord
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {
    @Query("SELECT * FROM schools ORDER BY name ASC")
    fun getAllSchools(): Flow<List<School>>

    @Query("SELECT * FROM schools WHERE id = :id LIMIT 1")
    suspend fun getSchoolById(id: String): School?

    @Query("SELECT * FROM schools WHERE id = :id LIMIT 1")
    fun getSchoolByIdFlow(id: String): Flow<School?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchool(school: School)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchools(schools: List<School>)

    @Query("SELECT COUNT(*) FROM schools")
    suspend fun getSchoolCount(): Int
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserAccount?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserByIdFlow(id: String): Flow<UserAccount?>

    @Query("SELECT * FROM users WHERE schoolId = :schoolId AND role = 'TEACHER' ORDER BY name ASC")
    fun getAllTeachers(schoolId: String): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE schoolId = :schoolId AND role = 'TEACHER' AND status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingTeachers(schoolId: String): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE schoolId = :schoolId AND role = 'TEACHER' AND status = 'APPROVED' ORDER BY name ASC")
    fun getApprovedTeachers(schoolId: String): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE schoolId = :schoolId AND role = 'PARENT' ORDER BY name ASC")
    fun getAllParents(schoolId: String): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE schoolId = :schoolId AND role = 'PARENT' AND status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingParents(schoolId: String): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE schoolId = :schoolId AND role = 'PARENT' AND status = 'APPROVED' ORDER BY name ASC")
    fun getApprovedParents(schoolId: String): Flow<List<UserAccount>>

    @Query("SELECT COUNT(*) FROM users WHERE schoolId = :schoolId AND role = 'PRINCIPAL'")
    suspend fun getPrincipalCount(schoolId: String): Int

    @Query("SELECT COUNT(*) FROM users WHERE role = 'PRINCIPAL'")
    suspend fun getTotalPrincipalCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccount)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserAccount>)

    @Update
    suspend fun updateUser(user: UserAccount)

    @Query("UPDATE users SET status = :status WHERE id = :userId")
    suspend fun updateTeacherStatus(userId: String, status: String)

    @Query("UPDATE users SET status = :status WHERE id = :userId")
    suspend fun updateUserStatus(userId: String, status: String)

    @Query("UPDATE users SET linkedStudentIds = :linkedStudentIds WHERE id = :parentId")
    suspend fun updateParentLinkedStudents(parentId: String, linkedStudentIds: String)

    @Query("UPDATE users SET assignedClassId = :classId WHERE id = :teacherId")
    suspend fun updateAssignedClass(teacherId: String, classId: String?)

    @Query("UPDATE users SET passwordHash = :newPasswordHash, passwordSalt = :newSalt WHERE id = :userId")
    suspend fun updatePassword(userId: String, newPasswordHash: String, newSalt: String)

    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUser(userId: String)
}

@Dao
interface ClassDao {
    @Query("SELECT * FROM classes WHERE schoolId = :schoolId ORDER BY name ASC")
    fun getAllClasses(schoolId: String): Flow<List<SchoolClass>>

    @Query("SELECT * FROM classes WHERE id = :id LIMIT 1")
    suspend fun getClassById(id: String): SchoolClass?

    @Query("SELECT * FROM classes WHERE id = :id LIMIT 1")
    fun getClassByIdFlow(id: String): Flow<SchoolClass?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClass(schoolClass: SchoolClass)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClasses(classes: List<SchoolClass>)

    @Update
    suspend fun updateClass(schoolClass: SchoolClass)

    @Query("UPDATE classes SET classTeacherId = :teacherId WHERE id = :classId")
    suspend fun updateClassTeacher(classId: String, teacherId: String?)

    @Query("DELETE FROM classes WHERE id = :id")
    suspend fun deleteClass(id: String)
}

@Dao
interface StudentDao {
    @Query("SELECT * FROM students WHERE schoolId = :schoolId ORDER BY rollNumber ASC")
    fun getAllStudents(schoolId: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE schoolId = :schoolId AND classId = :classId ORDER BY rollNumber ASC")
    fun getStudentsByClass(schoolId: String, classId: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE schoolId = :schoolId AND classId = :classId ORDER BY rollNumber ASC")
    suspend fun getStudentsByClassDirect(schoolId: String, classId: String): List<Student>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentById(id: String): Student?

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    fun getStudentByIdFlow(id: String): Flow<Student?>

    @Query("SELECT * FROM students WHERE id IN (:ids)")
    fun getStudentsByIdsFlow(ids: List<String>): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id IN (:ids)")
    suspend fun getStudentsByIds(ids: List<String>): List<Student>

    @Query("SELECT COUNT(*) FROM students WHERE schoolId = :schoolId")
    fun getTotalStudentCount(schoolId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM students WHERE schoolId = :schoolId AND classId = :classId")
    fun getStudentCountByClass(schoolId: String, classId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<Student>)

    @Update
    suspend fun updateStudent(student: Student)

    @Query("UPDATE students SET parentUserId = :parentUserId WHERE id = :studentId")
    suspend fun updateStudentParentUserId(studentId: String, parentUserId: String?)

    @Query("DELETE FROM students WHERE id = :id")
    suspend fun deleteStudent(id: String)
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE schoolId = :schoolId AND classId = :classId AND date = :date ORDER BY rollNumber ASC")
    fun getAttendanceByClassAndDate(schoolId: String, classId: String, date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE schoolId = :schoolId AND classId = :classId AND date = :date")
    suspend fun getAttendanceByClassAndDateDirect(schoolId: String, classId: String, date: String): List<AttendanceRecord>

    @Query("SELECT * FROM attendance_records WHERE schoolId = :schoolId AND date = :date")
    fun getAllAttendanceByDate(schoolId: String, date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE schoolId = :schoolId AND date = :date AND status = 'ABSENT' ORDER BY classId ASC, rollNumber ASC")
    fun getAbsentStudentsByDate(schoolId: String, date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE studentId = :studentId ORDER BY date DESC")
    fun getAttendanceForStudent(studentId: String): Flow<List<AttendanceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(records: List<AttendanceRecord>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSingleAttendance(record: AttendanceRecord)

    @Query("DELETE FROM attendance_records WHERE classId = :classId AND date = :date")
    suspend fun deleteAttendanceForClassDate(classId: String, date: String)
}

@Dao
interface AttendanceSubmissionDao {
    @Query("SELECT * FROM attendance_submissions WHERE schoolId = :schoolId ORDER BY date DESC, submittedAt DESC")
    fun getAllSubmissions(schoolId: String): Flow<List<AttendanceSubmissionRecord>>

    @Query("SELECT * FROM attendance_submissions WHERE schoolId = :schoolId AND date = :date ORDER BY className ASC")
    fun getSubmissionsByDate(schoolId: String, date: String): Flow<List<AttendanceSubmissionRecord>>

    @Query("SELECT * FROM attendance_submissions WHERE schoolId = :schoolId AND classId = :classId ORDER BY date DESC")
    fun getSubmissionsByClass(schoolId: String, classId: String): Flow<List<AttendanceSubmissionRecord>>

    @Query("SELECT * FROM attendance_submissions WHERE schoolId = :schoolId AND classId = :classId AND date = :date LIMIT 1")
    fun getSubmissionByClassAndDateFlow(schoolId: String, classId: String, date: String): Flow<AttendanceSubmissionRecord?>

    @Query("SELECT * FROM attendance_submissions WHERE schoolId = :schoolId AND classId = :classId AND date = :date LIMIT 1")
    suspend fun getSubmissionByClassAndDate(schoolId: String, classId: String, date: String): AttendanceSubmissionRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubmission(submission: AttendanceSubmissionRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubmissions(submissions: List<AttendanceSubmissionRecord>)

    @Query("DELETE FROM attendance_submissions WHERE id = :id")
    suspend fun deleteSubmission(id: String)
}

@Dao
interface HomeworkDao {
    @Query("SELECT * FROM homework WHERE schoolId = :schoolId AND classId = :classId ORDER BY assignedDate DESC")
    fun getHomeworkByClass(schoolId: String, classId: String): Flow<List<Homework>>

    @Query("SELECT * FROM homework WHERE schoolId = :schoolId ORDER BY assignedDate DESC")
    fun getAllHomework(schoolId: String): Flow<List<Homework>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomeworkList(list: List<Homework>)

    @Update
    suspend fun updateHomework(homework: Homework)

    @Query("DELETE FROM homework WHERE id = :id")
    suspend fun deleteHomework(id: String)
}

@Dao
interface TestDao {
    @Query("SELECT * FROM school_tests WHERE schoolId = :schoolId ORDER BY date DESC, timestamp DESC")
    fun getAllTests(schoolId: String): Flow<List<SchoolTest>>

    @Query("SELECT * FROM school_tests WHERE schoolId = :schoolId AND classId = :classId ORDER BY date DESC, timestamp DESC")
    fun getTestsByClass(schoolId: String, classId: String): Flow<List<SchoolTest>>

    @Query("SELECT * FROM school_tests WHERE id = :id LIMIT 1")
    suspend fun getTestById(id: String): SchoolTest?

    @Query("SELECT * FROM school_tests WHERE id = :id LIMIT 1")
    fun getTestByIdFlow(id: String): Flow<SchoolTest?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTest(test: SchoolTest)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTests(tests: List<SchoolTest>)

    @Update
    suspend fun updateTest(test: SchoolTest)

    @Query("DELETE FROM school_tests WHERE id = :id")
    suspend fun deleteTest(id: String)
}

@Dao
interface MarkDao {
    @Query("SELECT * FROM student_marks WHERE schoolId = :schoolId AND classId = :classId ORDER BY examName ASC, subject ASC, rollNumber ASC")
    fun getMarksByClass(schoolId: String, classId: String): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE testId = :testId ORDER BY rank ASC, marksObtained DESC, rollNumber ASC")
    fun getMarksByTest(testId: String): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE schoolId = :schoolId AND classId = :classId AND examName = :examName ORDER BY rank ASC, marksObtained DESC")
    fun getMarksByClassAndExam(schoolId: String, classId: String, examName: String): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE studentId = :studentId ORDER BY date DESC, timestamp DESC")
    fun getMarksByStudent(studentId: String): Flow<List<StudentMark>>

    @Query("SELECT * FROM student_marks WHERE schoolId = :schoolId ORDER BY date DESC, examName ASC, subject ASC")
    fun getAllMarks(schoolId: String): Flow<List<StudentMark>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMark(mark: StudentMark)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarks(marks: List<StudentMark>)

    @Update
    suspend fun updateMark(mark: StudentMark)

    @Query("DELETE FROM student_marks WHERE id = :id")
    suspend fun deleteMark(id: String)

    @Query("DELETE FROM student_marks WHERE testId = :testId")
    suspend fun deleteMarksByTest(testId: String)
}

@Dao
interface FeeDao {
    @Query("SELECT * FROM student_fees WHERE schoolId = :schoolId ORDER BY classId ASC, rollNumber ASC")
    fun getAllStudentFees(schoolId: String): Flow<List<StudentFee>>

    @Query("SELECT * FROM student_fees WHERE schoolId = :schoolId AND classId = :classId ORDER BY rollNumber ASC")
    fun getFeesByClass(schoolId: String, classId: String): Flow<List<StudentFee>>

    @Query("SELECT * FROM student_fees WHERE studentId = :studentId LIMIT 1")
    fun getFeeForStudent(studentId: String): Flow<StudentFee?>

    @Query("SELECT * FROM student_fees WHERE studentId = :studentId LIMIT 1")
    suspend fun getFeeForStudentDirect(studentId: String): StudentFee?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentFee(fee: StudentFee)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentFees(fees: List<StudentFee>)

    @Update
    suspend fun updateStudentFee(fee: StudentFee)

    @Query("DELETE FROM student_fees WHERE studentId = :studentId")
    suspend fun deleteStudentFee(studentId: String)
}

@Dao
interface FeePaymentDao {
    @Query("SELECT * FROM fee_payments WHERE schoolId = :schoolId ORDER BY date DESC, timestamp DESC")
    fun getAllPayments(schoolId: String): Flow<List<FeePayment>>

    @Query("SELECT * FROM fee_payments WHERE schoolId = :schoolId AND classId = :classId ORDER BY date DESC, timestamp DESC")
    fun getPaymentsByClass(schoolId: String, classId: String): Flow<List<FeePayment>>

    @Query("SELECT * FROM fee_payments WHERE studentId = :studentId ORDER BY date DESC, timestamp DESC")
    fun getPaymentsByStudent(studentId: String): Flow<List<FeePayment>>

    @Query("SELECT * FROM fee_payments WHERE studentId = :studentId ORDER BY date DESC, timestamp DESC")
    suspend fun getPaymentsByStudentDirect(studentId: String): List<FeePayment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: FeePayment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayments(payments: List<FeePayment>)

    @Query("DELETE FROM fee_payments WHERE id = :id")
    suspend fun deletePayment(id: String)
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements WHERE schoolId = :schoolId AND (targetAudience = 'ALL' OR targetAudience = :classId) ORDER BY timestamp DESC")
    fun getAnnouncementsForClass(schoolId: String, classId: String): Flow<List<Announcement>>

    @Query("SELECT * FROM announcements WHERE schoolId = :schoolId ORDER BY timestamp DESC")
    fun getAllAnnouncements(schoolId: String): Flow<List<Announcement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncements(list: List<Announcement>)

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncement(id: String)
}

@Dao
interface LeaveDao {
    @Query("SELECT * FROM leave_requests WHERE schoolId = :schoolId ORDER BY appliedAt DESC")
    fun getAllLeaveRequests(schoolId: String): Flow<List<LeaveRequest>>

    @Query("SELECT * FROM leave_requests WHERE teacherId = :teacherId ORDER BY appliedAt DESC")
    fun getLeaveRequestsByTeacher(teacherId: String): Flow<List<LeaveRequest>>

    @Query("SELECT * FROM leave_requests WHERE schoolId = :schoolId AND status = 'PENDING' ORDER BY appliedAt DESC")
    fun getPendingLeaveRequests(schoolId: String): Flow<List<LeaveRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveRequest(request: LeaveRequest)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaveRequests(requests: List<LeaveRequest>)

    @Query("SELECT * FROM leave_requests WHERE id = :id LIMIT 1")
    suspend fun getLeaveRequestById(id: String): LeaveRequest?

    @Query("UPDATE leave_requests SET status = :status, principalComment = :comment WHERE id = :id")
    suspend fun updateLeaveStatus(id: String, status: String, comment: String?)

    @Query("DELETE FROM leave_requests WHERE id = :id")
    suspend fun deleteLeaveRequest(id: String)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE schoolId = :schoolId AND studentId = :studentId ORDER BY timestamp ASC")
    fun getMessagesForStudent(schoolId: String, studentId: String): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE schoolId = :schoolId AND (senderId = :userId OR receiverId = :userId) ORDER BY timestamp DESC")
    fun getMessagesForUser(schoolId: String, userId: String): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE schoolId = :schoolId ORDER BY timestamp DESC")
    fun getAllMessagesForSchool(schoolId: String): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<ChatMessage>)

    @Query("UPDATE chat_messages SET status = :status WHERE id = :id")
    suspend fun updateMessageStatus(id: String, status: String)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessage(id: String)
}

@Dao
interface TeacherSalaryDao {
    @Query("SELECT * FROM teacher_salaries WHERE schoolId = :schoolId ORDER BY timestamp DESC")
    fun getAllSalaries(schoolId: String): Flow<List<TeacherSalary>>

    @Query("SELECT * FROM teacher_salaries WHERE schoolId = :schoolId AND teacherId = :teacherId ORDER BY timestamp DESC")
    fun getSalariesForTeacher(schoolId: String, teacherId: String): Flow<List<TeacherSalary>>

    @Query("SELECT * FROM teacher_salaries WHERE schoolId = :schoolId AND month = :month ORDER BY teacherName ASC")
    fun getSalariesByMonth(schoolId: String, month: String): Flow<List<TeacherSalary>>

    @Query("SELECT COUNT(*) FROM teacher_salaries")
    suspend fun getSalaryCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalary(salary: TeacherSalary)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalaries(salaries: List<TeacherSalary>)

    @Update
    suspend fun updateSalary(salary: TeacherSalary)

    @Query("DELETE FROM teacher_salaries WHERE id = :id")
    suspend fun deleteSalary(id: String)
}

@Dao
interface ActivityRecordDao {
    @Query("SELECT * FROM activity_records WHERE schoolId = :schoolId ORDER BY timestamp DESC")
    fun getAllActivities(schoolId: String): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activity_records WHERE schoolId = :schoolId AND category = :category ORDER BY timestamp DESC")
    fun getActivitiesByCategory(schoolId: String, category: String): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activity_records WHERE schoolId = :schoolId AND classId = :classId ORDER BY timestamp DESC")
    fun getActivitiesByClass(schoolId: String, classId: String): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activity_records WHERE schoolId = :schoolId AND personId = :personId ORDER BY timestamp DESC")
    fun getActivitiesByPerson(schoolId: String, personId: String): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM activity_records WHERE schoolId = :schoolId AND date = :date ORDER BY timestamp DESC")
    fun getActivitiesByDate(schoolId: String, date: String): Flow<List<ActivityRecord>>

    @Query("SELECT COUNT(*) FROM activity_records")
    suspend fun getActivityCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: ActivityRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivities(activities: List<ActivityRecord>)

    @Query("DELETE FROM activity_records WHERE id = :id")
    suspend fun deleteActivity(id: String)
}


